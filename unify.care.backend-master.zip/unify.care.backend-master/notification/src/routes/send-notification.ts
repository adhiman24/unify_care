import express, { Request, Response } from 'express';
import { body } from 'express-validator';
import {
  NotFoundError,
  requireAuth,
  validateRequest,
  InternalServerError,
  DevicePushType
} from '@unifycare/aem';
import { DeviceList } from '../models/device-list';
import { push } from '../push';
import mongoose from 'mongoose';

const router = express.Router();

router.post(
  '/api/notification/push',
  requireAuth,
  [
    body('userId')
      .not()
      .isEmpty()
      .custom((input: string) => mongoose.Types.ObjectId.isValid(input))
      .withMessage('User Id must be provided'),
    body('title')
      .not()
      .isEmpty()
      .withMessage('Message title must be provided'),
    body('body')
      .not()
      .isEmpty()
      .withMessage('Message body must be provided'),
  ],
  validateRequest,
  async (req: Request, res: Response) => {

    const { userId, title, body } = req.body;

    let device = await DeviceList.findById(userId);
    if (!device) {
      throw new NotFoundError();
    }

    try {
      const registrationIOSIds = [];
      const registrationANDROIDIds = [];
      let iosTopic;
      let androidTopic;
      for (let i = 0; i < device.numberOfDevices; i++) {
        if (device.devices[i].deviceType === DevicePushType.APM) {
          if (device.devices[i].token && device.devices[i].token !== '') {
            registrationIOSIds.push(device.devices[i].token);
            iosTopic = device.devices[i].topic;
          }
        } else {
          if (device.devices[i].token && device.devices[i].token !== '') {
            registrationANDROIDIds.push(device.devices[i].token);
            androidTopic = device.devices[i].topic;
          }
        }
      }
      const iosData = {
        title: title,
        body: body,
        topic: iosTopic
      };

      const androidData = {
        title: title,
        body: body,
        topic: androidTopic
      };

      if (registrationIOSIds.length > 0) {
        const iosResult = await push.send(registrationIOSIds, iosData);
        console.log('result: ' + JSON.stringify(iosResult));
      }

      if (registrationANDROIDIds.length > 0) {
        const androidResult = await push.send(registrationANDROIDIds, androidData);
        console.log('result: ' + JSON.stringify(androidResult));
      }
      res.status(200).send('OK');
    } catch (err) {
      console.error(err);
      throw new InternalServerError();
    }
  }
);

export { router as sendNotificationRouter };
