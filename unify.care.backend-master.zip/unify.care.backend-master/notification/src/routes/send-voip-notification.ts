import express, { Request, Response } from 'express';
import { body } from 'express-validator';
import {
  NotFoundError,
  requireAuth,
  validateRequest,
  InternalServerError,
  DevicePushType
} from '@unifycare/aem';
import { DeviceList } from '../models/device-list';
import { push } from '../push';
import mongoose from 'mongoose';

const router = express.Router();

router.post(
  '/api/notification/voippush',
  requireAuth,
  [
    body('userId')
      .not()
      .isEmpty()
      .custom((input: string) => mongoose.Types.ObjectId.isValid(input))
      .withMessage('User Id must be provided'),
    body('title')
      .not()
      .isEmpty()
      .withMessage('Message title must be provided'),
    body('body')
      .not()
      .isEmpty()
      .withMessage('Message body must be provided'),
  ],
  validateRequest,
  async (req: Request, res: Response) => {

    const { userId, title, body } = req.body;

    let device = await DeviceList.findById(userId);
    if (!device) {
      throw new NotFoundError();
    }

    try {
      const registrationIOSIds = [];
      let iosTopic;
      for (let i = 0; i < device.numberOfDevices; i++) {
        if (device.devices[i].deviceType === DevicePushType.APM) {
          if (device.devices[i].voiptoken && device.devices[i].voiptoken !== '') {
            registrationIOSIds.push(device.devices[i].voiptoken);
            iosTopic = device.devices[i].topic;
          }
        }
      }

      const iosData = {
        retries: 1,
        title: title,
        custom: body,
        topic: iosTopic + ".voip",
        priority: 'high',
        sound: 'ringing.wav',
        pushType: 'voip',
        alert: 'new pushkit',
        contentAvailable: 1,
      };

      console.log(iosData);
      if (registrationIOSIds.length > 0) {
        const iosResult = await push.send(registrationIOSIds, iosData);
        console.log('result: ' + JSON.stringify(iosResult));
      }
    } catch (err) {
      console.error(err);
      throw new InternalServerError();
    }
    res.status(200).send('OK');
  }
);

export { router as sendVoipNotificationRouter };
