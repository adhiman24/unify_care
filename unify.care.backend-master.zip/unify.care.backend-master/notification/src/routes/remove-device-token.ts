import express, { Request, Response } from 'express';
import { body } from 'express-validator';
import {
  NotFoundError,
  requireAuth,
  validateRequest,
} from '@unifycare/aem';
import { DeviceList } from '../models/device-list';
import { Device, DeviceDoc } from '../models/device';

const router = express.Router();

router.post(
  '/api/notification/token/remove',
  requireAuth,
  [
    body('uuid')
      .not()
      .isEmpty()
      .withMessage('uuid must be provided'),
  ],
  validateRequest,
  async (req: Request, res: Response) => {

    const { uuid } = req.body;
    const userId = req.currentUser!.id;

    if (userId && userId !== "undefined") {

      let device = await DeviceList.findById(req.currentUser!.id);

      if (device) {
        //check if this device alrady exist for this user
        let deviceIndex = -1;
        for (let i = 0; i < device.numberOfDevices; i++) {
          if (device.devices[i].uuid === uuid) {
            deviceIndex = i;
            break;
          }
        }
        if (deviceIndex != -1) {
          let newDeviceList: DeviceDoc[] = [...device.devices];
          newDeviceList.splice(deviceIndex, 1);
          device.set({
            devices: newDeviceList,
            numberOfDevices: device.numberOfDevices - 1,
          });
          await device.save();
        }
      }
    }
    res.status(200).send("Device Removed Successfully");
  }
);

export { router as removeDeviceTokenRouter };
