import express, { Request, Response } from 'express';
import { body } from 'express-validator';
import {
  DevicePushType,
  DeviceType,
  requireAuth,
  UserType,
  validateRequest,
} from '@unifycare/aem';
import { DeviceList } from '../models/device-list';
import { Device, DeviceDoc } from '../models/device';
import mongoose from 'mongoose';

const router = express.Router();

router.post(
  '/api/notification/token/update',
  requireAuth,
  [
    body('uuid')
      .not()
      .isEmpty()
      .withMessage('uuid must be provided'),
    body('deviceType')
      .not()
      .isEmpty()
      .withMessage('Device Push Type must be provided'),
  ],
  validateRequest,
  async (req: Request, res: Response) => {

    const { uuid, token, voiptoken, deviceType } = req.body;
    const numberOfDevices = 0;

    let device = await DeviceList.findById(req.currentUser!.id);

    if (!device) {
      let newDeviceList: DeviceDoc[] = [];

      let topic = String(process.env.CUSTOMER_IOS_APP_ID);
      let devicePushType = DevicePushType.APM;
      if (req.currentUser!.uty === UserType.Patient) {
        if (deviceType === DeviceType.IOS) {
          topic = String(process.env.CUSTOMER_IOS_APP_ID);
          devicePushType = DevicePushType.APM;
        } else {
          topic = String(process.env.CUSTOMER_ANDROID_APP_ID);
          devicePushType = DevicePushType.GCM;
        }
      } else {
        if (deviceType === DeviceType.IOS) {
          topic = String(process.env.CONSULTANT_IOS_APP_ID);
          devicePushType = DevicePushType.APM;
        } else {
          topic = String(process.env.CONSULTANT_ANDROID_APP_ID);
          devicePushType = DevicePushType.GCM;
        }
      }
      const newDevice = Device.build({
        id: new mongoose.Types.ObjectId().toHexString(),
        uuid: uuid,
        token: token,
        deviceType: devicePushType,
        topic: topic,
        voiptoken: voiptoken
      })
      newDeviceList.push(newDevice);

      device = DeviceList.build({
        id: req.currentUser!.id,
        devices: newDeviceList,
        numberOfDevices: numberOfDevices + 1,
      });
      await device.save();

    } else {
      //check if this device alrady exist for this user
      let deviceIndex = -1;
      for (let i = 0; i < device.numberOfDevices; i++) {
        if (device.devices[i].uuid === uuid) {
          deviceIndex = i;
          break;
        }
      }
      if (deviceIndex != -1) {
        let newDeviceList: DeviceDoc[] = [...device.devices];
        newDeviceList[deviceIndex].token = token;
        newDeviceList[deviceIndex].voiptoken = voiptoken;
        device.set({
          devices: newDeviceList
        });
        await device.save();
      } else {
        //Another New device of this user
        let newDeviceList: DeviceDoc[] = [...device.devices];
        let topic = String(process.env.CUSTOMER_IOS_APP_ID);
        let devicePushType = DevicePushType.APM;
        if (req.currentUser!.uty === UserType.Patient) {
          if (deviceType === DeviceType.IOS) {
            topic = String(process.env.CUSTOMER_IOS_APP_ID);
            devicePushType = DevicePushType.APM;
          } else {
            topic = String(process.env.CUSTOMER_ANDROID_APP_ID);
            devicePushType = DevicePushType.GCM;
          }
        } else {
          if (deviceType === DeviceType.IOS) {
            topic = String(process.env.CONSULTANT_IOS_APP_ID);
            devicePushType = DevicePushType.APM;
          } else {
            topic = String(process.env.CONSULTANT_ANDROID_APP_ID);
            devicePushType = DevicePushType.GCM;
          }
        }
        const newDevice = Device.build({
          id: new mongoose.Types.ObjectId().toHexString(),
          uuid: uuid,
          token: token,
          deviceType: devicePushType,
          topic: topic,
          voiptoken: voiptoken
        })
        newDeviceList.push(newDevice);

        device.set({
          devices: newDeviceList,
          numberOfDevices: device.numberOfDevices + 1,
        });
        await device.save();
      }
    }
    res.status(200).send(device);
  }
);

export { router as updateDeviceTokenRouter };
