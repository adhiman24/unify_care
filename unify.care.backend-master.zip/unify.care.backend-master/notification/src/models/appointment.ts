import { AppointmentStatus } from '@unifycare/aem';
import mongoose from 'mongoose';
import { updateIfCurrentPlugin } from 'mongoose-update-if-current';

interface AppointmentAttrs {
  id: string;
  consultantId: string;
  customerId: string;
  creatorId: string;
  parentId: string;
  partnerId: string;
  createdBy: string;
  appointmentDate: string;
  appointmentSlotId: number;
  appointmentStatus: AppointmentStatus;
  appointmentCreationTime: Date;
}

interface AppointmentDoc extends mongoose.Document {
  consultantId: string;
  customerId: string;
  creatorId: string;
  parentId: string;
  partnerId: string;
  createdBy: string;
  appointmentDate: string;
  appointmentSlotId: number;
  appointmentStatus: AppointmentStatus;
  appointmentCreationTime: Date;
  version: number;
}

interface AppointmentModel extends mongoose.Model<AppointmentDoc> {
  build(attrs: AppointmentAttrs): AppointmentDoc;
  findByEvent(event: {
    id: string;
    version: number;
  }): Promise<AppointmentDoc | null>;
}

const appointmentSchema = new mongoose.Schema(
  {
    consultantId: {
      type: String,
      required: true
    },
    customerId: {
      type: String,
      required: true
    },
    creatorId: {
      type: String,
      required: true
    },
    parentId: {
      type: String,
      required: true
    },
    partnerId: {
      type: String,
      required: true
    },
    appointmentSlotId: {
      type: Number,
      required: true
    },
    appointmentDate: {
      type: String,
      required: true
    },
    appointmentStatus: {
      type: AppointmentStatus,
      required: true
    },
    appointmentCreationTime: {
      type: Date,
      required: true
    },
    createdBy: {
      type: String,
      required: true
    },
  },
  {
    toJSON: {
      transform(doc, ret) {
        ret.id = ret._id;
        delete ret._id;
      },
    },
  }
);
appointmentSchema.set('versionKey', 'version');
appointmentSchema.plugin(updateIfCurrentPlugin);

appointmentSchema.static('findByEvent', (event: { id: string, version: number }) => {
  return Appointment.findOne({
    _id: event.id,
    version: event.version - 1,
  });
});

appointmentSchema.static('build', (attrs: AppointmentAttrs) => {
  return new Appointment({
    _id: attrs.id,
    consultantId: attrs.consultantId,
    customerId: attrs.customerId,
    partnerId: attrs.partnerId,
    parentId: attrs.parentId,
    appointmentSlotId: attrs.appointmentSlotId,
    appointmentDate: attrs.appointmentDate,
    appointmentStatus: attrs.appointmentStatus,
    appointmentCreationTime: attrs.appointmentCreationTime,
    createdBy: attrs.createdBy,
    creatorId: attrs.creatorId,
  });
});


const Appointment = mongoose.model<AppointmentDoc, AppointmentModel>('Appointment', appointmentSchema);

export { Appointment };
