import mongoose from 'mongoose';

interface UserAttrs {
  id: string;
  uid: string;
}

interface UserDoc extends mongoose.Document {
  uid: string;
}

interface UserModel extends mongoose.Model<UserDoc> {
  build(attrs: UserAttrs): UserDoc;
  findByEvent(event: {
    id: string;
  }): Promise<UserDoc | null>;
}

const userSchema = new mongoose.Schema(
  {
    uid: {
      type: String,
      required: true
    },
  },
  {
    toJSON: {
      transform(doc, ret) {
        ret.id = ret._id;
        delete ret._id;
      },
    },
  }
);
userSchema.static('findByEvent', (event: { id: string }) => {
  return User.findOne({
    _id: event.id,
  });
});

userSchema.static('build', (attrs: UserAttrs) => {
  return new User({
    _id: attrs.id,
    uid: attrs.uid
  });
});

const User = mongoose.model<UserDoc, UserModel>('User', userSchema);

export { User };
