import express from 'express';
import 'express-async-errors';
import { json } from 'body-parser';
import cookieSession from 'cookie-session';
import { errorHandler, NotFoundError, currentUser } from '@unifycare/aem';
import { loggerMiddleware, winstonMiddleware } from '@unifycare/logger';
import { sendNotificationRouter } from './routes/send-notification';
import { sendVoipNotificationRouter } from './routes/send-voip-notification';
import { updateDeviceTokenRouter } from './routes/update-device-token';
import { removeDeviceTokenRouter } from './routes/remove-device-token';
import { updateUserFirebaseIdRouter } from './routes/update-user-uid';
import { showUserFirebaseIdRouter } from './routes/show-user-uid';

var cors = require('cors')

const app = express();

app.use(cors({ credentials: true, origin: 'http://localhost:3000' }));

app.set('trust proxy', true);
app.use(json());
app.use(
  cookieSession({
    signed: false,
    secure: process.env.NODE_ENV !== 'test',
    //secure: false,
  })
);

app.use(currentUser);

app.use(loggerMiddleware);
app.use(winstonMiddleware);
app.use(sendNotificationRouter);
app.use(updateDeviceTokenRouter);
app.use(updateUserFirebaseIdRouter);
app.use(removeDeviceTokenRouter);
app.use(showUserFirebaseIdRouter);
app.use(sendVoipNotificationRouter);

app.all('*', async (req, res) => {
  throw new NotFoundError();
});

app.use(errorHandler);
export { app };
