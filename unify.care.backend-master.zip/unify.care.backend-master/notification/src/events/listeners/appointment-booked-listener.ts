import { appointmentBookedGroupName } from './queue-group-name';
import { Message } from 'node-nats-streaming';
import { Listener, AppointmentBookedEvent, Subjects } from '@unifycare/aem';
import { Appointment } from '../../models/appointment';
import mongoose from 'mongoose';

export class AppointmentBookedListener extends Listener<AppointmentBookedEvent> {
  subject: Subjects.AppointmentBooked = Subjects.AppointmentBooked;
  queueGroupName = appointmentBookedGroupName;

  async onMessage(data: AppointmentBookedEvent['data'], msg: Message) {

    console.log(data);
    let appointment = null;
    if (data.appointmentId) {
      appointment = await Appointment.findById(data.appointmentId);
      if (appointment) {
        console.log("appointment found for Id: " + appointment.id)
        msg.ack();
        return;
      }
    } else {
      msg.ack();
      return;
    }

    appointment = Appointment.build({
      id: data.appointmentId,
      consultantId: data.consultantId,
      customerId: data.customerId,
      creatorId: data.creatorId,
      partnerId: data.partnerId,
      parentId: data.parentId,
      createdBy: data.createdBy,
      appointmentDate: data.appointmentDate,
      appointmentSlotId: data.appointmentSlotId,
      appointmentStatus: data.appointmentStatus,
      appointmentCreationTime: data.appointmentCreationTime,
    })
    await appointment.save();

    msg.ack();
  }
}
