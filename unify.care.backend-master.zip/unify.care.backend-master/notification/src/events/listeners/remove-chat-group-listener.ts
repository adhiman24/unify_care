import { Listener, RemoveChatGroupEvent, Subjects, ChatMessageType } from '@unifycare/aem';
import { Message } from 'node-nats-streaming';
import { User } from '../../models/user';
import { removeChatGroupName } from './queue-group-name';
import { fbDatabase } from '../../firebase';
import moment from 'moment';

export class RemoveChatGroupListener extends Listener<RemoveChatGroupEvent> {
  subject: Subjects.RemoveChatGroup = Subjects.RemoveChatGroup;
  queueGroupName = removeChatGroupName;

  async onMessage(data: RemoveChatGroupEvent['data'], msg: Message) {
    console.log('RemoveChatGroupEvent Received for patient id: ', data.patientId);


    let patient = await User.findById(data.patientId);
    if (!patient) {
      msg.ack();
      console.error("Patient Not Found for Id: " + data.patientId);
      return;
    }

    let consutant = await User.findById(data.consultantId);
    if (!consutant) {
      msg.ack();
      console.error("Consultant Not Found for Id: " + data.consultantId);
      return;
    }
    const uniqueId = patient.uid + "-" + consutant.uid;

    const consultMessage = {
      id: "End: " + data.appointmentDate + "-" + data.appointmentSlotId,
      type: ChatMessageType.SYSTEM,
      message: data.remarks,
      senderName: null,
      senderId: null,
      thumbUrl: null,
      imageUrl: null,
      fileName: null,
      time: new Date(),
      status: null,
      isEncrypted: false
    }

    if (moment(data.appointmentDate).isSame(moment().utcOffset(330).format('YYYY-MM-DD'))) {
      if (data.appointmentSlotId < ((moment().utcOffset(330).toObject()).hours * 2 + ((moment().utcOffset(330).toObject()).minutes > 30 ? 2 : 1))) {
        fbDatabase.ref('conversations/' + uniqueId + '/members/' + patient.uid).set(false);
        fbDatabase.ref('conversations/' + uniqueId + '/members/' + consutant.uid).set(false);
        fbDatabase.ref('conversations/' + uniqueId + '/messages').push().set(consultMessage);
      }
    } else if (moment(data.appointmentDate).isBefore(moment().utcOffset(330).format('YYYY-MM-DD'))) {
      fbDatabase.ref('conversations/' + uniqueId + '/members/' + patient.uid).set(false);
      fbDatabase.ref('conversations/' + uniqueId + '/members/' + consutant.uid).set(false);
    }
    msg.ack();
  }
}; 
