import { Listener, AddChatGroupEvent, Subjects, ChatMessageType } from '@unifycare/aem';
import { Message } from 'node-nats-streaming';
import { User } from '../../models/user';
import { addChatGroupName } from './queue-group-name';
import { fbDatabase } from '../../firebase';
import { Appointment } from '../../models/appointment';
import moment from 'moment';

export class AddChatGroupListener extends Listener<AddChatGroupEvent> {
  subject: Subjects.AddChatGroup = Subjects.AddChatGroup;
  queueGroupName = addChatGroupName;

  async onMessage(data: AddChatGroupEvent['data'], msg: Message) {
    console.log('AddChatGroupEvent Received for patient id: ', data.patientId);

    const appointment = await Appointment.findById(data.appointmentId);
    if (!appointment) {
      msg.ack();
      console.error("Appointment Not Found for Id: " + data.appointmentId);
      return;
    }

    const patient = await User.findById(data.patientId);
    if (!patient) {
      msg.ack();
      console.error("Patient Not Found for Id: " + data.patientId);
      return;
    }

    const consutant = await User.findById(data.consultantId);
    if (!consutant) {
      msg.ack();
      console.error("Consultant Not Found for Id: " + data.consultantId);
      return;
    }
    const uniqueId = patient.uid + "-" + consutant.uid;

    const consultMessage = {
      id: "Start: " + data.appointmentDate + "-" + data.appointmentSlotId,
      type: ChatMessageType.SYSTEM,
      message: data.remarks,
      senderName: null,
      senderId: null,
      thumbUrl: null,
      imageUrl: null,
      fileName: null,
      time: new Date(),
      status: null,
      isEncrypted: false
    }

    fbDatabase.ref('conversations/' + uniqueId + '/members/' + patient.uid).set(true);
    fbDatabase.ref('conversations/' + uniqueId + '/members/' + consutant.uid).set(true);

    // if (moment(data.appointmentDate).isSame(moment().utcOffset(330).format('YYYY-MM-DD'))) {
    //   if (data.appointmentSlotId >= ((moment().utcOffset(330).toObject()).hours * 2 + ((moment().utcOffset(330).toObject()).minutes > 30 ? 1 : 0))) {
    //     fbDatabase.ref('conversations/' + uniqueId + '/members/' + patient.uid).set(true);
    //     fbDatabase.ref('conversations/' + uniqueId + '/members/' + consutant.uid).set(true);
    //     if (data.remarks !== 'NA') {
    //       fbDatabase.ref('conversations/' + uniqueId + '/messages').push().set(consultMessage);
    //     }
    //   }
    // }
    msg.ack();
  }
}; 
