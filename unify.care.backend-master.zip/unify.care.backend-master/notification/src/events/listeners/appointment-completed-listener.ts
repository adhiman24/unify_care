import { appointmentCompletedGroupName } from './queue-group-name';
import { Message } from 'node-nats-streaming';
import { Listener, AppointmentCompletedEvent, Subjects, AppointmentStatus } from '@unifycare/aem';
import { Appointment } from '../../models/appointment';

export class AppointmentCompletedListener extends Listener<AppointmentCompletedEvent> {
  subject: Subjects.AppointmentCompleted = Subjects.AppointmentCompleted;
  queueGroupName = appointmentCompletedGroupName;

  async onMessage(data: AppointmentCompletedEvent['data'], msg: Message) {

    console.log(data);

    await Appointment.findOneAndDelete({ id: data.appointmentId });

    msg.ack();
  }
}
