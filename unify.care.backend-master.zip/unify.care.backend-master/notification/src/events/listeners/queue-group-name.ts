export const removeChatGroupName = 'notification-remove-chat-group-service';
export const addChatGroupName = 'notification-add-chat-group-service';
export const databasBackupGroupName = 'notification-database-backup-service';
export const databasUploadGroupName = 'notification-database-upload-service';
export const sendNotificationGroupName = 'notification-send-notification-service';
export const appointmentCompletedGroupName = 'notification-appointment-completed-service';
export const appointmentCancelledGroupName = 'notification-appointment-cancelled-service';
export const appointmentBookedGroupName = 'notification-appointment-booked-service';