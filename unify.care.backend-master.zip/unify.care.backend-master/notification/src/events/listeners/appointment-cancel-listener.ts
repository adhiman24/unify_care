import { appointmentCancelledGroupName } from './queue-group-name';
import { Message } from 'node-nats-streaming';
import { Listener, AppointmentCancelEvent, Subjects } from '@unifycare/aem';
import { Appointment } from '../../models/appointment';

export class AppointmentCancelListener extends Listener<AppointmentCancelEvent> {
  subject: Subjects.AppointmentCancelled = Subjects.AppointmentCancelled;
  queueGroupName = appointmentCancelledGroupName;

  async onMessage(data: AppointmentCancelEvent['data'], msg: Message) {

    console.log(data);

    await Appointment.findOneAndDelete({ id: data.appointmentId });

    msg.ack();
  }
}
