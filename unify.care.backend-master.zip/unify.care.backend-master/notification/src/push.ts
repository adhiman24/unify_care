const PushNotifications = require('node-pushnotifications');

const settings = {
    gcm: {
        id: 'AAAAX2n5KgM:APA91bF1hkSy2vLCr_dNOlzHtzpfnV9c6z_PolvS3IygnO_9yQrp7DR4gj7CQ6zpBJqQeeGckAA4y1VXwJng-iylT49Mc48D_Cw0OMCfD-vES5LV6C3ECmAaG_a9eJOHkZ5FhwtRO8lV',
    },
    apn: {
        token: {
            key: './Key.p8',
            keyId: 'HACM9KH937',
            teamId: 'GU9M6K2H9B',
        },
    },
};

export const push = new PushNotifications(settings);