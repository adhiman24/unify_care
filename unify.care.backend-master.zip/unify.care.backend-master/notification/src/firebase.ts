var firebase = require("firebase-admin");

var serviceAccount = require("../serviceAccountKey.json");

firebase.initializeApp({
    credential: firebase.credential.cert(serviceAccount),
    databaseURL: "https://gamma-unify-care.firebaseio.com"
});

export const fbDatabase = firebase.database()
