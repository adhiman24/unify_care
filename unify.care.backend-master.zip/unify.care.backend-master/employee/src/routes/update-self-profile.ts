import express, { Request, Response } from 'express';
import { body } from 'express-validator';
import { requireEmployeeAuth, validateRequest, NotFoundError } from '@unifycare/aem';
import { Employee } from '../models/employee';

const router = express.Router();

router.put(
  '/api/employee',
  requireEmployeeAuth,
  async (req: Request, res: Response) => {

    const {
      displayProfileImageName,
      displayDesignation,
      displayQualification,
      displayAdditionalInformation,
    } = req.body;

    const employee = await Employee.findById(req.currentUser!.id);

    if (!employee) {
      throw new NotFoundError();
    }

    employee.set({
      displayProfileImageName,
      displayDesignation,
      displayQualification,
      displayAdditionalInformation,
    });

    await employee.save();

    res.status(200).send(employee);
  }
);

export { router as updateSelfProfileRouter };
