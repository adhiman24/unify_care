import express, { Request, Response } from 'express';
import { Employee } from '../models/employee';
import { requireAuth, NotFoundError } from '@unifycare/aem';

const router = express.Router();

router.get('/api/employee', requireAuth, async (req: Request, res: Response) => {
  const employee = await Employee.findById(req.currentUser!.id);

  if (!employee) {
    throw new NotFoundError();
  }

  res.send(employee);
});

export { router as indexEmployeeRouter };
