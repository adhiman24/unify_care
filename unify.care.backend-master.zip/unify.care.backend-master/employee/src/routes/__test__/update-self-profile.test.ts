import request from 'supertest';
import { app } from '../../app';
import { Employee } from '../../models/employee'
import { PartnerStatus } from '@unifycare/aem';
import { UserStatus, UserType, AccessLevel, DepartmentType, SpecializationType, PartnerEmployeeCreatedEvent } from '@unifycare/aem';
import mongoose from 'mongoose';
import { natsWrapper } from '../../nats-wrapper';
import { PartnerEmployeeCreatedListener } from '../../events/listeners/partner-employee-created-listener';

const setup = async (id: string, firstName: string) => {

  // Create an instance of the listener
  const listener = new PartnerEmployeeCreatedListener(natsWrapper.client);

  // Create the fake data event
  const data: PartnerEmployeeCreatedEvent['data'] = {
    id,
    userFirstName: firstName,
    userLastName: 'Dhiman',
    emailId: 'email@email.com',
    phoneNumber: '9876598765',
    userType: UserType.Doctor,
    partnerId: 'RUF00045',
    accessLevel: AccessLevel.Employee,
    userStatus: UserStatus.Active,
    dateOfBirth: 'data.dateOfBirth',
    experinceInYears: 6,
    highestQualification: 'data.highestQualification',
    department: DepartmentType.CustomerSupport,
    specialization: SpecializationType.Cardiology,
    profileImageName: 'data.profileImageName',
    designation: 'data.designation',
  };

  // @ts-ignore
  const msg: Message = {
    ack: jest.fn(),
  };

  return { listener, data, msg };
};


it('has a route handler listening to /api/employee for post requests', async () => {
  const response = await request(app)
    .put('/api/employee')
    .send({});

  expect(response.status).not.toEqual(404);
});

it('can only be accessed if the user is signed in', async () => {
  const response = await request(app)
    .put('/api/employee')
    .send({});

  expect(response.status).toEqual(401);
});

it('returns a status other than 401 if the user is signed in', async () => {
  const response = await request(app)
    .put('/api/employee')
    .set('Cookie', global.signin(UserType.Doctor,
      AccessLevel.Employee,
      UserStatus.Active,
      new mongoose.Types.ObjectId().toHexString(),
      new mongoose.Types.ObjectId().toHexString()))
    .send({});

  expect(response.status).not.toEqual(401);
});

it('update partner status with valid inputs', async () => {

  const id = new mongoose.Types.ObjectId().toHexString();
  const firstName = 'Ashutosh';

  const { listener, data, msg } = await setup(id, firstName);

  await listener.onMessage(data, msg);


  const response = await request(app)
    .put('/api/employee')
    .set('Cookie', global.signin(UserType.Doctor,
      AccessLevel.Employee,
      UserStatus.Active,
      id,
      new mongoose.Types.ObjectId().toHexString()))
    .send({
      displayProfileImageName: "NewImageName",
      displayDesignation: "NewImageName",
      displayQualification: "NewImageName",
      displayAdditionalInformation: "NewImageName",
    })
    .expect(200);

  expect(response.body.displayDesignation).toEqual('NewImageName');
});
