import request from 'supertest';
import { app } from '../../app';
import mongoose from 'mongoose';
import { UserType, AccessLevel, UserStatus, DepartmentType, SpecializationType, PartnerEmployeeCreatedEvent } from '@unifycare/aem';
import { PartnerEmployeeCreatedListener } from '../../events/listeners/partner-employee-created-listener';
import { natsWrapper } from '../../nats-wrapper';


const setup = async (id: string, firstName: string) => {

  // Create an instance of the listener
  const listener = new PartnerEmployeeCreatedListener(natsWrapper.client);

  // Create the fake data event
  const data: PartnerEmployeeCreatedEvent['data'] = {
    id,
    userFirstName: firstName,
    userLastName: 'Dhiman',
    emailId: 'email@email.com',
    phoneNumber: '9876598765',
    userType: UserType.Doctor,
    partnerId: 'RUF00045',
    accessLevel: AccessLevel.Employee,
    userStatus: UserStatus.Active,
    dateOfBirth: 'data.dateOfBirth',
    experinceInYears: 6,
    highestQualification: 'data.highestQualification',
    department: DepartmentType.CustomerSupport,
    specialization: SpecializationType.Cardiology,
    profileImageName: 'data.profileImageName',
    designation: 'data.designation',
  };

  // @ts-ignore
  const msg: Message = {
    ack: jest.fn(),
  };

  return { listener, data, msg };
};

const setup1 = async (id: string, firstName: string) => {

  // Create an instance of the listener
  const listener1 = new PartnerEmployeeCreatedListener(natsWrapper.client);

  // Create the fake data event
  const data1: PartnerEmployeeCreatedEvent['data'] = {
    id,
    userFirstName: firstName,
    userLastName: 'Dhiman',
    emailId: 'email@email.com',
    phoneNumber: '9876598765',
    userType: UserType.Doctor,
    partnerId: 'RUF00045',
    accessLevel: AccessLevel.Employee,
    userStatus: UserStatus.Active,
    dateOfBirth: 'data.dateOfBirth',
    experinceInYears: 6,
    highestQualification: 'data.highestQualification',
    department: DepartmentType.CustomerSupport,
    specialization: SpecializationType.Cardiology,
    profileImageName: 'data.profileImageName',
    designation: 'data.designation',
  };

  // @ts-ignore
  const msg1: Message = {
    ack: jest.fn(),
  };

  return { listener1, data1, msg1 };
};

it('returns the doctors if the doctors found', async () => {

  const id = new mongoose.Types.ObjectId().toHexString();
  const firstName = 'Ashutosh';

  const { listener, data, msg } = await setup(id, firstName);

  await listener.onMessage(data, msg);

  const id1 = new mongoose.Types.ObjectId().toHexString();

  const firstName1 = 'Ashutosh2';

  const { listener1, data1, msg1 } = await setup1(id1, firstName1);

  await listener1.onMessage(data1, msg1);

  const doctors = await request(app)
    .get(`/api/employee/doctors`)
    .set('Cookie', global.signin(UserType.Patient,
      AccessLevel.Patient,
      UserStatus.Active,
      new mongoose.Types.ObjectId().toHexString(),
      new mongoose.Types.ObjectId().toHexString()))
    .send()
    .expect(200);

  expect(doctors.body[0].userFirstName).toEqual('Ashutosh');
  expect(doctors.body[1].userFirstName).toEqual('Ashutosh2');

});
