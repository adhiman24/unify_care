import request from 'supertest';
import { app } from '../../app';
import mongoose from 'mongoose';
import { Message } from 'node-nats-streaming';
import { AccessLevel, DepartmentType, SpecializationType, PartnerEmployeeCreatedEvent, UserStatus, UserType } from '@unifycare/aem';
import { natsWrapper } from '../../nats-wrapper';
import { PartnerEmployeeCreatedListener } from '../../events/listeners/partner-employee-created-listener';

const setup = async (id: string, firstName: string) => {

  // Create an instance of the listener
  const listener = new PartnerEmployeeCreatedListener(natsWrapper.client);

  // Create the fake data event
  const data: PartnerEmployeeCreatedEvent['data'] = {
    id,
    userFirstName: firstName,
    userLastName: 'Dhiman',
    emailId: 'email@email.com',
    phoneNumber: '9876598765',
    userType: UserType.Doctor,
    partnerId: 'RUF00045',
    accessLevel: AccessLevel.Employee,
    userStatus: UserStatus.Active,
    dateOfBirth: 'data.dateOfBirth',
    experinceInYears: 6,
    highestQualification: 'data.highestQualification',
    department: DepartmentType.CustomerSupport,
    specialization: SpecializationType.Cardiology,
    profileImageName: 'data.profileImageName',
    designation: 'data.designation',
  };

  // @ts-ignore
  const msg: Message = {
    ack: jest.fn(),
  };

  return { listener, data, msg };
};


it('can fetch self info', async () => {

  const id = new mongoose.Types.ObjectId().toHexString();
  const firstName = 'Ashutosh';

  const { listener, data, msg } = await setup(id, firstName);

  await listener.onMessage(data, msg);


  const response = await request(app).get('/api/employee')
    .set('Cookie', global.signin(UserType.Doctor,
      AccessLevel.Employee,
      UserStatus.Active,
      id,
      new mongoose.Types.ObjectId().toHexString()))
    .send().expect(200);

  console.log(response.body);

  expect(response.body.userFirstName).toEqual('Ashutosh');
});
