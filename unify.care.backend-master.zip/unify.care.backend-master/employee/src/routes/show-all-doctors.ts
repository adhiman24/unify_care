import express, { Request, Response } from 'express';
import { requireAuth, UserType } from '@unifycare/aem';
import { Employee } from '../models/employee';

const router = express.Router();

router.get('/api/employee/doctors', requireAuth, async (req: Request, res: Response) => {

  if (req.currentUser!.uty !== UserType.Patient) {
    const doctors = await Employee.find({
      userType: UserType.Doctor,
      partnerId: req.currentUser!.fid
    });
    res.send(doctors);
  } else {
    const doctors = await Employee.find({ userType: UserType.Doctor });
    res.send(doctors);
  }
});

export { router as showAllDoctorsRouter };
