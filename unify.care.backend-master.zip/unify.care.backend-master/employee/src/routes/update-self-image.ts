import express, { Request, Response } from 'express';
import { body } from 'express-validator';
import { requireAuth, validateRequest, NotFoundError } from '@unifycare/aem';
import { Employee } from '../models/employee';

const router = express.Router();

router.put(
  '/api/employee/image',
  requireAuth,
  async (req: Request, res: Response) => {

    const {
      profileImageName,
    } = req.body;

    const employee = await Employee.findById(req.currentUser!.id);

    if (!employee) {
      throw new NotFoundError();
    }

    employee.set({
      profileImageName,
    });

    await employee.save();

    res.status(200).send(employee);
  }
);

export { router as updateSelfProfileImageRouter };
