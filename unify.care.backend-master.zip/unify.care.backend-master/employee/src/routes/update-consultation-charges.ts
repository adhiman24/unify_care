import express, { Request, Response } from 'express';
import { body } from 'express-validator';
import {
  requireRosterManagerAuth
  , UserType, NotFoundError, BadRequestError,
  validateRequest
} from '@unifycare/aem';
import { Employee } from '../models/employee';
import mongoose from 'mongoose';

const router = express.Router();

router.put(
  '/api/employee/consultationcharge',
  requireRosterManagerAuth,
  [
    body('consultantId')
      .not()
      .isEmpty()
      .custom((input: string) => mongoose.Types.ObjectId.isValid(input))
      .withMessage('Consultant Id must be provided'),],
  validateRequest,
  async (req: Request, res: Response) => {

    const {
      consultantId,
      consultationCharge,
    } = req.body;

    const employee = await Employee.findById(consultantId);

    if (!employee) {
      throw new NotFoundError();
    }

    if (employee.userType == UserType.Doctor
      || employee.userType == UserType.Educator
      || employee.userType == UserType.Nutritionist) {

      employee.set({
        consultationChargesInINR: consultationCharge
      });
      await employee.save();

      res.status(200).send(employee);
    } else {
      throw new BadRequestError("Employee type is not consultant");
    }
  }
);

export { router as updateConsultationChargesRouter };
