import express from 'express';
import 'express-async-errors';
import { json } from 'body-parser';
import cookieSession from 'cookie-session';
import { errorHandler, NotFoundError, currentUser } from '@unifycare/aem';
import { loggerMiddleware, winstonMiddleware } from '@unifycare/logger';
import { indexEmployeeRouter } from './routes/index';
import { showAllDoctorsRouter } from './routes/show-all-doctors';
import { updateSelfProfileRouter } from './routes/update-self-profile';
import { updateConsultationChargesRouter } from './routes/update-consultation-charges';
import { updateSelfProfileImageRouter } from './routes/update-self-image';

var cors = require('cors')

const app = express();

app.use(cors({ credentials: true, origin: 'http://localhost:3000' }));

app.set('trust proxy', true);
app.use(json());
app.use(
  cookieSession({
    signed: false,
    secure: process.env.NODE_ENV !== 'test',
    //secure: false,

  })
);

app.use(currentUser);

app.use(loggerMiddleware);
app.use(winstonMiddleware);
app.use(indexEmployeeRouter);
app.use(showAllDoctorsRouter);
app.use(updateSelfProfileRouter);
app.use(updateConsultationChargesRouter);
app.use(updateSelfProfileImageRouter);

app.all('*', async (req, res) => {
  throw new NotFoundError();
});

app.use(errorHandler);
export { app };
