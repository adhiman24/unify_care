import mongoose from 'mongoose';
import { UserStatus, UserType, AccessLevel, DepartmentType, SpecializationType } from '@unifycare/aem';
import { updateIfCurrentPlugin } from 'mongoose-update-if-current';


interface EmployeeAttrs {
  id: string;
  userFirstName: string;
  userLastName: string;
  emailId: string;
  phoneNumber: string;
  partnerId: string;
  userStatus: UserStatus;
  accessLevel: AccessLevel;
  dateOfBirth: string;
  experinceInYears: number;
  highestQualification: string;
  userType: UserType;
  department: DepartmentType;
  specialization: SpecializationType;
  profileImageName: string;
  consultationChargesInINR: number;
  designation: string;
  displayProfileImageName: string;
  displayDesignation: string;
  displayQualification: string;
  displayAdditionalInformation: string;
  onboardingDate: Date;
}

interface EmployeeDoc extends mongoose.Document {
  userFirstName: string;
  userLastName: string;
  emailId: string;
  phoneNumber: string;
  partnerId: string;
  userStatus: UserStatus;
  accessLevel: AccessLevel;
  dateOfBirth: string;
  experinceInYears: number;
  userType: UserType;
  department: DepartmentType;
  specialization: SpecializationType;
  profileImageName: string;
  consultationChargesInINR: number;
  designation: string;
  highestQualification: string;
  displayProfileImageName: string;
  displayDesignation: string;
  displayQualification: string;
  displayAdditionalInformation: string;
  onboardingDate: Date;
  version: number;
}


interface EmployeeModel extends mongoose.Model<EmployeeDoc> {
  build(attrs: EmployeeAttrs): EmployeeDoc;
  findByEvent(event: {
    id: string;
    version: number;
  }): Promise<EmployeeDoc | null>;
}

const employeeSchema = new mongoose.Schema(
  {
    userFirstName: {
      type: String,
      required: true,
    },
    userLastName: {
      type: String,
      required: true,
    },
    emailId: {
      type: String,
      required: true,
    },
    phoneNumber: {
      type: String,
      required: true,
    },
    partnerId: {
      type: String,
      required: true,
    },
    userStatus: {
      type: UserStatus,
      required: true,
    },
    accessLevel: {
      type: AccessLevel,
      required: true,
    },
    userType: {
      type: UserType,
      required: true,
    },
    dateOfBirth: {
      type: String,
      required: true,
    },
    experinceInYears: {
      type: Number,
      required: true,
    },
    consultationChargesInINR: {
      type: Number,
      required: true,
    },
    department: {
      type: DepartmentType,
      required: true,
    },
    specialization: {
      type: SpecializationType,
      required: true,
    },
    profileImageName: {
      type: String,
      required: true,
    },
    designation: {
      type: String,
      required: true,
    },
    displayProfileImageName: {
      type: String,
      required: true,
    },
    displayDesignation: {
      type: String,
      required: true,
    },
    displayQualification: {
      type: String,
      required: true,
    },
    displayAdditionalInformation: {
      type: String,
      required: true,
    },
    highestQualification: {
      type: String,
      required: true,
    },
    onboardingDate: {
      type: Date,
      required: true,
    }
  },
  {
    toJSON: {
      transform(doc, ret) {
        ret.id = ret._id;
        delete ret._id;
      },
    },
  }
);
employeeSchema.set('versionKey', 'version');
employeeSchema.plugin(updateIfCurrentPlugin);

employeeSchema.static('findByEvent', (event: { id: string, version: number }) => {
  return Employee.findOne({
    _id: event.id,
    version: event.version - 1,
  });
});
employeeSchema.static('build', (attrs: EmployeeAttrs) => {
  return new Employee({
    _id: attrs.id,
    userFirstName: attrs.userFirstName,
    userLastName: attrs.userLastName,
    emailId: attrs.emailId,
    phoneNumber: attrs.phoneNumber,
    partnerId: attrs.partnerId,
    userStatus: attrs.userStatus,
    accessLevel: attrs.accessLevel,
    userType: attrs.userType,
    dateOfBirth: attrs.dateOfBirth,
    experinceInYears: attrs.experinceInYears,
    department: attrs.department,
    consultationChargesInINR: attrs.consultationChargesInINR,
    specialization: attrs.specialization,
    profileImageName: attrs.profileImageName,
    designation: attrs.designation,
    displayProfileImageName: attrs.displayProfileImageName,
    displayDesignation: attrs.displayDesignation,
    displayQualification: attrs.displayQualification,
    displayAdditionalInformation: attrs.displayAdditionalInformation,
    highestQualification: attrs.highestQualification,
    onboardingDate: attrs.onboardingDate
  });
});

const Employee = mongoose.model<EmployeeDoc, EmployeeModel>('Employee', employeeSchema);

export { Employee };
