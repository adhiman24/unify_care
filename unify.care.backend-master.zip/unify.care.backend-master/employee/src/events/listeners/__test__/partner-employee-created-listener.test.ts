import mongoose from 'mongoose';
import { Message } from 'node-nats-streaming';
import { PartnerEmployeeCreatedEvent, UserType, AccessLevel, UserStatus, DepartmentType, SpecializationType } from '@unifycare/aem';
import { natsWrapper } from '../../../nats-wrapper';
import { PartnerEmployeeCreatedListener } from '../partner-employee-created-listener';
import { Employee } from '../../../models/employee';

const setup = async () => {

  // Create an instance of the listener
  const listener = new PartnerEmployeeCreatedListener(natsWrapper.client);
  const id = new mongoose.Types.ObjectId().toHexString();

  // Create the fake data event
  const data: PartnerEmployeeCreatedEvent['data'] = {
    id,
    userFirstName: 'Ashutosh',
    userLastName: 'Dhiman',
    emailId: 'email@email.com',
    phoneNumber: '9876598765',
    userType: UserType.Doctor,
    partnerId: 'RUF00045',
    accessLevel: AccessLevel.Employee,
    userStatus: UserStatus.Active,
    dateOfBirth: 'data.dateOfBirth',
    experinceInYears: 6,
    highestQualification: 'data.highestQualification',
    department: DepartmentType.CustomerSupport,
    specialization: SpecializationType.Cardiology,
    profileImageName: 'data.profileImageName',
    designation: 'data.designation',
  };

  // @ts-ignore
  const msg: Message = {
    ack: jest.fn(),
  };

  return { listener, data, msg };
};

it('create new Hospital Subuser', async () => {
  const { listener, data, msg } = await setup();

  await listener.onMessage(data, msg);

  const newHospital = await Employee.findById(data.id);

  expect(newHospital!.partnerId).toEqual('RUF00045');
  expect(newHospital!.userStatus).toEqual(UserStatus.Active);
});

it('acks the message', async () => {
  const { listener, data, msg } = await setup();
  await listener.onMessage(data, msg);

  expect(msg.ack).toHaveBeenCalled();
});
