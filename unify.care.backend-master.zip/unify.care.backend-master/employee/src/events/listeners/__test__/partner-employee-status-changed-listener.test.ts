import mongoose from 'mongoose';
import { Message } from 'node-nats-streaming';
import { PartnerEmployeeStatusChangedEvent, UserType, AccessLevel, UserStatus, DepartmentType, SpecializationType } from '@unifycare/aem';
import { natsWrapper } from '../../../nats-wrapper';
import { PartnerEmployeeStatusChangedListener } from '../partner-employee-status-changed-listener';
import { Employee } from '../../../models/employee';

const setup = async () => {

  const id = new mongoose.Types.ObjectId().toHexString();
  //create New User
  const user = Employee.build({
    id,
    userFirstName: 'Ashutosh',
    userLastName: 'Dhiman',
    emailId: 'ashutosh@test.com',
    phoneNumber: '6666666666',
    partnerId: new mongoose.Types.ObjectId().toHexString(),
    userStatus: UserStatus.Suspended,
    accessLevel: AccessLevel.Employee,
    userType: UserType.Doctor,
    dateOfBirth: '24-09-1980',
    experinceInYears: 16,
    highestQualification: 'btech',
    department: DepartmentType.CustomerSupport,
    specialization: SpecializationType.Cardiology,
    profileImageName: 'string',
    designation: 'string',
    displayProfileImageName: 'string',
    displayDesignation: 'string',
    displayQualification: 'string',
    displayAdditionalInformation: 'string',
    onboardingDate: new Date(),
    consultationChargesInINR: 500,
  });
  await user.save();

  // Create an instance of the listener
  const listener = new PartnerEmployeeStatusChangedListener(natsWrapper.client);

  // Create the fake data event
  const data: PartnerEmployeeStatusChangedEvent['data'] = {
    id,
    userStatus: UserStatus.Suspended,
  };

  // @ts-ignore
  const msg: Message = {
    ack: jest.fn(),
  };

  return { listener, data, msg };
};

it('Update Hospital Subuser Status', async () => {
  const { listener, data, msg } = await setup();

  await listener.onMessage(data, msg);

  const newHospital = await Employee.findById(data.id);

  expect(newHospital!.userStatus).toEqual(UserStatus.Suspended);
});

it('acks the message', async () => {
  const { listener, data, msg } = await setup();
  await listener.onMessage(data, msg);

  expect(msg.ack).toHaveBeenCalled();
});
