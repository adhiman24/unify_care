import { Message } from 'node-nats-streaming';
import { Listener, UserCreatedEvent, Subjects, PartnerStates, PartnerType, DepartmentType, SpecializationType } from '@unifycare/aem';
import { partnerSuperuserCreatedGroupName } from './queue-group-name';
import { Employee } from '../../models/employee';

export class UserCreatedListener extends Listener<UserCreatedEvent> {
  subject: Subjects.UserCreated = Subjects.UserCreated;
  queueGroupName = partnerSuperuserCreatedGroupName;

  async onMessage(data: UserCreatedEvent['data'], msg: Message) {

    if (data.partnerType === PartnerType.NotApplicable) {
      msg.ack();
      return;
    }

    let employee = await Employee.findById(data.id)

    if (employee) {
      msg.ack();
      return;
    }

    let consultationCharges = 0;

    // Create a candidate  
    employee = Employee.build({
      id: data.id,
      userFirstName: data.userFirstName,
      userLastName: data.userLastName,
      emailId: data.emailId,
      phoneNumber: data.phoneNumber,
      partnerId: data.partnerId,
      userStatus: data.userStatus,
      accessLevel: data.accessLevel,
      userType: data.userType,
      dateOfBirth: 'NA',
      experinceInYears: 0,
      highestQualification: 'NA',
      department: DepartmentType.NonProfessionalServices,
      specialization: SpecializationType.Counseling,
      profileImageName: 'NA',
      designation: 'NA',
      displayProfileImageName: 'NA',
      displayDesignation: 'NA',
      displayQualification: 'NA',
      displayAdditionalInformation: "NA",
      onboardingDate: new Date(),
      consultationChargesInINR: consultationCharges,
    });
    await employee.save();
    // ack the message
    msg.ack();
  }
}
