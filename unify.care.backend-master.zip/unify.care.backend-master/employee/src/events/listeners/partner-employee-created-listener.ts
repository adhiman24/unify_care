import { Listener, PartnerEmployeeCreatedEvent, Subjects, UserType } from '@unifycare/aem';
import { Message } from 'node-nats-streaming';
import { Employee } from '../../models/employee';
import { partnerEmployeeCreatedGroupName } from './queue-group-name';

export class PartnerEmployeeCreatedListener extends Listener<PartnerEmployeeCreatedEvent> {
  subject: Subjects.PartnerEmployeeCreated = Subjects.PartnerEmployeeCreated;
  queueGroupName = partnerEmployeeCreatedGroupName;

  async onMessage(data: PartnerEmployeeCreatedEvent['data'], msg: Message) {
    console.log('PartnerEmployeeCreatedEvent Received for id: ', data.id);

    let employee = await Employee.findById(data.id)

    if (employee) {
      msg.ack();
      return;
    }

    let consultationCharges = 0;
    if (data.userType == UserType.Doctor
      || data.userType == UserType.Educator
      || data.userType == UserType.Nutritionist) {
      consultationCharges = 500;
    }

    // Create a candidate  
    employee = Employee.build({
      id: data.id,
      userFirstName: data.userFirstName,
      userLastName: data.userLastName,
      emailId: data.emailId,
      phoneNumber: data.phoneNumber,
      partnerId: data.partnerId,
      userStatus: data.userStatus,
      accessLevel: data.accessLevel,
      userType: data.userType,
      dateOfBirth: data.dateOfBirth,
      experinceInYears: data.experinceInYears,
      highestQualification: data.highestQualification,
      department: data.department,
      specialization: data.specialization,
      profileImageName: data.profileImageName,
      designation: data.designation,
      displayProfileImageName: data.profileImageName,
      displayDesignation: data.designation,
      displayQualification: data.highestQualification,
      displayAdditionalInformation: "NA",
      onboardingDate: new Date(),
      consultationChargesInINR: consultationCharges,
    });
    await employee.save();

    msg.ack();
  }
}; 
