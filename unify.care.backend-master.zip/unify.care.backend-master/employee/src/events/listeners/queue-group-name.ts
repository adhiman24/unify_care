export const partnerEmployeeStatusChangedGroupName = 'employee-status-change-service';
export const partnerEmployeeCreatedGroupName = 'employee-created-service';
export const partnerSuperuserCreatedGroupName = 'employee-superuser-created-service';
export const databasBackupGroupName = 'employee-database-backup-service';
export const databasUploadGroupName = 'employee-database-upload-service';
