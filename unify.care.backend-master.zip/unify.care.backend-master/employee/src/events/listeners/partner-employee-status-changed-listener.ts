import { Listener, PartnerEmployeeStatusChangedEvent, Subjects } from '@unifycare/aem';
import { Message } from 'node-nats-streaming';
import { Employee } from '../../models/employee';
import { partnerEmployeeStatusChangedGroupName } from './queue-group-name';

export class PartnerEmployeeStatusChangedListener extends Listener<PartnerEmployeeStatusChangedEvent> {
  subject: Subjects.PartnerEmployeeStatusUpdated = Subjects.PartnerEmployeeStatusUpdated;
  queueGroupName = partnerEmployeeStatusChangedGroupName;

  async onMessage(data: PartnerEmployeeStatusChangedEvent['data'], msg: Message) {
    console.log('PartnerEmployeeStatusChangedEvent Received for id: ', data.id);

    const employee = await Employee.findById(data.id);
    if (!employee) {
      msg.ack();
      return;
    }

    employee.set({
      userStatus: data.userStatus,
    });
    await employee.save();

    msg.ack();
  }
}; 
