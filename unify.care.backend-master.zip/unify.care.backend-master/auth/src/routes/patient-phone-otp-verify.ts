import express, { Request, Response } from 'express';
import { body } from 'express-validator';
import jwt from 'jsonwebtoken';
import { validateRequest, BadRequestError, OTPStatus } from '@unifycare/aem';

import { User } from '../models/user-auth';
import { PhoneOTP } from '../models/phone-otp';
import short from 'short-uuid';

const router = express.Router();

router.post(
  '/api/users/phoneotpverify',
  [
    body('phoneNumber')
      .isLength({ min: 10, max: 10 })
      .withMessage('Phone Number must be 10 Digit'),
    body('otp')
      .isLength({ min: 4, max: 4 })
      .withMessage('OTP Number must be 4 Digit'),
  ],
  validateRequest,
  async (req: Request, res: Response) => {
    let { phoneNumber, otp } = req.body;

    const phoneOTP = await PhoneOTP.findOne({ phoneNumber });
    if (!phoneOTP) {
      throw new BadRequestError('Invalid credentials');
    }

    if (phoneOTP.otpStatus === OTPStatus.Valid) {
      if (otp != phoneOTP.otp) {
        throw new BadRequestError('Invalid OTP');
      }
    } else {
      throw new BadRequestError('OTP Expired');
    }
    const token = short.uuid();

    // OTP USES update OTP STATUS
    phoneOTP.set({
      otpStatus: OTPStatus.Used,
      token: token
    });

    await phoneOTP.save();

    res.status(200).send({
      phoneNumber: phoneNumber,
      token: token
    });
  }
);

export { router as phoneVerifyRouter };
