import express, { Request, Response } from 'express';
import { body } from 'express-validator';
import jwt from 'jsonwebtoken';

import {
  validateRequest,
  BadRequestError,
  UserStatus,
  AccessLevel,
  UserType,
  EmailType,
  EmailTemplate,
  EmailDeliveryType,
  PartnerType,
} from '@unifycare/aem';
import { PatientCreatedPublisher } from '../events/publishers/candidate-created-publisher';
import { SendNewEmailPublisher } from '../events/publishers/send-new-email-publisher';
import { natsWrapper } from '../nats-wrapper';
import mongoose from 'mongoose';
import { User } from '../models/user-auth';
import { PhoneOTP } from '../models/phone-otp';

const router = express.Router();


router.post(
  '/api/users/patientsignup',
  [
    body('emailId').isEmail().withMessage('Email must be valid'),
    body('phoneNumber')
      .isLength({ min: 10, max: 10 })
      .withMessage('Phone Number must be 10 Digit'),
  ],
  validateRequest,
  async (req: Request, res: Response) => {

    const {
      userFirstName,
      userLastName,
      emailId,
      phoneNumber,
      age,
      gender,
      token,
      isMobileClient
    } = req.body;

    const id = mongoose.Types.ObjectId().toHexString();
    const partnerId = mongoose.Types.ObjectId().toHexString();
    const lastAuthAt = new Date();
    const userStatus = UserStatus.Verified;
    const userType = UserType.Patient;

    const existingEmailId = await User.findOne({ emailId });

    if (existingEmailId) {
      throw new BadRequestError('Email in use');
    }

    const existingPhoneNumber = await User.findOne({ phoneNumber });
    if (existingPhoneNumber) {
      throw new BadRequestError('Phone Number in use');
    }

    const phoneOTP = await PhoneOTP.findOne({ phoneNumber });
    if (!phoneOTP) {
      throw new BadRequestError('Invalid credentials');
    }

    if (phoneOTP.token !== token) {
      throw new BadRequestError('Invalid Token');
    }

    const user = User.build({
      id,
      userFirstName,
      userLastName,
      emailId,
      phoneNumber,
      password: emailId,
      userType,
      partnerId,
      accessLevel: AccessLevel.Patient,
      lastAuthAt,
      userStatus,
      registrationTimeAndDate: new Date(),
    });
    await user.save();

    // Generate JWT which Expires In 1 hour
    const userJwt = jwt.sign(
      {
        id: user.id,
        emd: user.emailId,
        phn: user.phoneNumber,
        uty: user.userType,
        fid: user.partnerId,
        alv: user.accessLevel,
        ust: user.userStatus,
      },
      process.env.JWT_KEY!, { expiresIn: 60 * 60 }
    );

    if (!isMobileClient) {
      // Store it on session object
      req.session = {
        jwt: userJwt,
      };
      res.status(201).send(user);
    } else {
      const existingUser = {
        id: user.id,
        userFirstName: user.userFirstName,
        userLastName: user.userLastName,
        emailId: user.emailId,
        phoneNumber: user.phoneNumber,
        userType: user.userType,
        partnerId: user.partnerId,
        token: userJwt
      };
      res.status(201).send(existingUser);
    }

    //////// Publish New User Create Event
    new PatientCreatedPublisher(natsWrapper.client).publish({
      id: user.id,
      userFirstName: user.userFirstName,
      userLastName: user.userLastName,
      emailId: user.emailId,
      phoneNumber: user.phoneNumber,
      partnerId: user.partnerId,
      dateOfBirth: age,
      gender: gender,
    });

    //////// Send Email to  New User 
    new SendNewEmailPublisher(natsWrapper.client).publish({
      to: user.emailId,
      from: 'ashutosh@rufous.com',
      subject: 'Hello from Unify Care',
      body: '<h1>Welcome from Unify Care</h1>',
      emailType: EmailType.HtmlText,
      emailTemplate: EmailTemplate.NoTemplate,
      emaiDeliveryType: EmailDeliveryType.Immediate,
      atExactTime: new Date()
    });
  });

export { router as patientSignupRouter };
