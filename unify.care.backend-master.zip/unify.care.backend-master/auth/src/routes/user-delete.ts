import express, { Request, Response } from 'express';
import { body } from 'express-validator';
import {
  validateRequest,
  BadRequestError
} from '@unifycare/aem';

import { User } from '../models/user-auth';

const router = express.Router();

router.post(
  '/api/users/deletebyemail',
  [
    body('emailId').isEmail().withMessage('Email must be valid'),
  ],
  validateRequest,
  async (req: Request, res: Response) => {
    const { emailId } = req.body;

    await User.findOneAndDelete({ emailId });

    res.status(200).send({ message: 'User deleted' });
  }
);

export { router as deleteByEmailRouter };
