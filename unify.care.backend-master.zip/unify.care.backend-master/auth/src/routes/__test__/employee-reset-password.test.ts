import request from 'supertest';
import { app } from '../../app';
import { UserStatus, UserType } from '@unifycare/aem';
import { User } from '../../models/user-auth';
import mongoose from 'mongoose';
import jwt from 'jsonwebtoken';

it('fails when no password is provided', async () => {

  await request(app).post(`/api/users/resetpassword`)
    .send({
      key: 'key'
    })
    .expect(400);
});

it('fails when empty password is provided', async () => {

  await request(app).post(`/api/users/resetpassword`)
    .send({
      password: '',
      key: 'key'
    })
    .expect(400);
});

it('fails when invalid password is provided', async () => {

  await request(app).post(`/api/users/resetpassword`)
    .send({
      password: '1234',
      key: 'key'
    })
    .expect(400);
});

it('fails when no key is provided', async () => {

  await request(app).post(`/api/users/resetpassword`)
    .send({
      password: 'password'
    })
    .expect(400);
});

it('fails when empty key is provided', async () => {

  await request(app).post(`/api/users/resetpassword`)
    .send({
      password: 'password',
      key: ''
    })
    .expect(400);
});

it('fails when provided key does not exists', async () => {

  const id = new mongoose.Types.ObjectId().toHexString();

  //create token for email verification
  const verificationKey = jwt.sign(
    {
      id: id,
    },
    process.env.JWT_KEY!, { expiresIn: 60 * 60 }
  );

  await request(app).post(`/api/users/resetpassword`)
    .send({
      password: 'password',
      key: verificationKey
    })
    .expect(400);
});

it('responds with 200 when given valid key credentials', async () => {

  let user = await User.find({});
  expect(user.length).toEqual(0);

  await request(app)
    .post('/api/users/partnersignup')
    .send({
      userFirstName: 'Ashutosh',
      userLastName: 'Dhiman',
      emailId: 'test@test.com',
      phoneNumber: '6666666666',
      password: 'password',
      userType: UserType.PartnerSuperuser,
    })
    .expect(201);

  user = await User.find({});
  expect(user.length).toEqual(1);
  expect(user[0].userStatus).toEqual(UserStatus.Unverified);

  //create token for email verification
  const verificationKey = jwt.sign(
    {
      id: user[0].id,
    },
    process.env.JWT_KEY!, { expiresIn: 60 * 60 }
  );

  await request(app).get(`/api/users/emailverification/${verificationKey}`)
    .send()
    .expect(200);

  user = await User.find({});
  expect(user.length).toEqual(1);
  expect(user[0].userStatus).toEqual(UserStatus.Verified);

  await request(app).post(`/api/users/resetpassword`)
    .send({
      password: 'password',
      key: verificationKey
    })
    .expect(200);
});
