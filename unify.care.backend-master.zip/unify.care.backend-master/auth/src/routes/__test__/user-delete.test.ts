import request from 'supertest';
import { app } from '../../app';
import { UserStatus, UserType } from '@unifycare/aem';
import { User } from '../../models/user-auth';


it('responds with 200 when given valid credentials', async () => {

  let user = await User.find({});
  expect(user.length).toEqual(0);

  await request(app)
    .post('/api/users/partnersignup')
    .send({
      userFirstName: 'Ashutosh',
      userLastName: 'Dhiman',
      emailId: 'test@test.com',
      phoneNumber: '6666666666',
      password: 'password',
      userType: UserType.PartnerSuperuser,
      agreePolicy: true,
    })
    .expect(201);

  user = await User.find({});
  expect(user.length).toEqual(1);
  expect(user[0].userStatus).toEqual(UserStatus.Unverified);

  await request(app).post(`/api/users/deletebyemail`)
    .send({
      emailId: 'test@test.com'
    })
    .expect(200);

  user = await User.find({});
  expect(user.length).toEqual(0);
});
