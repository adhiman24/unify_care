import express, { Request, Response } from 'express';
import { body } from 'express-validator';
import jwt from 'jsonwebtoken';
import { validateRequest, BadRequestError, OTPStatus } from '@unifycare/aem';

import { User } from '../models/user-auth';
import { PhoneOTP } from '../models/phone-otp';

const router = express.Router();

router.post(
  '/api/users/phoneotpsignin',
  [
    body('phoneNumber')
      .isLength({ min: 10, max: 10 })
      .withMessage('Phone Number must be 10 Digit'),
    body('otp')
      .isLength({ min: 4, max: 4 })
      .withMessage('OTP Number must be 4 Digit'),
  ],
  validateRequest,
  async (req: Request, res: Response) => {
    let { phoneNumber, otp, isMobileClient } = req.body;

    const phoneOTP = await PhoneOTP.findOne({ phoneNumber });
    if (!phoneOTP) {
      throw new BadRequestError('Invalid credentials');
    }

    if (phoneOTP.otpStatus === OTPStatus.Valid) {
      if (otp != phoneOTP.otp) {
        throw new BadRequestError('Invalid OTP');
      }
    } else {
      throw new BadRequestError('OTP Expired');
    }

    // OTP USES update OTP STATUS
    phoneOTP.set({
      otpStatus: OTPStatus.Used,
    });

    await phoneOTP.save();
    ///////////////////////////////// 

    const existingUser = await User.findOne({ phoneNumber });
    if (!existingUser) {
      throw new BadRequestError('Invalid credentials');
    }

    existingUser.set({
      lastAuthAt: new Date(),
    });

    await existingUser.save();


    // Generate JWT which Expires In 1 hour
    const userJwt = jwt.sign(
      {
        id: existingUser.id,
        emd: existingUser.emailId,
        phn: existingUser.phoneNumber,
        uty: existingUser.userType,
        fid: existingUser.partnerId,
        alv: existingUser.accessLevel,
        ust: existingUser.userStatus,
      },
      process.env.JWT_KEY!, { expiresIn: 60 * 60 }
    );

    if (!isMobileClient) {
      // Store it on session object
      req.session = {
        jwt: userJwt,
      };
      res.status(200).send(existingUser);
    } else {
      const user = {
        id: existingUser.id,
        userFirstName: existingUser.userFirstName,
        userLastName: existingUser.userLastName,
        emailId: existingUser.emailId,
        phoneNumber: existingUser.phoneNumber,
        userType: existingUser.userType,
        partnerId: existingUser.partnerId,
        token: userJwt
      };
      res.status(200).send(user);
    }
  }
);

export { router as phoneSigninRouter };
