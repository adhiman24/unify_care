import express, { Request, Response } from 'express';
import { body } from 'express-validator';
import jwt from 'jsonwebtoken';
import { validateRequest, BadRequestError, UserStatus, NotVerifiedError } from '@unifycare/aem';

import bcrypt from 'bcrypt';
import { User } from '../models/user-auth';

const router = express.Router();

router.post(
  '/api/users/employeesignin',
  [
    body('emailId').isEmail().withMessage('Email must be valid'),
    body('password').trim()
      .notEmpty()
      .isLength({ min: 6, max: 20 })
      .withMessage('Password must be 6 character or more'),
  ],
  validateRequest,
  async (req: Request, res: Response) => {
    const { emailId, password } = req.body;

    const existingUser = await User.findOne({ emailId });
    if (!existingUser) {
      console.log("email not found: " + emailId);
      throw new BadRequestError('Invalid credentials');
    }

    if (existingUser.userStatus === UserStatus.Unverified) {
      // throw new NotVerifiedError();
    }

    await bcrypt.compare(password, existingUser.password).then(function (result) {
      if (!result) {
        throw new BadRequestError('Invalid credentials');
      }
    });

    existingUser.set({
      lastAuthAt: new Date(),
    });
    await existingUser.save();


    // Generate JWT which Expires In 1 hour
    const userJwt = jwt.sign(
      {
        id: existingUser.id,
        emd: existingUser.emailId,
        phn: existingUser.phoneNumber,
        uty: existingUser.userType,
        fid: existingUser.partnerId,
        alv: existingUser.accessLevel,
        ust: existingUser.userStatus,
      },
      process.env.JWT_KEY!, { expiresIn: 12 * 60 * 60 }
    );

    // Store it in session object.....
    req.session = {
      jwt: userJwt,
    };

    const user = {
      id: existingUser.id,
      userFirstName: existingUser.userFirstName,
      userLastName: existingUser.userLastName,
      emailId: existingUser.emailId,
      phoneNumber: existingUser.phoneNumber,
      userType: existingUser.userType,
      partnerId: existingUser.partnerId,
      token: userJwt
    };

    res.status(200).send(user);
  }
);

export { router as employeeSigninRouter };
