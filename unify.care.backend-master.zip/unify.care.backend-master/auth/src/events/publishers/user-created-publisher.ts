import { Publisher, Subjects, UserCreatedEvent } from '@unifycare/aem';

export class UserCreatedPublisher extends Publisher<UserCreatedEvent> {
  subject: Subjects.UserCreated = Subjects.UserCreated;
}
