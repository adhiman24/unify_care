import { Publisher, Subjects, sendNewEmailEvent } from '@unifycare/aem';

export class SendNewEmailPublisher extends Publisher<sendNewEmailEvent> {
  subject: Subjects.SendNewEmail = Subjects.SendNewEmail;
}
