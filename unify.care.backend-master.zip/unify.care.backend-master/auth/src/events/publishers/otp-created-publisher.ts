import { Publisher, Subjects, OTPCreatedEvent } from '@unifycare/aem';

export class OTPCreatedPublisher extends Publisher<OTPCreatedEvent> {
  subject: Subjects.OTPCreated = Subjects.OTPCreated;
}
