import { Publisher, Subjects, PatientCreatedEvent } from '@unifycare/aem';

export class PatientCreatedPublisher extends Publisher<PatientCreatedEvent> {
  subject: Subjects.PatientCreated = Subjects.PatientCreated;
}
