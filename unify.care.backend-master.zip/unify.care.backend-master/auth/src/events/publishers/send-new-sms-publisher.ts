import { Publisher, Subjects, sendNewSMSEvent } from '@unifycare/aem';

export class SendNewSMSPublisher extends Publisher<sendNewSMSEvent> {
  subject: Subjects.SendNewSMS = Subjects.SendNewSMS;
}
