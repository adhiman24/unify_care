export const otpExpiredGroupName = 'otp-expire-service';
export const patientStatusChangedGroupName = 'patient-status-changed-service';
export const partnerEmployeeStatusChangedGroupName = 'partner-employee-status-changed-service';
export const partnerEmployeeCreatedGroupName = 'partner-employee-created-service';
export const partnerSuperuserStatusChangedGroupName = 'partner-superuser-status-changed-service';
export const databasBackupGroupName = 'auth-database-backup-service';
export const databasUploadGroupName = 'auth-database-upload-service';
