import { Message } from 'node-nats-streaming';
import { Listener, DatabaseBackupEvent, Subjects } from '@unifycare/aem';
import { databasBackupGroupName } from './queue-group-name';

var backup = require('mongodb-backup');
var fs = require('fs');

export class DatabaseBackupListener extends Listener<DatabaseBackupEvent> {
  subject: Subjects.DatabaseBackup = Subjects.DatabaseBackup;
  queueGroupName = databasBackupGroupName;

  async onMessage(data: DatabaseBackupEvent['data'], msg: Message) {

    //It's time taking job so ack msg as soon as it is received
    msg.ack();

    var dataBackupDir = data.localBackupDirectory;

    try {
      if (!fs.existsSync(dataBackupDir)) {
        // Create the directory if it does not exist
        fs.mkdirSync(dataBackupDir);
      }
    } catch (err) {
      console.error(err)
      return;
    }

    const backupFileName = data.backupFilePrifix + process.env.DATABACKUP_TAR_FILENAME;

    //Create Dump File of MongoDB Database
    await backup({
      uri: process.env.MONGO_URI,
      root: dataBackupDir,
      tar: backupFileName,
      callback: function (err: Error) {
        if (err) {
          console.error(err);
        } else {
          console.log('Backup file created : ' + backupFileName);
        }
      }
    });
  }
}
