import express from 'express';
import 'express-async-errors';
import swaggerUi from 'swagger-ui-express';
import { swaggerDocument } from './swagger'
import { json } from 'body-parser';
import cookieSession from 'cookie-session';
import { errorHandler, NotFoundError, currentUser } from '@unifycare/aem';
import { loggerMiddleware, winstonMiddleware } from '@unifycare/logger';

import { currentUserRouter } from './routes/current-user';
import { emailSigninRouter } from './routes/email-otp-signin';
import { employeeEmailVerificationRouter } from './routes/employee-email-verification';
import { employeeForgotPasswordRouter } from './routes/employee-forgot-password';
import { employeeSigninRouter } from './routes/employee-pwd-signin';
import { employeeResetPasswordRouter } from './routes/employee-reset-password';
import { partnerOtpSignupRouter } from './routes/partner-otp-signup';
import { partnerSignupRouter } from './routes/partner-signup';
import { patientOTPSignupRouter } from './routes/patient-otp-signup';
import { phoneSigninRouter } from './routes/patient-phone-otp-signin';
import { patientSignupRouter } from './routes/patient-signup';
import { phoneVerifyRouter } from './routes/patient-phone-otp-verify';
import { sendEmailOTPRouter } from './routes/send-email-otp';
import { sendPhoneEmailOTPRouter } from './routes//send-phone-email-otp';
import { sendPhoneOTPRouter } from './routes/send-phone-otp';
import { sendVerificationEmailRouter } from './routes/send-verification-email';
import { signoutRouter } from './routes/signout';
import { deleteByEmailRouter } from './routes/user-delete';

var cors = require('cors')

const app = express();

app.use(cors({ credentials: true, origin: 'http://localhost:3000' }));

app.set('trust proxy', true);
app.use(json());
app.use(
  cookieSession({
    signed: false,
    secure: process.env.NODE_ENV !== 'test',
    //secure: false,
  })
);

app.use(currentUser);

app.use(loggerMiddleware);
app.use(winstonMiddleware);
app.use('/api/users/swagger', swaggerUi.serve, swaggerUi.setup(swaggerDocument));
app.use(currentUserRouter);
app.use(emailSigninRouter);
app.use(phoneSigninRouter);
app.use(signoutRouter);
app.use(patientSignupRouter);
app.use(sendEmailOTPRouter);
app.use(sendPhoneEmailOTPRouter);
app.use(sendPhoneOTPRouter);
app.use(partnerSignupRouter);
app.use(partnerOtpSignupRouter);
app.use(employeeResetPasswordRouter);
app.use(employeeSigninRouter);
app.use(employeeForgotPasswordRouter);
app.use(employeeEmailVerificationRouter);
app.use(deleteByEmailRouter);
app.use(sendVerificationEmailRouter);
app.use(phoneVerifyRouter);
app.use(patientOTPSignupRouter);

app.all('*', async (req, res) => {
  throw new NotFoundError();
});

app.use(errorHandler);
export { app };
