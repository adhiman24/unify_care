import express from 'express';
import { Storage } from '@google-cloud/storage';

const router = express.Router();

// Creates a client
const storage = new Storage({ keyFilename: "key.json" });

router.get('/api/file-manager/download/:fileName', async (req,
  res) => {

  const bucketName = 'gamma-unify-care-bucket-1';

  const fileName = req.params.fileName;

  storage.bucket(bucketName).file(fileName).createReadStream()
    .on('error', function (err) {
      console.log('error Called: ' + err);
    })
    .on('response', function (response) {
      // Server connected and responded with the specified status and headers.
      console.log('response Called: ' + response);
    })
    .on('end', function () {
      // The file is fully downloaded.
    })
    .pipe(res);

  res.status(200);
});

export { router as downloadFileRouter };