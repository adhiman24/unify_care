import { servicesVersion } from "typescript";

export const partnerSuperuserCreatedGroupName = 'partner-superuser-created-service';

export const databasBackupGroupName = 'file-manager-database-backup-servicesVersion';

export const databasUploadGroupName = 'file-manager-database-upload-servicesVersion';
