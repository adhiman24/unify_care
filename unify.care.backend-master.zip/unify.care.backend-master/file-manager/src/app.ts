import express from 'express';
import 'express-async-errors';
import { json } from 'body-parser';
import cookieSession from 'cookie-session';
import { errorHandler, NotFoundError, currentUser } from '@unifycare/aem';
import { loggerMiddleware, winstonMiddleware } from '@unifycare/logger';
import { uploadFileRouter } from './routes/upload_file_to_cdn';
import { downloadFileRouter } from './routes/download_file_from_cdn';

var cors = require('cors')

const app = express();

app.use(cors({ credentials: true, origin: 'http://localhost:3000' }));

app.set('trust proxy', true);
app.use(json());
app.use(
  cookieSession({
    signed: false,
    secure: process.env.NODE_ENV !== 'test',
    //secure: false,

  })
);
app.use(currentUser);

app.use(loggerMiddleware);
app.use(winstonMiddleware);

app.use(uploadFileRouter);
app.use(downloadFileRouter);

app.all('*', async (req, res) => {
  throw new NotFoundError();
});

app.use(errorHandler);

export { app };
