import axios from 'axios';
import React, { useState } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import { Alert, AlertTitle } from '@material-ui/lab';

const useStyles = makeStyles((theme) => ({
  root: {
    width: '100%',
    '& > * + *': {
      marginTop: theme.spacing(2),
    },
  },
}));


const DoRequest = ({ url, method, body, onSuccess }) => {
  const classes = useStyles();
  const [errors, setErrors] = useState(null);
  const [errorMessage, setErrorMessage] = useState(null);

  const doRequest = async (props = {}) => {
    try {
      setErrors(null);
      const response = await axios[method](url, { ...body, ...props, withCredentials: true });

      console.log(response)

      if (onSuccess) {
        onSuccess(response.data);
      }

      return response.data;
    } catch (error) {
      setErrors(

        <div className={classes.root}>
          <Alert severity="error">
            <AlertTitle>Error</AlertTitle>
            <ul className="my-0">
              {error && error.response && error.response.data && error.response.data.errors && error.response.data.errors.map((err) => (
                <li key={err.message}>{err.message}</li>
              ))}
            </ul>
          </Alert>
        </div>
      );
      if (error && error.response && error.response.data && error.response.data.errors && error.response.data.errors.length) {
        console.log(error.response.data.errors[0].message);
        setErrorMessage(error.response.data.errors[0].message);
      }
    }
  };

  return { doRequest, errors, errorMessage };
};

export default DoRequest;