const config = {
   //API_URL: "https://unify.care",
   API_URL: ""
};

export default config;