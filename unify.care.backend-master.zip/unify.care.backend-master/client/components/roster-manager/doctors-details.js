import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import TextField from '@material-ui/core/TextField';
import time from '../../data/time.json';
import days from '../../data/day.json';
import Calendar from 'react-calendar';
import CircularProgress from '@material-ui/core/CircularProgress';
import { useAlert, types } from 'react-alert';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogTitle from '@material-ui/core/DialogTitle';
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import config from '../../app.constant';
import {useCookies } from "react-cookie";
import Button from '@material-ui/core/Button';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import CalanderSection from '../roster-manager/calender-section'
function DoctorsDetails(props){
    // console.log("props: ",props)
    let doctorSelected =props.doctorSelected;  
    // console.log("doctorSelected: ",doctorSelected);
    const [consltFee,setConsltFee] = useState('');
    const [currency, setCurrency] = useState('INR');
    const [timing, setTiming] = useState([]);
    const [date, setDate] = useState(new Date());
    // const [doctorSelected, setDoctorSelected] = useState([{}]);
    // const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    const [selectedDay, setSelectedDay] = useState(new Date().getDay());
    const [responseData, setResponseData] = useState([]);
    const [slotSelectedDay, setSlotSelectedDay] = useState([]);
    const [loader, setLoader] = useState(false);
    const [cookies, getCookie] = useCookies(['name']);
    const alert = useAlert();
   
    useEffect(()=>{
        if(doctorSelected.id !== undefined){
            fetchTimeslot(doctorSelected.id);
            setConsltFee(doctorSelected.consultationChargesInINR)

            // onDateChange(new Date());
        }
    },[doctorSelected])
   
    const fetchTimeslot = (id) =>{
        // console.log("id",id); 
        let cookie = ''
        for (const [key, value] of Object.entries(cookies)) {
           if(key === 'express:sess'){
              cookie = value;
           }
        }
        let headers = {
           'authtoken': cookie
        }
        let obj={
           consultantId: id
        }
        setLoader(true);
        axios.get(config.API_URL + `/api/appointment/slotstimetable/${id}`, {headers})
        .then(response => {
        //    console.log('Fetch Time slots: ',response.data)
           if(response.data){
              setResponseData(response.data);
              let WorkingTmpArray = [];
                  days.forEach((item) => {
                    let obj = {};
                    obj.id = item.id;
                    obj.day = item.day;
                    obj.checked = false;
                    obj.timeSlot=[{timeFrom:'', timeTo:''}]
                 
                 //   let dInd;
                    if(response.data && response.data.mondayAvailableSlotList.length > 0 && item.day =='Monday'){
                       obj.checked = true;
                       obj.timeSlot = showTimeSlot(response.data.mondayAvailableSlotList);
                    }
                    if(response.data && response.data.tuesdayAvailableSlotList.length > 0 && item.day =='Tuesday'){
                       obj.checked = true;
                       obj.timeSlot = showTimeSlot(response.data.tuesdayAvailableSlotList);
                    } 
                    if(response.data && response.data.wednesdayAvailableSlotList.length > 0 && item.day =='Wednesday'){
                       obj.checked = true;
                       obj.timeSlot = showTimeSlot(response.data.wednesdayAvailableSlotList);
                    }
                    if(response.data && response.data.thursdayAvailableSlotList.length > 0 && item.day =='Thursday'){
                       obj.checked = true;
                       obj.timeSlot = showTimeSlot(response.data.thursdayAvailableSlotList);
                    } 
                    if(response.data && response.data.fridayAvailableSlotList.length > 0 && item.day =='Friday'){
                       obj.checked = true;
                       obj.timeSlot = showTimeSlot(response.data.fridayAvailableSlotList);
                    }
                    if(response.data && response.data.saturdayAvailableSlotList.length > 0 && item.day =='Saturday'){
                       obj.checked = true;
                       obj.timeSlot = showTimeSlot(response.data.saturdayAvailableSlotList);
                    }
                    if(response.data && response.data.sundayAvailableSlotList.length > 0 && item.day =='Sunday'){
                       obj.checked = true;
                       obj.timeSlot = showTimeSlot(response.data.sundayAvailableSlotList);
                    } 
  
                    WorkingTmpArray.push(obj);
                  });
                 //  console.log("WorkingTmpArray: ",WorkingTmpArray)
                  setTiming(WorkingTmpArray);
           }else{
              setTiming(emptyTimeArr());
              setResponseData([]);
           }
           setLoader(false);
        })
        .catch(error => {
           // alert.show('Api error', { type: 'error' });
           setTiming(emptyTimeArr());
           setResponseData([]);
           console.log(error);
           setLoader(false);
        });
    }

    const timeData = time;
    function showTimeSlot(arr){
        let newTimeSlot = [];
        let st; let end;
        st= parseInt(arr[0]);
        
        for( let i = 0; i<arr.length; i++){
            let obj = {};
            if((parseInt(arr[i])+1) != parseInt(arr[i+1])){
                end= parseInt(arr[i]) +1;
                timeData.map((item)=>{
                if(item.value==st){
                    obj.timeFrom = item.label;
                }
                if(item.value==end){
                    obj.timeTo = item.label;
                }
                })
                newTimeSlot.push(obj);
                st = parseInt(arr[i+1])
                
            }
        }
        return newTimeSlot;
    }

    const DEFAULT_FROM_TIME = '';
    const DEFAULT_TO_TIME = '';
    
    
    function emptyTimeArr(){
        const WorkingTimeArray = [];
        days.forEach((item) => {
            let obj = {};
            obj.id = item.id;
            obj.day = item.day;
            obj.timeSlot=[{timeFrom: DEFAULT_FROM_TIME,timeTo: DEFAULT_TO_TIME}]
            //  obj.timeFrom = DEFAULT_FROM_TIME;
            //  obj.timeTo = DEFAULT_TO_TIME;
            obj.checked = false;
            WorkingTimeArray.push(obj);
        });
        return WorkingTimeArray;
    }
    useEffect(() => {
        setTiming(emptyTimeArr());
    }, []);

    function changeTimeSlotDay(day){
        if(responseData.id != undefined){
            if(day==1){
                setSlotSelectedDay(showTimeSlot(responseData.mondayAvailableSlotList));
            }
            if(day==2){
                setSlotSelectedDay(showTimeSlot(responseData.tuesdayAvailableSlotList));
            } 
            if(day==3){
                setSlotSelectedDay(showTimeSlot(responseData.wednesdayAvailableSlotList));
            } 
            if(day==4){
                setSlotSelectedDay(showTimeSlot(responseData.thursdayAvailableSlotList));
            } 
            if(day==5){
                setSlotSelectedDay(showTimeSlot(responseData.fridayAvailableSlotList));
            } 
            if(day==6){
                setSlotSelectedDay(showTimeSlot(responseData.saturdayAvailableSlotList));
            }
            if(day==0){
                setSlotSelectedDay(showTimeSlot(responseData.sundayAvailableSlotList));
            }
        }else{
            // console.log("in else: ",responseData);
            setSlotSelectedDay([])
        }
    }
    useEffect(()=>{
        changeTimeSlotDay(date.getDay())
    },[responseData]);
    const onWorkTimeChange = (index, type, value,id) => {
        let currentWorkTime = [...timing];
        if (type === 'DAY') {
            //  currentWorkTime[index].checked = !currentWorkTime[index].checked;
            currentWorkTime[id -1].checked = !currentWorkTime[id -1].checked;
        } else if (type === 'FROM_TIME') {
            currentWorkTime[id -1].timeSlot[index].timeFrom = value;
            //  currentWorkTime[index].timeFrom = value;
        } else if (type === 'TO_TIME') {
            currentWorkTime[id -1].timeSlot[index].timeTo = value;
            //  currentWorkTime[index].timeTo = value;
        }
        // console.log('currentWorkTime: ',currentWorkTime)
        setTiming(currentWorkTime);
    };

    const handleAddSlot = (i,item) =>{
        // e.preventDefault();
        const values = [...timing];
        values[i].timeSlot.push({timeFrom:'',timeTo:''})
        setTiming(values);
    }

    const handleRemoveSlot = (index,itemId) =>{
        // e.preventDefault();
        console.log("i ",index);
        //   console.log("item ",item);
        console.log("itemid ",itemId);
        const values = [...timing];
        console.log('values: ',values)
        values[itemId-1].timeSlot.splice(index, 1);
        setTiming(values);
    }
    const saveSchedule = () => {
        // console.log("saveSchedule clicked",timing,doctorSelected.id);
        let obj = {};
        obj.consultantId = doctorSelected.id ;
        let flag = false;
        timing.forEach((item)=>{
            // console.log("item chacked: ",item.checked);
            if(item.checked == true){
                flag = true;
            }
        })
        if(flag == false){
            alert('Please Select Time Schedule');
            return false;
        }
        if(timing[0].checked===true){
            obj.mondayAvailableSlotList = fetchSlotFromArr(timing[0].timeSlot);
        }else{
            obj.mondayAvailableSlotList = [];
        }

        if(timing[1].checked===true){
            obj.tuesdayAvailableSlotList = fetchSlotFromArr(timing[1].timeSlot);
        }else{
            obj.tuesdayAvailableSlotList = [];
        } 

        if(timing[2].checked===true){
            obj.wednesdayAvailableSlotList = fetchSlotFromArr(timing[2].timeSlot);
        }else{
            obj.wednesdayAvailableSlotList = [];
        } 

        if(timing[3].checked===true){
            obj.thursdayAvailableSlotList = fetchSlotFromArr(timing[3].timeSlot);
        }else{
            obj.thursdayAvailableSlotList = [];
        }

        if(timing[4].checked===true){
            obj.fridayAvailableSlotList = fetchSlotFromArr(timing[4].timeSlot);
        }else{
            obj.fridayAvailableSlotList = [];
        }

        if(timing[5].checked===true){
            obj.saturdayAvailableSlotList = fetchSlotFromArr(timing[5].timeSlot);
        }else{
            obj.saturdayAvailableSlotList = [];
        }

        if(timing[6].checked===true){
            obj.sundayAvailableSlotList = fetchSlotFromArr(timing[6].timeSlot);
        }else{
            obj.sundayAvailableSlotList = [];
        }


        let cookie = ''
        for (const [key, value] of Object.entries(cookies)) {
            if(key === 'express:sess'){
                cookie = value;
            }
        }
        let headers = {
            'authtoken': cookie
        }
        console.log("obj : ",obj);
        console.log("consult fee :",consltFee);
        // return false;
        setLoader(true);
        axios
            .put(config.API_URL + '/api/employee/consultationcharge', {consultantId: doctorSelected.id, consultationCharge: consltFee}, {headers})
            .then((response) => {
                console.log(response.data);
                // fetchData();
                // setLoader(false);
                props.consultFeeUpdate(consltFee);
            })
            .catch((error) => {
                // setLoader(false);
                alert.show(error.response.data.errors[0].message, { type: 'error' });
                console.log(error);
            });

        axios
            .post(config.API_URL + '/api/appointment/slotstimetable', obj, {headers})
            .then((response) => {
                console.log(response.data);
                fetchTimeslot(doctorSelected.id)
                setLoader(false);
                alert.show('Roster Updated', { type: 'success' });
            })
            .catch((error) => {
                setLoader(false);
                alert.show(error.response.data.errors[0].message, { type: 'error' });
                console.log(error);
            });

    }
    function fetchSlotFromArr(arr){
        let newArr =[];
        let st; let end;
        for (let i=0; i<arr.length; i++){
            timeData.map((val)=> {
                // console.log('valujj',i)
                if(val.label == arr[i].timeFrom){
                st = val.value;
                // console.log("vlaue: ", val.value);
                }
                if(val.label == arr[i].timeTo){
                end = val.value;
                // console.log("vlaue: ", val.value);
                }
            })
            for(let j =st; j < end; j++){
                if(newArr.indexOf(j) === -1) {
                newArr.push(j);;
            }
            
            
            }
        }
        return newArr;
    }
    
    return(
        <>
         {loader && <div className="loader"><CircularProgress color="secondary" /><div className="text"></div></div>}
        {doctorSelected.userFirstName ?
            <div className='centerItem'>
               <div className='docname'>
                  <span style={{fontWeight:'bold'}} >{doctorSelected.userFirstName + " "+ doctorSelected.userLastName} </span>
               </div>
               <div className='consultation'>
                  <div className='constText'>Consultation Fee: </div>
                  <TextField
                     // select
                     label=""
                     // fullWidth
                     className='feeField'
                     style={{borderRight:'1px solid #545454', marginLeft:'4%'}}
                     size="small"
                     variant="filled"
                     value={consltFee}
                     onChange={(e) => {
                        setConsltFee(e.target.value)
                     }}
                     >
                  </TextField>
                  <TextField
                     select
                     label=""
                     className='feeField'
                     // fullWidth
                     size="small"
                     variant="filled"
                     // margin='normal'
                     value={currency}
                     onChange={(e) => {
                        
                     }}>
                        <MenuItem value='INR'>INR</MenuItem>
                  </TextField>
               </div>
               <div className="slotPreferenceTime">
                  {timing.map((item, index) => { return(
                        <div
                        key={item.day}
                        style={{
                              display: 'flex',
                              // alignItems: 'center',
                              paddingBottom: '3px',
                              verticalAlign: top,
                        }}
                        >
                        <div style={{ width: '25%', verticalAlign: 'top', marginTop: '15px'}}>
                              <FormControlLabel
                                 control={
                                    <Checkbox
                                          checked={
                                             item.checked 
                                          }
                                          onChange={(e) =>
                                             onWorkTimeChange(
                                                index,
                                                'DAY',
                                                !item.checked,
                                                item.id
                                             )
                                          }
                                    />
                                 }
                                 label={item.day}
                              />
                        </div>
                        <div
                              style={{
                                 width: '12%',
                                 color: '#555555',
                                 fontSize: '14px',
                                 margin: 'auto',
                                 marginTop: '30px'
                              }}>
                              Time:
                        </div>
                        <div style={{width:'62%'}}>
                           {item.timeSlot.map((i,index)=>{
                              return(
                              <div style={{width:'100%', marginTop:'10px'}} key={index} >
                                 <div
                                    style={{
                                       width: '38%',
                                       margin: 'auto auto auto 5px',
                                       float: 'left',
                                       marginRight:'10px'
                                    }}>
                                    <TextField
                                       disabled={
                                          !(item.checked)
                                       }
                                       select
                                       size="small"
                                       label="From"
                                       style={{marginBottom:'10px'}}
                                       defaultValue={DEFAULT_FROM_TIME}
                                       fullWidth
                                       variant="filled"
                                       value={i.timeFrom}
                                       onChange={(e) => {
                                          onWorkTimeChange(
                                                index,
                                                'FROM_TIME',
                                                e.target.value,
                                                item.id
                                          );
                                       }}>
                                       {timeData.map((elm) => {
                                          return (
                                                <MenuItem
                                                   value={elm.label}
                                                   key={elm.id}>
                                                   {elm.label}
                                                </MenuItem>
                                          );
                                       })}
                                    </TextField>
                                 </div>
                                 <div
                                    style={{
                                       width: '38%',
                                       margin: 'auto auto auto 5px',
                                       float: 'left',
                                       marginRight:'10px'
                                    }}>
                                    <TextField
                                       disabled={
                                          !(item.checked)
                                       }
                                       defaultValue={DEFAULT_TO_TIME}
                                       select
                                       label="To"
                                       style={{marginBottom:'10px'}}
                                       fullWidth
                                       size="small"
                                       variant="filled"
                                       value={i.timeTo}
                                       onChange={(e) => {
                                          onWorkTimeChange(
                                                index,
                                                'TO_TIME',
                                                e.target.value,
                                                item.id
                                          );
                                       }}>
                                       {timeData.map((element) => {
                                          return (
                                                <MenuItem
                                                   value={element.label}
                                                   key={element.id}>
                                                   {element.label}
                                                </MenuItem>
                                          );
                                       })}
                                    </TextField>
                                 </div>
                                 {index > 0 && (
                                 <button
                                    className="removeIcon"
                                    type="button"
                                    onClick={() => handleRemoveSlot(index,item.id)}
                                 >
                                    <span className="minusLine"></span>
                                 </button>
                                 )}
                              </div>
                           )})}

                        </div>
                           
                           <div className='plusBtn' onClick={()=>handleAddSlot(index,item)}>
                              <span>+</span>
                           </div>
                        </div>
                     
                     );
                  })}
               </div>
               <div className="action">
                  <Button 
                     size="small" 
                     variant="contained" 
                     color="secondary" 
                     className="primary-button forward" 
                     style={{color:'#000', width:'125px'}}
                     onClick={saveSchedule}
                  >Save</Button>
               </div>
            </div>
            :''}
            <CalanderSection responseData={responseData} doctorSelected={doctorSelected} />
        </>
    )
}
export default DoctorsDetails;