import Calendar from 'react-calendar';
import CircularProgress from '@material-ui/core/CircularProgress';
import { useAlert, types } from 'react-alert';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogTitle from '@material-ui/core/DialogTitle';
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import config from '../../app.constant';
import {useCookies } from "react-cookie";
import time from '../../data/time.json';
import Button from '@material-ui/core/Button';
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';
import moment from 'moment';
function CalanderSection(props){
    // console.log("props: ",props);
    let responseData = props.responseData;
    let doctorSelected = props.doctorSelected;
    const [selectedDay, setSelectedDay] = useState(new Date().getDay());
    const [slotSelectedDay, setSlotSelectedDay] = useState([]);
    const timeData = time;
    const [date, setDate] = useState(new Date());
    const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    const [cookies, getCookie] = useCookies(['name']);
    const [loader, setLoader] = useState(false);
    const alert = useAlert();
    const [leaveDayArr, setLeaveDayArr] = useState([]);
    const [leaveBtnFlag, setLeaveBtnFlag] = useState('show');
    const onDateChange = (date) =>{
        setDate(date);
        setSelectedDay(date.getDay());
        changeTimeSlotDay(date.getDay())
        if(doctorSelected.id !== undefined){
            checkSlotOnselectedday(date);
        }
        let temp = leaveDayArr.indexOf(changeDateFormat(date));
        if(temp > -1){
            setLeaveBtnFlag('hide');
        }else{
            setLeaveBtnFlag('show');
        }
    }

    function checkSlotOnselectedday (date){
        let startDate = changeDateFormat(date);
        let obj ={ 
            consultantId: doctorSelected.id,
            startDate: startDate,
            stopDate: startDate
        }
        let temp = [];
        let availSlot = [];
        // console.log("obj: ",obj)
        // return false;
        let cookie = ''
        for (const [key, value] of Object.entries(cookies)) {
            if(key === 'express:sess'){
                cookie = value;
            }
        }
        let headers = {
            'authtoken': cookie
        }
        setLoader(true);
        axios.post(config.API_URL + '/api/appointment/viewslots',obj,{headers})
        .then(response => {
            // console.log(response.data)
            availSlot = response.data[0].availableSlotsList;
            timeData.map((item)=>{
                let obj = {}
                if(availSlot[item.value] ==='available'){
                    temp.push(item.value);
                }
            })
            if(temp.length>0){
                setSlotSelectedDay(showTimeSlot(temp));
            }
            setLoader(false);
        })
        .catch(error => {
            alert.show(error.response.data.errors[0].message, { type: 'error' });
            // alert.show('Api error', { type: 'error' });
            console.log(error);
            setLoader(false);
            
        });
    }
    useEffect(()=>{
        changeTimeSlotDay(date.getDay());
        onDateChange(new Date());
    },[responseData]);
    
    function changeTimeSlotDay(day){
        if(responseData.id != undefined){
            if(day==1){
                setSlotSelectedDay(showTimeSlot(responseData.mondayAvailableSlotList));
            }
            if(day==2){
                setSlotSelectedDay(showTimeSlot(responseData.tuesdayAvailableSlotList));
            } 
            if(day==3){
                setSlotSelectedDay(showTimeSlot(responseData.wednesdayAvailableSlotList));
            } 
            if(day==4){
                setSlotSelectedDay(showTimeSlot(responseData.thursdayAvailableSlotList));
            } 
            if(day==5){
                setSlotSelectedDay(showTimeSlot(responseData.fridayAvailableSlotList));
            } 
            if(day==6){
                setSlotSelectedDay(showTimeSlot(responseData.saturdayAvailableSlotList));
            }
            if(day==0){
                setSlotSelectedDay(showTimeSlot(responseData.sundayAvailableSlotList));
            }
        }else{
            // console.log("in else: ",responseData);
            setSlotSelectedDay([])
        }
    }
    function showTimeSlot(arr){
        let newTimeSlot = [];
        let st; let end;
        st= parseInt(arr[0]);
        
        for( let i = 0; i<arr.length; i++){
            let obj = {};
            if((parseInt(arr[i])+1) != parseInt(arr[i+1])){
                end= parseInt(arr[i]) +1;
                timeData.map((item)=>{
                if(item.value==st){
                    obj.timeFrom = item.label;
                }
                if(item.value==end){
                    obj.timeTo = item.label;
                }
                })
                newTimeSlot.push(obj);
                st = parseInt(arr[i+1])
            }
        }
        return newTimeSlot;
    }
     const handleSlotSpecDay = () =>{
        const values = [...slotSelectedDay];
        // console.log("setSlotSelectedDay values: ",values);
        values.push({timeFrom:'',timeTo:''})
        setSlotSelectedDay(values);
    }

    const onSpecDayTimeChange = (index, type, value) => {
        let tempSlot = [...slotSelectedDay];
        if (type === 'FROM_TIME') {
            //  currentWorkTime[id -1].timeSlot[index].timeFrom = value;
            tempSlot[index].timeFrom = value;
        } else if (type === 'TO_TIME') {
            //  currentWorkTime[id -1].timeSlot[index].timeTo = value;
            tempSlot[index].timeTo = value;
        }
        // console.log('tempSlot: ',tempSlot)
        setSlotSelectedDay(tempSlot);
    };
    function changeDateFormat(dateObj){
        // let month = dateObj.getUTCMonth() + 1; //months from 1-12
        // let day = dateObj.getUTCDate();
        // let year = dateObj.getUTCFullYear();
        let month = dateObj.getMonth() + 1; //months from 1-12
        let day = dateObj.getDate();
        let year = dateObj.getFullYear();
        if(day<10){
            day = '0'+day;
        }
        if(month < 10){
            month = '0'+month;
        }
        return  year + "-" + month + "-" + day;
    }
    const saveSlotSpecDay = () =>{
        let slotList = fetchSlotFromArr(slotSelectedDay);
        let newdate= changeDateFormat(date);
        let obj ={ 
            consultantId: doctorSelected.id,
            appointmentDate: newdate ,
            availableSlotList: slotList, 
        }
        // console.log("obj: ",obj)
        // return false;
        let cookie = ''
        for (const [key, value] of Object.entries(cookies)) {
            if(key === 'express:sess'){
                cookie = value;
            }
        }
        let headers = {
            'authtoken': cookie
        }
        setLoader(true);
        axios.post(config.API_URL + '/api/appointment/addslots',obj,{headers})
        .then(response => {
            console.log(response.data)
            setLoader(false);
            alert.show('Slot updated successfully', { type: 'success' });
        })
        .catch(error => {
            alert.show(error.response.data.errors[0].message, { type: 'error' });
            // alert.show('Api error', { type: 'error' });
            console.log(error);
            setLoader(false);
            
        });
        // fetchSlotFromArr(slotSelectedDay)
    }
    const handleRemoveSlotSpecDay = (id) =>{
        const values = [...slotSelectedDay];
        values.splice(id, 1);
        setSlotSelectedDay(values);
    }
    function fetchSlotFromArr(arr){
        let newArr =[];
        let st; let end;
        for (let i=0; i<arr.length; i++){
            timeData.map((val)=> {
                if(val.label == arr[i].timeFrom){
                st = val.value;
                }
                if(val.label == arr[i].timeTo){
                end = val.value;
                }
            })
                for(let j =st; j < end; j++){
                    if(newArr.indexOf(j) === -1) {
                    newArr.push(j);;
                }
            }
        }
        return newArr;
    }
    function dateSuffix(i) {
        var j = i % 10,
            k = i % 100;
        if (j == 1 && k != 11) {
            return i + "st";
        }
        if (j == 2 && k != 12) {
            return i + "nd";
        }
        if (j == 3 && k != 13) {
            return i + "rd";
        }
        return i + "th";
     }
     const [openLeaveMark, setOpenMarkLeave] = useState(false);
     const closeMarkLeave = () => {
        setOpenMarkLeave(false);
     }
     const openMarkLeave = () => {
        setOpenMarkLeave(true);
     }
    const markLeave = () =>{
        let newdate = changeDateFormat(date);
        let obj ={ 
            consultantId: doctorSelected.id,
            leaveDate: newdate ,
            }
        // console.log("obj: ",obj)
        // return false;
        let cookie = ''
        for (const [key, value] of Object.entries(cookies)) {
            if(key === 'express:sess'){
                cookie = value;
            }
        }
        let headers = {
            'authtoken': cookie
        }
        setLoader(true);
        // /api/appointment/addslots
        axios.post(config.API_URL + '/api/appointment/markleave',obj,{headers})
        .then(response => {
            console.log(response.data)
            onDateChange(new Date());
            leaveDtlOnDatechange();
            setLoader(false);
            alert.show('Leave applied successfully', { type: 'success' });
        })
        .catch(error => {
            alert.show(error.response.data.errors[0].message, { type: 'error' });
            // alert.show('Api error', { type: 'error' });
            console.log(error);
            setLoader(false);
        });
        setOpenMarkLeave(false);
    }
    const [openCancelLeave, setOpenCancrlLeave] = useState(false);
    const closeCancelLeave = () => {
        setOpenCancrlLeave(false);
    }
    const openCancelLeavemark = () => {
        setOpenCancrlLeave(true);
    }
    const cancleLeave = () =>{
        let newdate = changeDateFormat(date);
        let obj ={ 
            consultantId: doctorSelected.id,
            leaveDate: newdate ,
            }
        // console.log("obj: ",obj)
        // return false;
        let cookie = ''
        for (const [key, value] of Object.entries(cookies)) {
            if(key === 'express:sess'){
                cookie = value;
            }
        }
        let headers = {
            'authtoken': cookie
        }
        setLoader(true);
        // /api/appointment/addslots
        axios.post(config.API_URL + '/api/appointment/cancelLeave',obj,{headers})
        .then(response => {
            console.log(response.data)
            onDateChange(new Date());
            leaveDtlOnDatechange();
            setLoader(false);
            alert.show('Leave applied successfully', { type: 'success' });
        })
        .catch(error => {
            alert.show(error.response.data.errors[0].message, { type: 'error' });
            // alert.show('Api error', { type: 'error' });
            console.log(error);
            setLoader(false);
        });
        setOpenCancrlLeave(false);
    }
    useEffect(()=>{
        if(doctorSelected.id !== undefined){
            leaveDtlOnDatechange();
        }
    },[doctorSelected]);

    function leaveDtlOnDatechange(){
        let todayDate = new Date();
        let startDate = changeDateFormat(todayDate);
        let month = todayDate.getMonth() + 1; //months from 1-12
        let year = todayDate.getFullYear();
        let day = '30'
        if(month < 10){
            month = '0'+month;
        }
        if(month == 2){
            if(moment([todayDate.getFullYear()]).isLeapYear()){
                day = 29;
            }else{
                day = 28;
            }
        }
        if(month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12){
            day = 31
        }
        let endDate = year + "-" + month + "-" + day;
        getLeaveDetails(startDate,endDate);
    }
    const getLeaveDetails = (startDate, endDate) =>{
        let obj ={ 
                consultantId: doctorSelected.id,
                startDate: startDate,
                stopDate: endDate
            }
        // console.log("obj: ",obj)
        // return false;
        let cookie = ''
        for (const [key, value] of Object.entries(cookies)) {
            if(key === 'express:sess'){
                cookie = value;
            }
        }
        let headers = {
            'authtoken': cookie
        }
        setLoader(true);
        axios.post(config.API_URL + '/api/appointment/viewslots',obj,{headers})
        .then(response => {
            // console.log(response.data)
            let tempArr = [];
            response.data.map((item)=>{
                if(item.isDoctorOnLeave === true){
                    tempArr.push(item.appointmentDate);
                }
            })
            setLeaveDayArr(tempArr);
            setLoader(false);
        })
        .catch(error => {
            alert.show(error.response.data.errors[0].message, { type: 'error' });
            // alert.show('Api error', { type: 'error' });
            console.log(error);
            setLoader(false);
            
        });
    }
    const onMonthChange = ({ activeStartDate, view }) =>{
        // && activeStartDate.getMonth >= date.getMonth()
        let todayDate = new Date();
        if(activeStartDate.getFullYear() >= todayDate.getFullYear()){
            let startDate= changeDateFormat(activeStartDate);
            let month = activeStartDate.getMonth() + 1; //months from 1-12
            let year = activeStartDate.getFullYear();
            let day = '30'
            if(month < 10){
                month = '0'+month;
            }
            if(month == 2){
                if(moment([activeStartDate.getFullYear()]).isLeapYear()){
                    day = 29;
                }else{
                    day = 28;
                }
            }
            if(month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12){
                day = 31
            }
            let endDate = year + "-" + month + "-" + day;
            if( activeStartDate.getFullYear() == todayDate.getFullYear() && activeStartDate.getMonth() >= todayDate.getMonth()){
                if(activeStartDate.getMonth() == todayDate.getMonth()){
                    startDate = changeDateFormat(todayDate);
                }
                getLeaveDetails(startDate,endDate);
            }else if(activeStartDate.getFullYear() > todayDate.getFullYear()){
                getLeaveDetails(startDate,endDate);
            }
        }
       
    }
    return(
        <>
         {loader && <div className="loader"><CircularProgress color="secondary" /><div className="text"></div></div>}
            <div className='rightView'>
               <div className='calander'>
                  <Calendar
                    // tileClassName = {showLeaveMark}
                    onChange={onDateChange}
                    value={date}
                    tileClassName={({ date, view }) => {
                        if(leaveDayArr.find(x=>x===moment(date).format("YYYY-MM-DD"))){
                         return  'leaveMark'
                        }
                      }}
                    onActiveStartDateChange = {onMonthChange}
                  />
               </div>
               <div className='showSelectedDate'>
                <span style={{float:'left', padding:'5px 0'}}>{dateSuffix(date.getDate())} &nbsp;{months[date.getMonth()]}</span>
                <span className={'markLeave ' + leaveBtnFlag} onClick={openMarkLeave}>Mark Leave</span>
                <span className={'markLeave CancelLeave ' + leaveBtnFlag} onClick={openCancelLeavemark}>Cancel Leave</span>
               </div>

               <Dialog
                  open={openLeaveMark}
                  // onClose={closeRefund}
                  aria-labelledby="alert-dialog-title"
                  aria-describedby="alert-dialog-description"
                  className='cancelAndRefund'
                  >
                  <DialogTitle id="alert-dialog-title"><span>Do you want to mark leave on {dateSuffix(date.getDate())}&nbsp;{months[date.getMonth()]}?</span></DialogTitle>
                  <DialogActions>
                     <Button onClick={closeMarkLeave} color="primary" color="primary" className="back cancelBtn">
                        No
                     </Button>
                     <Button onClick={markLeave} color="primary" className="primary-button forward saveBtn" style={{marginRight:'30px'}}>
                       Yes
                     </Button>
                  </DialogActions>
               </Dialog>

               <Dialog
                  open={openCancelLeave}
                  // onClose={closeCancelLeave}
                  aria-labelledby="alert-dialog-title"
                  aria-describedby="alert-dialog-description"
                  className='cancelAndRefund'
                  >
                  <DialogTitle id="alert-dialog-title"><span>Do you want to cancel leave on {dateSuffix(date.getDate())}&nbsp;{months[date.getMonth()]}?</span></DialogTitle>
                  <DialogActions>
                     <Button onClick={closeCancelLeave} color="primary" color="primary" className="back cancelBtn">
                        No
                     </Button>
                     <Button onClick={cancleLeave} color="primary" className="primary-button forward saveBtn" style={{marginRight:'30px'}}>
                       Yes
                     </Button>
                  </DialogActions>
               </Dialog>
               {slotSelectedDay.length>0 ? 
               <div className='timeSlots'>
                  {slotSelectedDay.map((item,i)=>(
                     <div key={i}>
                        <TextField
                           select
                           // disabled
                           label="From"
                           className='timeSlotSelect'
                           size="small"
                           variant="filled"
                           defaultValue='9:AM'
                           // margin='normal'
                           value={item.timeFrom}
                           onChange={(e) => {
                              // e.target.value
                              onSpecDayTimeChange(
                                    i,
                                    'FROM_TIME',
                                    e.target.value,
                                    // item.id
                              );
                           }}
                           >
                              {timeData.map((element) => {
                                 return (
                                       <MenuItem
                                          value={element.label}
                                          key={element.id}>
                                          {element.label}
                                       </MenuItem>
                                 );
                              })}
                        </TextField>
                        <TextField
                           select
                           // disabled
                           label="To "
                           className='timeSlotSelect'
                           size="small"
                           variant="filled"
                           defaultValue='10:AM'
                           // margin='normal'
                           value={item.timeTo}
                           onChange={(e) => {
                              // e.target.value
                              onSpecDayTimeChange(
                                    i,
                                    'TO_TIME',
                                    e.target.value,
                                    // item.id
                              );
                           }}
                           >
                              {timeData.map((element) => {
                                 return (
                                       <MenuItem
                                          value={element.label}
                                          key={element.id}>
                                          {element.label}
                                       </MenuItem>
                                 );
                              })}
                        </TextField>
                           {i >= 0 && (
                           <button
                              className="removeIcon"
                              type="button"
                              onClick={() => handleRemoveSlotSpecDay(i)}
                           >
                              <span className="minusLine"></span>
                           </button>
                           )}
                     </div>
                  ))}
                  
                  <div className='plusBtn' onClick={handleSlotSpecDay}>
                     <span>+ ADD NEW SLOT</span>
                  </div>

                  <div className="action">
                     <Button 
                        size="small" 
                        variant="contained" 
                        color="secondary" 
                        className="primary-button forward" 
                        // type="submit" 
                        onClick={saveSlotSpecDay}
                     >UPDATE</Button>
                  </div>
               </div>
               :
               
               <div className='timeSlots'>
                   {leaveBtnFlag === 'show' ?
                   <>
                    <div style={{textAlign:'center', marginTop:'10%'}}>
                        <span>No slot for {dateSuffix(date.getDate())}&nbsp;{months[date.getMonth()]} </span>
                    </div>
                    <div className='plusBtn' onClick={handleSlotSpecDay} style={{margin:"35px 10px"}}>
                        <span>+ ADD NEW SLOT</span>
                    </div>
                  </>
                  :
                  <>
                   <div style={{textAlign:'center', marginTop:'10%'}}>
                        <span>Leave applied  for {dateSuffix(date.getDate())}&nbsp;{months[date.getMonth()]} </span>
                    </div>
                  </>
                  }
               </div> 
               }
            </div>
        </>
    )
}
export default CalanderSection;