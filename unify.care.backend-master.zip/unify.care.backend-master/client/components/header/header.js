
import { useState, useEffect } from 'react';
import Button from '@material-ui/core/Button';
import axios from 'axios';
import config from '../../app.constant';
import Router from 'next/router';
import {useCookies } from "react-cookie";
import { useAlert, types } from 'react-alert';

function Header(props) {
    // console.log("props: ",props)
    // let userDetails = props.userDetails;
    const alert = useAlert();
    const [showSignout, setShowSignout] = useState('hide');
    const [cookies, getCookie] = useCookies(['name']);
    const [loader, setLoader] = useState(false);
    const [userDetails, setUserDetails] = useState({});

    const signout = async () => {
        setShowSignout('hide');
        await axios.post(config.API_URL + '/api/users/signout')
           .then(() => {
              Router.push('/')
           })
           .catch(error => {
              console.log(error);
              alert.show(error.response.data.errors[0].message, { type: 'error' })
           });
     }
    function signOutBtn (){
        setShowSignout('');
        if(showSignout === ''){
           setShowSignout('hide');
        }
     }
     
    const fetcUserData = () =>{
    let cookie = ''
    for (const [key, value] of Object.entries(cookies)) {
        if(key === 'express:sess'){
            cookie = value;
        }
    }
    let headers = {
        'authtoken': cookie
    }
    setLoader(true);
    axios.get(config.API_URL + '/api/employee', {headers})
    .then(response => {
        // console.log(response.data)
        setUserDetails(response.data)
        setLoader(false);
    })
    .catch(error => {
        alert.show(error.response.data.errors[0].message, { type: 'error' });
        console.log(error);
        setLoader(false);
        
    });
    }
    useEffect(() => {
        fetcUserData();
    }, []);
    const userProfileImg = (e) =>{
        e.preventDefault()
        let newVal = e.target.value.replace(/^.*[\\\/]/, '');
        let file = document.getElementById('UserprofilePic').files[0];
        let timestamp = new Date().getTime();
        let fileRe = file.name.replace(/[^a-zA-Z.]/g, "")
        let filename = ''
        filename = "empProfile/" + timestamp + "_" + fileRe;
        uploadProfileImages();
    }

    const uploadProfileImages = () => {
    let imageUrl = null;
    var model = {
        file: document.getElementById('UserprofilePic').files[0]
    };
    let cookie = ''
    for (const [key, value] of Object.entries(cookies)) {
        if(key === 'express:sess'){
            cookie = value;
        }
    }
    var configs = {
        headers: {'authtoken': cookie},
        transformRequest: function (obj) {
            var formData = new FormData();
            for (var prop in obj) {
                formData.append(prop, obj[prop]);
            }
            return formData;
        }
    };
    setLoader(true)
    axios.post(config.API_URL + '/api/file-manager/upload', model, configs)
        .then(response => {
            console.log(response.data)
            imageUrl = response.data.fileName;
            saveProfileImage(imageUrl);
            setLoader(false)
        })
        .catch(error => {
            console.log(error);
            setLoader(false);
            alert.show(error.response.data.errors[0].message, { type: 'error' });
        });
    }
    const saveProfileImage = (imageUrl) =>{
    let cookie = ''
    for (const [key, value] of Object.entries(cookies)) {
        if(key === 'express:sess'){
            cookie = value;
        }
    }
    let headers = {
        'authtoken': cookie
    }
    console.log("imageUrl: ",imageUrl);
    axios.put(config.API_URL + '/api/employee/image', {profileImageName:imageUrl}, {headers})
    .then(response => {
        console.log(response);
        setShowSignout('hide');
        fetcUserData();
        // setLoader(false)
    })
    .catch(error => {
        console.log(error);
        setShowSignout('hide');
        // setLoader(false);
        alert.show(error.response.data.errors[0].message, { type: 'error' });
    });
    }
    return<>
        {/* <p>this is header{props.name}</p> */}
        {/* <div className="heading">{props.name}</div> */}

        <div className="header-area">
            <div className="heading">{props.name}</div>
            <div className='headright'>
               <img src="settings.svg" className="righticon" style={{cursor:'not-allowed'}} />
               <img src="notifications.svg" className="righticon" style={{cursor:'not-allowed'}} />
               <img src={userDetails.profileImageName && userDetails.profileImageName !='NA' ? "https://www.unify.care/api/file-manager/download/" + userDetails.profileImageName: 'user.svg'} className="righticon" style={{borderRadius:'50%',border: 'solid 1px #9b9b9b'}} onClick={signOutBtn} />
               <div className={'signOutDiag ' + (showSignout)}>
                  <div style={{margin:'10px'}}>
                     <img src={userDetails.profileImageName && userDetails.profileImageName !='NA' ? "https://www.unify.care/api/file-manager/download/" + userDetails.profileImageName: 'user.svg'} />
                     <span>
                     <input type="file" id="UserprofilePic" onChange={userProfileImg} />
                     </span>
                  </div>
                  <div className='userName' style={{textTransform:'capitalize'}}>
                     {userDetails.userFirstName + ' '+ userDetails.userLastName}
                  </div>
                  <div className='userEmail'>
                     {userDetails.emailId}
                  </div>
                  <Button onClick={signout} className='signOutBtn'>
                  Logout
                  </Button>
               </div>
            </div>
         </div>

    </>
}
export default Header;