import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import { useState, useEffect } from 'react';
import { useAlert, types } from 'react-alert';
import {useCookies } from "react-cookie";
import axios from 'axios';
import config from '../../app.constant';
import CircularProgress from '@material-ui/core/CircularProgress';
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';
function EmployeeTable(props){
   const [empList, setEmpList] = useState([]);
   const alert = useAlert();
   const [cookies, getCookie] = useCookies(['name']);
   const [loader, setLoader] = useState(false);

   function getEmpData () {
        let temp = []
        let cookie = ''
        for (const [key, value] of Object.entries(cookies)) {
        if(key === 'express:sess'){
            cookie = value;
        }
        }
        let headers = {
        'authtoken': cookie
        }
        setLoader(true);
        axios.get(config.API_URL + '/api/partner/employee',{headers})
        .then((response) => {
        console.log('response: ',response)
        temp = response.data;
        temp.map((item)=>{
            let dateObj = new Date(item.onboardingDate);
            let month = dateObj.toLocaleString('en-us', { month: 'short' }); //months from 1-12
            let day = dateObj.getUTCDate();
            let year = dateObj.getUTCFullYear();
            if(day<10){
                day = '0'+day;
            }
            let newdate = day + "-" + month + "-" + year;
            item.showOnboardingDate = newdate;
        })
        setEmpList(temp);
        // setEmpList(response.data);
        setLoader(false);
        })
        .catch(error => {
        setLoader(false);
        console.log(error);
        alert.show(error.response.data.errors[0].message, { type: 'error' });
        });
    }
    useEffect(() => {
        getEmpData();
     }, [props.updateList]);
    const changeStatus =(e,val,id) =>{
    e.preventDefault();
    const ins = empList.findIndex((v)=> v.id === id);
    const value = [...empList];
    if(ins >=0 ){
        value[ins].userStatus = val;
        console.log("value: ",value)
    }
    
    let cookie = ''
        for (const [key, value] of Object.entries(cookies)) {
            if(key === 'express:sess'){
                cookie = value;
            }
        }
        let headers = {
            'authtoken': cookie
        }
    let obj={
        id: id,
        userStatus: val,
    }
    setLoader(true);
    axios.put(config.API_URL + '/api/partner/employee',obj,{headers})
        .then((response) => {
            console.log('response: ',response);
            setLoader(false)
        })
        .catch(error => {
            console.log(error);
            setLoader(false);
            alert.show(error.response.data.errors[0].message, { type: 'error' });
        });
    setEmpList(value);
    }
    return(
        <>
        {loader && <div className="loader"><CircularProgress color="secondary" /><div className="text"></div></div>}
         <div className='empTable'>
            {empList.length>0 ? 
               <TableContainer component={Paper}>
                  <Table aria-label="simple table" className='table'>
                  <TableHead>
                     <TableRow>
                        <TableCell align="center">User Name</TableCell>
                        <TableCell align="center">Phone</TableCell>
                        <TableCell align="center">Email</TableCell>
                        <TableCell align="center">Onboarding Date</TableCell>
                        <TableCell align="center">Department</TableCell>
                        <TableCell align="center">Designation</TableCell>
                        <TableCell align="center">Status</TableCell>
                     </TableRow>
                  </TableHead>
                  <TableBody>
                     {empList.map((emp,i) => (
                        <TableRow key={emp.id}>
                        <TableCell align="center" style={{textTransform:'capitalize'}}> {emp.userFirstName + ' ' +emp.userLastName}</TableCell>
                        <TableCell align="center">{emp.phoneNumber}</TableCell>
                        <TableCell align="center">{emp.emailId}</TableCell>
                        <TableCell align="center">{emp.showOnboardingDate?emp.showOnboardingDate :'01-10-2020'}</TableCell>
                        <TableCell align="center" style={{textTransform:'capitalize'}}>
                           {emp.department.indexOf('-department') > -1 ? emp.department.replace("-", " ").slice(0,emp.department.indexOf('-department')) : emp.department.replace("-", " ").replace("-", " ") }
                        </TableCell>
                        <TableCell align="center" style={{textTransform:'capitalize'}}>{emp.designation.indexOf(':') > -1 ? emp.designation.replace(":", " ") : emp.designation.replace("-", " ").replace("-", " ")}</TableCell>
                        <TableCell align="center" style={{textTransform:'capitalize'}}>
                           <span>
                              <TextField
                                 select
                                 key={emp.id}
                                 label=''
                                 id="Department"
                                 value={emp.userStatus}
                                 required
                                 margin="normal"
                                 variant="filled"
                                 onChange={(e) => changeStatus(e, e.target.value,emp.id)}
                                 // className={(addDept === '' ? 'err1' : '')}
                              >
                                 <MenuItem  value='unverified'>Unverified</MenuItem>
                                 <MenuItem value='verified'>Verified</MenuItem>
                                 <MenuItem  value='actice'>Active</MenuItem>
                                 <MenuItem  value='inactive'>Inactive</MenuItem>
                                 <MenuItem  value='suspended'>Suspended</MenuItem>
                              </TextField>
                           </span>
                           </TableCell>
                        </TableRow>
                     ))}
                  </TableBody>
                  </Table>
               </TableContainer>
               : 
                  <div style={{textAlign:'center', marginTop:'10%', lineHeight:'1.5', wordSpacing:'1px'}} className='noData'>
                     <div className='title'>
                        Tap on "Add New" button to add new employee.
                     </div>
                  </div>
               }
         </div>
         
        </>
    )
}
export default EmployeeTable;