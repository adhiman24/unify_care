import TextField from '@material-ui/core/TextField';
import Button from '@material-ui/core/Button';
import CircularProgress from '@material-ui/core/CircularProgress';
import Grid from '@material-ui/core/Grid';
import DeleteForeverIcon from '@material-ui/icons/DeleteForever';
import { useState, useContext, useEffect } from 'react';
import axios from 'axios'
import { StepUpdateContext } from '../../context/registerStep'
import { UserUpdateContext } from '../../context/basiciSignup'
import { useRouter } from 'next/router'
import Icon from '@material-ui/core/Icon';
import { useAlert, types } from 'react-alert'
import config from '../../app.constant';
import {useCookies } from "react-cookie";

function AuthoritySign({ userData, type }) {

   const router = useRouter()
   const alert = useAlert()

   const { step, newStep } = useContext(StepUpdateContext);
   const { user, newUser } = useContext(UserUpdateContext);
   const [authorityName, setAuthorityName] = useState('')
   const [authorityEmail, setAuthorityEmail] = useState('')
   const [authorityTaxId, setAuthorityTaxId] = useState('')
   const [authoritySTaxId, setAuthoritySTaxId] = useState('')

   const [loader, setLoader] = useState(false)
   const [errMsg, setErrMsg] = useState(false)

   const [userPhone, setUserPhone] = useState({})
   const [userEmail, setUserEmail] = useState({})
   
   const [cookies, getCookie] = useCookies(['name']);
   useEffect(() => {
      if (Object.keys(userData).length !== 0) {
         setUserPhone(userData.mobileNumber)
         setUserEmail(userData.email)
      } else {
         setUserPhone(user.data.mobileNumber)
         setUserEmail(user.data.email)
      }
   }, [user])

   const [uid, setUid] = useState('')
   useEffect(() => {
      if (process.browser) {
         setUid(localStorage.getItem('agencyuserId'))
      }
   }, [])

   const goBackVerifyPage = (e) => {
      e.preventDefault()
      router.push('/companydetails?companyInfo')
   }

   const [authorityTaxvalue, setAuthorityTaxvalue] = useState('')
   const [authoritySTaxvalue, setAuthoritySTaxvalue] = useState('')
   const [authorityTaxFileName, setAuthorityTaxFileName] = useState('')
   const [authoritySTaxFileName, setAuthoritySTaxFileName] = useState('')
   const [signingAuthTaxIdUrl, setSigningAuthTaxIdUrl] = useState('');
   const [signingAuthLetterUrl, setSigningAuthLetterUrl] = useState('');

   const authorityTaxChange = (e) => {
      e.preventDefault()
      let newVal = e.target.value.replace(/^.*[\\\/]/, '')
      setAuthorityTaxvalue(newVal)

      let file = document.getElementById('authorityTaxId').files[0]
      let timestamp = new Date().getTime();
      let fileRe = file.name.replace(/[^a-zA-Z.]/g, "")
      let filename = ''

      filename = "agency/" + uid + "/" + timestamp + "_" + fileRe
      setAuthorityTaxFileName(filename)
   }
   const authoritySTaxChange = (e) => {
      e.preventDefault()
      let newVal = e.target.value.replace(/^.*[\\\/]/, '')
      setAuthoritySTaxvalue(newVal)

      let file = document.getElementById('authoritySTaxId').files[0]
      let timestamp = new Date().getTime();
      let fileRe = file.name.replace(/[^a-zA-Z.]/g, "")
      let filename = ''
      filename = "agency/" + uid + "/" + timestamp + "_" + fileRe
      setAuthoritySTaxFileName(filename)
   }
   const deleteAuthorityTaxvalue = (e) => {
      e.preventDefault()
      setAuthorityTaxvalue('')
      setAuthorityTaxFileName('')
   }

   const deleteAuthoritySTaxvalue = (e) => {
      e.preventDefault()
      setAuthoritySTaxvalue('')
      setAuthoritySTaxFileName('')
   }

   const fetchAuthorityDetails = async () => {

      try {
         setLoader(true)
         let cookie = ''
         for (const [key, value] of Object.entries(cookies)) {
            if(key === 'express:sess'){
               cookie = value;
            }
         }
         let headers = {
            'authtoken': cookie
         }
         const url =config.API_URL +  '/api/partner/signingauth'
         const response = await axios.get(url,{headers});

         console.log(response.data);

         if (response.data) {
            setLoader(false)
            const {
               signingAuthName, signingAuthWorkEmail, signingAuthTaxId,
               signingAuthTaxIdUrl, signingAuthTitle, signingAuthLetterUrl
            } = response.data;

            setAuthorityName(signingAuthName);
            setAuthorityEmail(signingAuthWorkEmail)
            setAuthorityTaxId(signingAuthTaxId)
            setAuthoritySTaxId(signingAuthTitle)
            let newVal = signingAuthTaxIdUrl.replace(/^.*[\\\/]/, '')
            setAuthorityTaxvalue(newVal)
            setAuthorityTaxFileName(signingAuthTaxIdUrl)
            newVal = signingAuthLetterUrl.replace(/^.*[\\\/]/, '')
            setAuthoritySTaxvalue(newVal)
            setAuthoritySTaxFileName(signingAuthLetterUrl)
         }
         setLoader(false)
      } catch (err) {
         console.error(err);
         setLoader(false)
      }
   }

   useEffect(() => {
      fetchAuthorityDetails()
   }, [])

   let documentarr = []

   const submitAuthoritySign = (e) => {
      e.preventDefault()
      setErrMsg(false)
      if (authorityTaxvalue === '' || authoritySTaxvalue === '') {
         setErrMsg(true)
         alert.show('All fields are required', { type: 'error' })
         return false
      }

      documentarr = []

      if (authorityTaxvalue !== '') {
         documentarr.push({ name: 'Authority Tax ID', id: 'authorityTaxId', key: authorityTaxvalue, filename: authorityTaxFileName })
      }
      if (authoritySTaxvalue !== '') {
         documentarr.push({ name: 'Authority Service Tax ID', id: 'authoritySTaxId', key: authoritySTaxvalue, filename: authoritySTaxFileName })
      }

      console.log(documentarr)
      setLoader(true)
      if (documentarr.length > 0) {
         uploadImages()
      } else {
         finalsave(signingAuthTaxIdUrl, signingAuthLetterUrl);
      }
   }

   const uploadImages = () => {
      let signingAuthTaxIdUrlofStoredLocation = null;
      let signingAuthTitleUrlofStoredLocation = null;
      const saveImage = (a) => {
         var model = {
            file: document.getElementById(documentarr[a].id).files[0]
         };
         let cookie = ''
         for (const [key, value] of Object.entries(cookies)) {
            if(key === 'express:sess'){
               cookie = value;
            }
         }
         var configs = {
            headers: { 'Content-Type': 'multipart/form-data', 'type': 'formData','authtoken': cookie },
            transformRequest: function (obj) {
               var formData = new FormData();
               for (var prop in obj) {
                  formData.append(prop, obj[prop]);
               }
               return formData;
            }
         };

         axios.post(config.API_URL + '/api/file-manager/upload', model, configs)
            .then(response => {
               console.log(response.data)
               if (a == 0) {
                  signingAuthTaxIdUrlofStoredLocation = response.data.fileName;
                  setSigningAuthTaxIdUrl(response.data.fileName);
               }
               if (a == 1) {
                  signingAuthTitleUrlofStoredLocation = response.data.fileName;
                  setSigningAuthLetterUrl(response.data.fileName);
               }
               if (a < (documentarr.length - 1)) {
                  saveImage(a + 1);
               } else if (a === (documentarr.length - 1)) {
                  console.log('after saving images, finalcall');
                  finalsave(signingAuthTaxIdUrlofStoredLocation,
                     signingAuthTitleUrlofStoredLocation);
               }
            })
            .catch(error => {
               console.log(error);
               setLoader(false)
            });
      };
      saveImage(0);
   }

   const finalsave = (signingAuthTaxIdUrlofStoredLocation, signingAuthTitleUrlofStoredLocation) => {
      setLoader(false)

      let obj =
      {
         signingAuthName: authorityName,
         signingAuthWorkEmail: authorityEmail,
         signingAuthTaxId: authorityTaxId,
         signingAuthTaxIdUrl: signingAuthTaxIdUrlofStoredLocation,
         signingAuthTitle: authoritySTaxId,
         signingAuthLetterUrl: signingAuthTitleUrlofStoredLocation,
      }
      let cookie = ''
      for (const [key, value] of Object.entries(cookies)) {
         if(key === 'express:sess'){
            cookie = value;
         }
      }
      let headers = {
         'authtoken': cookie
      }
      setLoader(true)
      const url = config.API_URL + '/api/partner/signingauth';
      axios.post(url, obj,{headers})
         .then(response => {
            console.log(response.data)
            setLoader(false)
            newStep(parseInt(step) + 1)
            router.push('/companydetails?bankAccount')
         })
         .catch(error => {
            setLoader(false)
            console.log(error);
         });
   }

   const signout = async () => {
      await axios.post(config.API_URL + '/api/users/signout')
         .then(() => {
            router.push('/')
         })
         .catch(error => {
            console.log(error);
            alert.show('API error', { type: 'error' })
         });
   }


   return <>
      <div
         // style={{
         //    display: "flex",
         //    flexDirection: "row",
         //    background: "#2b2b2b",
         // }}
      >
         {/* <Button
            size="small"
            variant="contained"
            color="secondary"
            className="primary-button"
            onClick={signout}
            style={{ margin: "20px 20px 20px 900px" }}
         >
            Logout
            </Button> */}
            <div style={{textAlign:'end'}}>
               <img style={{height:'25px'}} src="bell.png" />
               <img style={{height:'25px',marginLeft:'12px', borderRadius:'50%', border:'1px solid #a9a9a9'}} src="user.svg" />
            </div>
      </div>
      {loader && <div className="loader"><CircularProgress color="secondary" /><div className="text">Uploading Authorized Signatory</div></div>}
      <h2>Authorized Signatory</h2>
      <div className="form-input authSign">
         <form noValidate autoComplete="off" onSubmit={submitAuthoritySign}>
            <TextField 
               required 
               label="Signing Authority Name" 
               style={{ margin: 8 }} 
               margin="normal" 
               variant="filled"
               // InputLabelProps={{ shrink: true }} 
               className={"half-div " + (errMsg && authorityName === '' ? 'err' : '')} 
               value={authorityName} 
               onChange={(e) => setAuthorityName(e.target.value)} 
               />
            <TextField 
               required 
               label="Signing Authority Work Email" 
               style={{ margin: 8 }} 
               margin="normal" 
               variant="filled"
               // InputLabelProps={{ shrink: true }} 
               className={"half-div " + (errMsg && authorityEmail === '' ? 'err' : '')} 
               value={authorityEmail} 
               onChange={(e) => setAuthorityEmail(e.target.value)} 
               />

            <div className="break"></div>

            <div className="two-div">
               <TextField 
                  required 
                  label="Signing Authority Tax ID" 
                  style={{ margin: 8 }} 
                  margin="normal" 
                  variant="filled"
                  // InputLabelProps={{ shrink: true }} 
                  className={"more " + (errMsg && authorityTaxId === '' ? 'err' : '')} 
                  value={authorityTaxId} 
                  onChange={(e) => setAuthorityTaxId(e.target.value)} 
                  />
               <div className="upload-option">
                  <input type="file" className="choose" id="authorityTaxId" onChange={authorityTaxChange} />
                  <label htmlFor="authorityTaxId" className="dragContent"><img src="upload.svg" />{authorityTaxvalue === '' ? <span className='dragContentText'>Upload scanned copy of Permanent Account Number (PAN) Card</span> : <div className="change-file">{authorityTaxvalue}
                     <div className="delete-opt" onClick={deleteAuthorityTaxvalue}><Grid item xs={8}>
                        <DeleteForeverIcon />
                     </Grid></div>
                  </div>}
                  </label>
               </div>
            </div>

            <div className="two-div">
               <TextField 
                  required 
                  label="Signing Authority Title" 
                  style={{ margin: 8 }} 
                  margin="normal" 
                  variant="filled"
                  // InputLabelProps={{ shrink: true }} 
                  className={"more " + (errMsg && authoritySTaxId === '' ? 'err' : '')} 
                  value={authoritySTaxId} 
                  onChange={(e) => setAuthoritySTaxId(e.target.value)} 
                  />
               <div className="upload-option">
                  <input type="file" className="choose" id="authoritySTaxId" onChange={authoritySTaxChange} />
                  <label htmlFor="authoritySTaxId" className="dragContent"><img src="upload.svg" />{authoritySTaxvalue === '' ? <span className='dragContentText'>Upload scanned copy of  signing authority letter</span>: <div className="change-file">{authoritySTaxvalue}
                     <div className="delete-opt" onClick={deleteAuthoritySTaxvalue}><Grid item xs={8}>
                        <DeleteForeverIcon />
                     </Grid></div>
                  </div>}
                  </label>
               </div>
            </div>

            <div className="action">
               <Button size="small" variant="contained" onClick={goBackVerifyPage} className="back" style={{fontSize:'14px',fontWeight:'bold' }}><Icon className="fa fa-chevron-left"></Icon>Back</Button>
               <Button size="small" variant="contained" color="secondary" className="primary-button forward" type="submit" style={{ color: '#000',fontSize:'14px',fontWeight:'bold' }}>NEXT<Icon className="fa fa-chevron-right"></Icon></Button>
            </div>
         </form>

      </div>
   </>
}

export default AuthoritySign