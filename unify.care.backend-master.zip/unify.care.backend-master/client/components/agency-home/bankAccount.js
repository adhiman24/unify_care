import TextField from '@material-ui/core/TextField';
import CircularProgress from '@material-ui/core/CircularProgress';
import Grid from '@material-ui/core/Grid';
import DeleteForeverIcon from '@material-ui/icons/DeleteForever';
import { useState, useContext, useEffect } from 'react';
import { StepUpdateContext } from '../../context/registerStep'
import { UserUpdateContext } from '../../context/basiciSignup'
import { useRouter } from 'next/router'
import Button from '@material-ui/core/Button';
import axios from 'axios'
import Icon from '@material-ui/core/Icon';
import { useAlert, types } from 'react-alert';
import config from '../../app.constant';
import {useCookies } from "react-cookie";

function BankAccount({ userData, type }) {

   const router = useRouter()
   const alert = useAlert()

   const { step, newStep } = useContext(StepUpdateContext);
   const { user, newUser } = useContext(UserUpdateContext);
   const [name, setName] = useState('')
   const [number, setNumber] = useState('')
   const [ifsc, setIfsc] = useState('')
   const [bankName, setBankName] = useState('')

   const [loader, setLoader] = useState(false)
   const [errMsg, setErrMsg] = useState(false)

   const [userPhone, setUserPhone] = useState({})
   const [userEmail, setUserEmail] = useState({})
   const [cookies, getCookie] = useCookies(['name']);
   useEffect(() => {
      if (Object.keys(userData).length !== 0) {
         setUserPhone(userData.mobileNumber)
         setUserEmail(userData.email)
      } else {
         setUserPhone(user.data.mobileNumber)
         setUserEmail(user.data.email)
      }
   }, [user])

   const [uid, setUid] = useState('')
   useEffect(() => {
      if (type === 'company') {
         if (process.browser) {
            setUid(localStorage.getItem('companyuserId'))
         }
      } else {
         if (process.browser) {
            setUid(localStorage.getItem('agencyuserId'))
         }
      }
   }, [])

   const goBackVerifyPage = (e) => {
      e.preventDefault()
      router.push('/companydetails?authoritySign')
   }

   const [cancelChequevalue, setCancelChequevalue] = useState('')
   const [cancelChequeFileName, setCancelChequeFileName] = useState('')
   const [bankChequeURL, setBankChequeURL] = useState('')

   const cancelChequeChange = (e) => {
      e.preventDefault()
      let newVal = e.target.value.replace(/^.*[\\\/]/, '')
      setCancelChequevalue(newVal)

      let file = document.getElementById('cancelChequeId').files[0]
      let timestamp = new Date().getTime();
      let fileRe = file.name.replace(/[^a-zA-Z.]/g, "")
      let filename = ''
      filename = "agency/" + uid + "/" + timestamp + "_" + fileRe
      setCancelChequeFileName(filename)
   }
   const deleteCancelChequevalue = (e) => {
      e.preventDefault()
      setCancelChequevalue('')
      setCancelChequeFileName('')
   }


   const fetchBankDetails = async () => {

      try {
         setLoader(true)
         let cookie = ''
         for (const [key, value] of Object.entries(cookies)) {
            if(key === 'express:sess'){
               cookie = value;
            }
         }
         let headers = {
            'authtoken': cookie
         }
         const url = config.API_URL + '/api/partner/bankdetails';
         const response = await axios.get(url,{headers});

         console.log(response.data);
         if (response.data) {

            const {
               bankAccountName, bankAccountNumber, bankIFSCCode,
               bankName, bankChequeURL,
            } = response.data;

            setName(bankAccountName)
            setNumber(bankAccountNumber)
            setIfsc(bankIFSCCode)
            setBankName(bankName)

            let newVal = bankChequeURL.replace(/^.*[\\\/]/, '')
            setCancelChequevalue(newVal)
            setCancelChequeFileName(bankChequeURL)
            setLoader(false)
         }
         setLoader(false)
      } catch (err) {
         console.error(err);
         setLoader(false)
      }
   }

   useEffect(() => {
      fetchBankDetails()
   }, [])

   let documentarr = []

   const submitAuthoritySign = (e) => {
      e.preventDefault()
      setErrMsg(false)
      if (cancelChequevalue === '') {
         setErrMsg(true)
         alert.show('All fields are required', { type: 'error' })
         return false
      }

      documentarr = []

      if (cancelChequevalue !== '') {
         documentarr.push({ name: 'Authority Tax ID', id: 'cancelChequeId', key: cancelChequevalue, filename: cancelChequeFileName })
      }
      setLoader(true)
      if (documentarr.length > 0) {
         uploadImages(0)
      } else {
         finalsave(bankChequeURL);
      }
   }

   const uploadImages = (a) => {
      let setBankChequeURLOfStoredLocation = null;
      var model = {
         file: document.getElementById(documentarr[a].id).files[0]
      };
      let cookie = ''
      for (const [key, value] of Object.entries(cookies)) {
         if(key === 'express:sess'){
            cookie = value;
         }
      }
      var configs = {
         headers: { 'Content-Type': 'multipart/form-data', 'type': 'formData', 'authtoken': cookie},
         transformRequest: function (obj) {
            var formData = new FormData();
            for (var prop in obj) {
               formData.append(prop, obj[prop]);
            }
            return formData;
         }
      };

      axios.post(config.API_URL + '/api/file-manager/upload', model, configs)
         .then(response => {
            console.log(response.data)
            setBankChequeURLOfStoredLocation = response.data.fileName;
            setBankChequeURL(response.data.fileName);
            finalsave(setBankChequeURLOfStoredLocation);
         })
         .catch(error => {
            console.log(error);
            setLoader(false)
         });
   }

   const finalsave = (setBankChequeURLOfStoredLocation) => {
      setLoader(false)

      let obj = {
         bankAccountName: name,
         bankAccountNumber: number,
         bankIFSCCode: ifsc,
         bankName: bankName,
         bankChequeURL: setBankChequeURLOfStoredLocation
      }
      let cookie = ''
      for (const [key, value] of Object.entries(cookies)) {
         if(key === 'express:sess'){
            cookie = value;
         }
      }
      let headers = {
         'authtoken': cookie
      }
      setLoader(true)
      const url = config.API_URL + '/api/partner/bankdetails';
      axios.post(url, obj,{headers})
         .then(response => {
            console.log(response.data)
            setLoader(false)
            newStep(parseInt(step) + 1)

            router.push('/companydetails?finalMessage')
         })
         .catch(error => {
            setLoader(false)
            alert.show('Api error', { type: 'error' })
            console.log(error);
         });
   }

   const signout = async () => {
      await axios.post(config.API_URL + '/api/users/signout')
         .then(() => {
            router.push('/')
         })
         .catch(error => {
            console.log(error);
            alert.show('API error', { type: 'error' })
         });
   }

   return <>
      <div
         // style={{
         //    display: "flex",
         //    flexDirection: "row",
         //    background: "#2b2b2b",
         // }}
      >
         {/* <Button
            size="small"
            variant="contained"
            color="secondary"
            className="primary-button"
            onClick={signout}
            style={{ margin: "20px 20px 20px 900px" }}
         >
            Logout
            </Button> */}
            <div style={{textAlign:'end'}}>
               <img style={{height:'25px'}} src="bell.png" />
               <img style={{height:'25px',marginLeft:'12px',borderRadius:'50%', border:'1px solid #a9a9a9'}} src="user.svg" />
            </div>
      </div>
      {loader && <div className="loader"><CircularProgress color="secondary" /><div className="text">Uploading Bank Account</div></div>}
      <h2>Bank Account</h2>
      <div className="form-input bankAcc">
         <form noValidate autoComplete="off" onSubmit={submitAuthoritySign}>
            <TextField 
               required 
               label="Account Name" 
               style={{ margin: 8 }} 
               margin="normal" 
               variant="filled"
               // InputLabelProps={{ shrink: true }} 
               className={"half-div " + (errMsg && name === '' ? 'err' : '')} 
               value={name} 
               onChange={(e) => setName(e.target.value)} 
               />
            <TextField 
               required 
               label="Account Number" 
               style={{ margin: 8 }} 
               margin="normal" 
               variant="filled"
               // InputLabelProps={{ shrink: true }} 
               className={"half-div " + (errMsg && number === '' ? 'err' : '')} 
               value={number} 
               onChange={(e) => setNumber(e.target.value)} 
               />
            <TextField 
               required 
               label="IFSC Code" 
               style={{ margin: 8 }} 
               margin="normal" 
               variant="filled"
               // InputLabelProps={{ shrink: true }} 
               className={"half-div " + (errMsg && ifsc === '' ? 'err' : '')} 
               value={ifsc} 
               onChange={(e) => setIfsc(e.target.value)} 
               />
            <TextField 
               required 
               label="Bank Name" 
               style={{ margin: 8 }} 
               margin="normal" 
               variant="filled"
               // InputLabelProps={{ shrink: true }} 
               className={"half-div " + (errMsg && bankName === '' ? 'err' : '')} 
               value={bankName} 
               onChange={(e) => setBankName(e.target.value)} 
               />

            <div className="break" style={{ height: '20px' }}></div>

            <div className="two-div">
               <div className="upload-option">
                  <input type="file" className="choose" id="cancelChequeId" onChange={cancelChequeChange} />
                  <label htmlFor="cancelChequeId" className="dragContent"><img src="upload.svg" />{cancelChequevalue === '' ? <span className='dragContentText'>Upload Scanned copy of cancelled cheque</span> : <div className="change-file">{cancelChequevalue}
                     <div className="delete-opt" onClick={deleteCancelChequevalue}><Grid item xs={8}>
                        <DeleteForeverIcon />
                     </Grid></div>
                  </div>}
                  </label>
               </div>
            </div>

            <div className="two-div">
            </div>

            <div className="action">
               <Button size="small" variant="contained" onClick={goBackVerifyPage} className="back" style={{fontSize:'14px',fontWeight:'bold' }}><Icon className="fa fa-chevron-left"></Icon>Back</Button>
               <Button size="small" variant="contained" color="secondary" className="primary-button forward" type="submit" style={{ color: '#000',fontSize:'14px',fontWeight:'bold' }}>NEXT<Icon className="fa fa-chevron-right"></Icon></Button>
            </div>
         </form>

      </div>
   </>
}

export default BankAccount