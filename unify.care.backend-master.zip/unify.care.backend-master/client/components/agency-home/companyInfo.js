import TextField from '@material-ui/core/TextField';
import Button from '@material-ui/core/Button';
import CircularProgress from '@material-ui/core/CircularProgress';
import MenuItem from '@material-ui/core/MenuItem';
import Select from '@material-ui/core/Select';
import InputLabel from '@material-ui/core/InputLabel';
import Grid from '@material-ui/core/Grid';
import DeleteForeverIcon from '@material-ui/icons/DeleteForever';
import { useState, useContext, useEffect } from 'react';
import axios from 'axios'
import { StepUpdateContext } from '../../context/registerStep'
import { UserUpdateContext } from '../../context/basiciSignup'
import { useRouter } from 'next/router'
import Icon from '@material-ui/core/Icon';
import { useAlert, types } from 'react-alert'
import config from '../../app.constant';
import { useCookies } from "react-cookie";

function CompanyInfo({ userData, type }) {
   const router = useRouter()
   const alert = useAlert()

   const { step, newStep } = useContext(StepUpdateContext);
   const { user, newUser } = useContext(UserUpdateContext);
   const [country, setCountry] = useState('India')
   const [state, setState] = useState('')
   const [corporateName, setCorporateName] = useState('')
   const [corporateId, setCorporateId] = useState('')
   const [corporateTaxId, setCorporateTaxId] = useState('')
   const [corporateSTaxId, setCorporateSTaxId] = useState('')
   const [websiteLink, setWebsiteLink] = useState('')
   const [addressLine1, setAddressLine1] = useState('')
   const [addressLine2, setAddressLine2] = useState('')
   const [city, setCity] = useState('')
   const [pin, setPin] = useState('')
   const [loader, setLoader] = useState(false)
   const [corporateIdUrl, setCorporateIdUrl] = useState('');
   const [corporateTaxIdUrl, setCorporateTaxIdUrl] = useState('');
   const [goodsAndServicesTaxIdUrl, setGoodsAndServicesTaxIdUrl] = useState('');

   const [userPhone, setUserPhone] = useState({})
   const [userEmail, setUserEmail] = useState({})
   const [cookies, getCookie] = useCookies(['name']);

   useEffect(() => {
      if (process.browser) {
         newUser(JSON.parse(localStorage.getItem('agencyinfo')));
      }
   }, [])
   useEffect(() => {
      if (Object.keys(userData).length !== 0) {
         setUserPhone(userData.mobileNumber)
         setUserEmail(userData.email)
      }
      else {
         setUserPhone(user.data.mobileNumber)
         setUserEmail(user.data.email)
      }
   }, [user])

   const [agencyList, setAgencyList] = useState([])
   const getAgencies = () => {
      let url = 'https://testapi.rufous.com/static/agency_types'
      axios.get(url)
         .then(response => {
            let tempArr = []
            if (response.data && response.data.length) {
               response.data.forEach((v) => tempArr.push(v.name))
            }
            setAgencyList(tempArr)
         })
         .catch(error => {
            console.log(error);
         });
   }

   const [uid, setUid] = useState('')
   useEffect(() => {
      if (process.browser) {
         setUid(localStorage.getItem('agencyuserId'))
      }
      getAgencies()
   }, [])

   const [stateList, setStateList] = useState('')
   const getStates = () => {
      setState('')
      setCity('')
      let url = 'https://testapi.rufous.com/static/cities?countryName=' + country
      axios.get(url)
         .then(response => {
            if (response.data) {
               setStateList(response.data)
            }
         })
         .catch(error => {
            console.log(error);
         });
   }

   useEffect(() => {
      getStates()
   }, [country])

   const [cityList, setCityList] = useState('')
   const getCities = () => {
      setCity('')
      let url = 'https://testapi.rufous.com/static/cities?countryName=' + country + '&stateName=' + state
      axios.get(url)
         .then(response => {
            if (response.data.cityList) {
               setCityList(response.data.cityList)
            }
         })
         .catch(error => {
            console.log(error);
         });
   }

   useEffect(() => {
      if (state !== '') {
         getCities()
      }
   }, [state])

   const goBackVerifyPage = (e) => {
      e.preventDefault()
      router.push('/otpverification')
   }
   const [corporatevalue, setCorporatevalue] = useState('')
   const [corporateTaxvalue, setCorporateTaxvalue] = useState('')
   const [corporateSTaxvalue, setCorporateSTaxvalue] = useState('')
   const [corporateFileName, setCorporateFileName] = useState('')
   const [corporateTaxFileName, setCorporateTaxFileName] = useState('')
   const [corporateSTaxFileName, setCorporateSTaxFileName] = useState('')

   const corporateChange = (e) => {
      e.preventDefault()
      let newVal = e.target.value.replace(/^.*[\\\/]/, '')
      setCorporatevalue(newVal)

      let file = document.getElementById('corporateId').files[0]
      let timestamp = new Date().getTime();
      let fileRe = file.name.replace(/[^a-zA-Z.]/g, "")
      let filename = ''
      filename = "agency/" + uid + "/" + timestamp + "_" + fileRe
      setCorporateFileName(filename)
   }
   const corporateTaxChange = (e) => {
      e.preventDefault()
      let newVal = e.target.value.replace(/^.*[\\\/]/, '')
      setCorporateTaxvalue(newVal)

      let file = document.getElementById('corporateTaxId').files[0]
      let timestamp = new Date().getTime();
      let fileRe = file.name.replace(/[^a-zA-Z.]/g, "")
      let filename = ''
      filename = "agency/" + uid + "/" + timestamp + "_" + fileRe
      setCorporateTaxFileName(filename)
   }
   const corporateSTaxChange = (e) => {
      e.preventDefault()
      let newVal = e.target.value.replace(/^.*[\\\/]/, '')
      setCorporateSTaxvalue(newVal)

      let file = document.getElementById('corporateSTaxId').files[0]
      let timestamp = new Date().getTime();
      let fileRe = file.name.replace(/[^a-zA-Z.]/g, "")
      let filename = ''
      filename = "agency/" + uid + "/" + timestamp + "_" + fileRe
      setCorporateSTaxFileName(filename)
   }

   const deleteCorporatevalue = (e) => {
      e.preventDefault()
      setCorporatevalue('')
      setCorporateFileName('')
   }

   const deleteCorporateTaxvalue = (e) => {
      e.preventDefault()
      setCorporateTaxvalue('')
      setCorporateTaxFileName('')
   }

   const deleteCorporateSTaxvalue = (e) => {
      e.preventDefault()
      setCorporateSTaxvalue('')
      setCorporateSTaxFileName('')
   }


   const fetchCompanyDetails = async () => {
      try {
         let cookie = ''
         for (const [key, value] of Object.entries(cookies)) {
            if (key === 'express:sess') {
               cookie = value;
            }
         }
         let headers = {
            'authtoken': cookie
         }
         const url = config.API_URL + '/api/partner/information';
         setLoader(true)
         const response = await axios.get(url, { headers });

         console.log(response.data);

         if (response.data) {
            const {
               legalName, website,
               addressLine1, addressLine2, city, state, country,
               pincode, corporateId, corporateIdUrl, corporateTaxId, corporateTaxIdUrl, goodsAndServicesTaxId,
               goodsAndServicesTaxIdUrl
            } = response.data;

            setCorporateName(legalName);
            setWebsiteLink(website);
            setCorporateId(corporateId);
            setCorporateTaxId(corporateTaxId);
            setCorporateSTaxId(goodsAndServicesTaxId);
            let newVal = corporateIdUrl.replace(/^.*[\\\/]/, '');
            setCorporatevalue(newVal);
            setCorporateFileName(corporateIdUrl);
            newVal = corporateTaxIdUrl.replace(/^.*[\\\/]/, '')
            setCorporateTaxvalue(newVal)
            setCorporateTaxFileName(corporateTaxIdUrl)
            newVal = goodsAndServicesTaxIdUrl.replace(/^.*[\\\/]/, '')
            setCorporateSTaxvalue(newVal)
            setCorporateSTaxFileName(goodsAndServicesTaxIdUrl)
            setAddressLine1(addressLine1)
            setAddressLine2(addressLine2)
            setPin(pincode)
            setTimeout(function () {
               setCountry(country)
            }, 1000)
            setTimeout(function () {
               setState(state)
            }, 2000)
            setTimeout(function () {
               setCity(city)
            }, 3000)
         }
         setLoader(false)

      } catch (err) {
         console.error(err);
         setLoader(false)
      }
   }

   //using this method to get the data when this page open
   useEffect(() => {
      fetchCompanyDetails()
   }, [])

   const [errMsg, setErrMsg] = useState(false)
   let documentarr = []

   const submitCompanyInfo = (e) => {
      e.preventDefault()
      setErrMsg(false)
      if (corporatevalue === '' || corporateTaxvalue === '' || corporateSTaxvalue === '' || country === '' || state === '' || city === '') {
         setErrMsg(true)
         alert.show('All fields are required', { type: 'error' })
         return false
      }

      documentarr = []

      if (corporatevalue !== '') {
         documentarr.push({ name: 'Corporate ID', id: 'corporateId', key: corporatevalue, filename: corporateFileName })
      }
      if (corporateTaxvalue !== '') {
         documentarr.push({ name: 'Corporate Tax ID', id: 'corporateTaxId', key: corporateTaxvalue, filename: corporateTaxFileName })
      }
      if (corporateSTaxvalue !== '') {
         documentarr.push({ name: 'Corporate Service Tax ID', id: 'corporateSTaxId', key: corporateSTaxvalue, filename: corporateSTaxFileName })
      }

      console.log(documentarr)
      setLoader(true)
      if (documentarr.length > 0) {
         uploadImages()
      } else {
         finalsave(corporateIdUrl, corporateTaxIdUrl, goodsAndServicesTaxIdUrl);
      }
   }

   const uploadImages = () => {
      let corporateIdUrlOfStoredLocation = null;
      let corporateTaxIdUrlOfStoredLocation = null;
      let goodsAndServicesTaxIdUrlOfStoredLocation = null;
      const saveImage = (a) => {
         var model = {
            file: document.getElementById(documentarr[a].id).files[0]
         };
         let cookie = ''
         for (const [key, value] of Object.entries(cookies)) {
            if (key === 'express:sess') {
               cookie = value;
            }
         }

         var configs = {
            headers: { 'Content-Type': 'multipart/form-data', 'type': 'formData', 'authtoken': cookie },
            transformRequest: function (object) {
               var formData = new FormData();
               for (var prop in object) {
                  formData.append(prop, object[prop]);
               }
               return formData;
            }
         };

         axios.post(config.API_URL + '/api/file-manager/upload', model, configs)
            .then(response => {
               console.log(response.data)
               if (a == 0) {
                  corporateIdUrlOfStoredLocation = response.data.fileName;
                  setCorporateIdUrl(response.data.fileName);
               }
               if (a == 1) {
                  corporateTaxIdUrlOfStoredLocation = response.data.fileName;
                  setCorporateTaxIdUrl(response.data.fileName);
               }
               if (a == 2) {
                  goodsAndServicesTaxIdUrlOfStoredLocation = response.data.fileName;
                  setGoodsAndServicesTaxIdUrl(response.data.fileName);
               }
               if (a < (documentarr.length - 1)) {
                  saveImage(a + 1);
               } else if (a === (documentarr.length - 1)) {
                  console.log('after saving images, finalcall');
                  finalsave(corporateIdUrlOfStoredLocation,
                     corporateTaxIdUrlOfStoredLocation,
                     goodsAndServicesTaxIdUrlOfStoredLocation);
               }
            })
            .catch(error => {
               console.log(error);
               alert.show('Api error, please try after some time', { type: 'error' })
               setLoader(false)
            });
      };
      saveImage(0);
   }

   const finalsave = (corporateIdUrlOfStoredLocation,
      corporateTaxIdUrlOfStoredLocation,
      goodsAndServicesTaxIdUrlOfStoredLocation) => {
      setLoader(false)
      let cookie = ''
      for (const [key, value] of Object.entries(cookies)) {
         if (key === 'express:sess') {
            cookie = value;
         }
      }
      let headers = {
         'authtoken': cookie
      }
      let obj =
      {
         legalName: corporateName,
         website: websiteLink,
         addressLine1: addressLine1,
         addressLine2: addressLine2,
         city: city,
         state: state,
         country: country,
         pincode: pin,
         corporateId: corporateId,
         corporateIdUrl: corporateIdUrlOfStoredLocation,
         corporateTaxId: corporateTaxId,
         corporateTaxIdUrl: corporateTaxIdUrlOfStoredLocation,
         goodsAndServicesTaxId: corporateSTaxId,
         goodsAndServicesTaxIdUrl: goodsAndServicesTaxIdUrlOfStoredLocation,
      }

      setLoader(true)
      const url = config.API_URL + '/api/partner/information'
      axios.post(url, obj, { headers })
         .then(response => {
            console.log(response.data)
            setLoader(false)
            newStep(parseInt(step) + 1)
            router.push('/companydetails?authoritySign')
         })
         .catch(error => {
            setLoader(false)
            alert.show('Api error', { type: 'error' })
            console.log(error);
         });
   }

   const signout = async () => {
      await axios.post(config.API_URL + '/api/users/signout')
         .then(() => {
            router.push('/')
         })
         .catch(error => {
            console.log(error);
            alert.show('API error', { type: 'error' })
         });
   }

   return <>
      <div
         style={{
            // display: "flex",
            // flexDirection: "row",
            // background: "#2b2b2b",
         }}
      >
         {/* <Button
            size="small"
            variant="contained"
            color="secondary"
            className="primary-button"
            onClick={signout}
            style={{ margin: "20px 20px 20px 900px" }}
         >
            Logout
            </Button> */}
         <div style={{ textAlign: 'end' }}>
            <img style={{ height: '25px' }} src="bell.png" />
            <img style={{ height: '25px', marginLeft: '12px', borderRadius:'50%', border:'1px solid #a9a9a9'}} src="user.svg" />
         </div>
      </div>
      {loader && <div className="loader"><CircularProgress color="secondary" /><div className="text">Uploading Company Information</div></div>}
      <h2>Establishment Details</h2>
      <div className="form-input companyInfo">
         <form noValidate autoComplete="off" onSubmit={submitCompanyInfo}>
            <div className="mainForm">
               <TextField
                  required
                  label="Legal Name"
                  style={{ margin: 8 }}
                  margin="normal"
                  variant="filled"
                  // InputLabelProps={{ shrink: true }} 
                  className={"half-div " + (errMsg && corporateName === '' ? 'err' : '')}
                  value={corporateName}
                  onChange={(e) => setCorporateName(e.target.value)}
               />
               <TextField
                  required
                  label="Website"
                  style={{ margin: 8 }}
                  margin="normal"
                  variant="filled"
                  // InputLabelProps={{ shrink: true }} 
                  className={"half-div " + (errMsg && websiteLink === '' ? 'err' : '')}
                  value={websiteLink}
                  onChange={(e) => setWebsiteLink(e.target.value)}
               />

               <div className="break"></div>

               <TextField
                  required
                  label="Address Line 1"
                  style={{ margin: 8 }}
                  margin="normal"
                  variant="filled"
                  // InputLabelProps={{ shrink: true }} 
                  className={"half-div " + (errMsg && addressLine1 === '' ? 'err' : '')}
                  value={addressLine1}
                  onChange={(e) => setAddressLine1(e.target.value)}
               />
               <TextField
                  required
                  label="Address Line 2"
                  style={{ margin: 8 }}
                  margin="normal"
                  variant="filled"
                  // InputLabelProps={{ shrink: true }} 
                  className={"half-div " + (errMsg && addressLine2 === '' ? 'err' : '')}
                  value={addressLine2}
                  onChange={(e) => setAddressLine2(e.target.value)}
               />

               <div className="break"></div>

               <div className="info-div">
                  <div className={"selection-div " + (errMsg && country === '' ? 'err' : '')}>
                     {/* <InputLabel shrink htmlFor="service-label">Country*</InputLabel> */}
                     <TextField
                        select
                        // labelId="country-label"
                        label='Country'
                        id="country"
                        value={country}
                        required
                        margin="normal"
                        variant="filled"
                        onChange={(e) => setCountry(e.target.value)}
                        // displayEmpty
                        className={"half-div  mar-left-10 newblock " + (country === '' ? 'err1' : '')}
                     >
                        <MenuItem value={'India'}>India</MenuItem>
                        <MenuItem value={'USA'}>USA</MenuItem>
                     </TextField>
                  </div>
                  <div className={"selection-div some-align " + (errMsg && state === '' ? 'err' : '')}>
                     {/* <InputLabel shrink htmlFor="service-label">State*</InputLabel> */}
                     <TextField
                        // labelId="state-label"
                        select
                        label="State"
                        id="state"
                        value={state}
                        required
                        margin="normal"
                        variant="filled"
                        onChange={(e) => setState(e.target.value)}
                        // displayEmpty
                        className={"half-div  mar-left-10 newblock " + (state === '' ? 'err1' : '')}
                     >
                        <MenuItem value="" disabled></MenuItem>
                        {stateList.length > 0 && stateList.map((st, id) => (
                           <MenuItem key={"st-" + id} value={st}>{st}</MenuItem>
                        ))}
                     </TextField>
                  </div>
               </div>
               <div className="info-div">
                  <div className={"selection-div " + (errMsg && city === '' ? 'err' : '')}>
                     {/* <InputLabel shrink htmlFor="service-label">City*</InputLabel> */}
                     <TextField
                        // labelId="city-label"
                        select
                        label="City"
                        id="city"
                        value={city}
                        required
                        margin="normal"
                        variant="filled"
                        onChange={(e) => setCity(e.target.value)}
                        // displayEmpty
                        className={"half-div  mar-left-10 newblock " + (city === '' ? 'err1' : '')}
                     >
                        <MenuItem value="" disabled>
                        </MenuItem>
                        {cityList.length > 0 && cityList.map((st, id) => (
                           <MenuItem key={"st-" + id} value={st.name}>{st.name}</MenuItem>
                        ))}
                     </TextField>
                  </div>
                  <TextField
                     required
                     label="PIN"
                     style={{ margin: '6px 8px' }}
                     margin="normal"
                     variant="filled"
                     // InputLabelProps={{ shrink: true }} 
                     className={"more " + (errMsg && pin === '' ? 'err' : '')}
                     value={pin}
                     onChange={(e) => setPin(e.target.value)}
                  />
               </div>

               <div className="break"></div>

               <div className="three-div">
                  <TextField
                     required
                     label="Corporate ID"
                     style={{ margin: 8 }}
                     margin="normal"
                     variant="filled"
                     // InputLabelProps={{ shrink: true }} 
                     className={"more " + (errMsg && corporateId === '' ? 'err' : '')}
                     value={corporateId}
                     onChange={(e) => setCorporateId(e.target.value)}
                  />
                  <div className="upload-option">
                     <input type="file" className="choose" id="corporateId" onChange={corporateChange} />
                     <label htmlFor="corporateId" className="dragContent"><img src="upload.svg" />{corporatevalue === '' ? 'Upload Scanned copy of Certificate of Incorporation (COI)' : <div className="change-file">{corporatevalue}
                        <div className="delete-opt" onClick={deleteCorporatevalue}><Grid item xs={8}>
                           <DeleteForeverIcon />
                        </Grid></div>
                     </div>}
                     </label>
                  </div>
               </div>

               <div className="three-div">
                  <TextField
                     required
                     label="Corporate Tax ID"
                     style={{ margin: 8 }}
                     variant="filled"
                     margin="normal"
                     // InputLabelProps={{ shrink: true }} 
                     className={"more " + (errMsg && corporateTaxId === '' ? 'err' : '')}
                     value={corporateTaxId}
                     onChange={(e) => setCorporateTaxId(e.target.value)}
                  />
                  <div className="upload-option">
                     <input type="file" className="choose" id="corporateTaxId" onChange={corporateTaxChange} />
                     <label htmlFor="corporateTaxId" className="dragContent"><img src="upload.svg" />{corporateTaxvalue === '' ? 'Upload Scanned copy of Permanent Account Number (PAN) Card' : <div className="change-file">{corporateTaxvalue}
                        <div className="delete-opt" onClick={deleteCorporateTaxvalue}><Grid item xs={8}>
                           <DeleteForeverIcon />
                        </Grid></div>
                     </div>}
                     </label>
                  </div>
               </div>

               <div className="three-div">
                  <TextField
                     required
                     label="Good & Services Tax ID"
                     style={{ margin: 8 }}
                     margin="normal"
                     variant="filled"
                     // InputLabelProps={{ shrink: true }} 
                     className={"more " + (errMsg && corporateSTaxId === '' ? 'err' : '')}
                     value={corporateSTaxId}
                     onChange={(e) => setCorporateSTaxId(e.target.value)}
                  />
                  <div className="upload-option">
                     <input type="file" className="choose" id="corporateSTaxId" onChange={corporateSTaxChange} />
                     <label htmlFor="corporateSTaxId" className="dragContent"><img src="upload.svg" />{corporateSTaxvalue === '' ? 'Upload Scanned copy of GST Certificate' : <div className="change-file">{corporateSTaxvalue}
                        <div className="delete-opt" onClick={deleteCorporateSTaxvalue}><Grid item xs={8}>
                           <DeleteForeverIcon />
                        </Grid></div>
                     </div>}
                     </label>
                  </div>
               </div>
            </div>


            <div className="action">
               <Button size="small" variant="contained" onClick={goBackVerifyPage} className="back" style={{fontSize:'14px',fontWeight:'bold' }}><Icon className="fa fa-chevron-left"></Icon>Back</Button>
               <Button size="small" variant="contained" color="secondary" className="primary-button forward" type="submit" style={{ color: '#000',fontSize:'14px',fontWeight:'bold' }}>NEXT<Icon className="fa fa-chevron-right"></Icon></Button>
            </div>
         </form>

      </div>
   </>
}

export default CompanyInfo