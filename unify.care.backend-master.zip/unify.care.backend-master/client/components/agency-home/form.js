import { useState, useContext, useEffect } from 'react';
import { StepUpdateContext } from '../../context/registerStep'
import UserUpdateProvider from '../../context/basiciSignup';
import BasicForm from './basicForm';
import VerificationForm from './verificationForm';
import CompanyInfo from './companyInfo';
import AuthoritySign from './authoritySign';
import BankAccount from './bankAccount';
import FinalMessage from './finalMessage';

function Form({ userData, type}) {
   const { step, newStep } = useContext(StepUpdateContext);
   const [pageName, setPageName] = useState(0)
   // { key: 'register', num: 0 }, { key: 'verification', num: 1 },
   const allSteps = [{ key: 'companydetails', num: 0 }, { key: 'authority', num: 1 }, { key: 'bankdetails', num: 2 }, { key: 'finalpage', num: 3 }]

   useEffect(() => {
      const name = allSteps[parseInt(step)].key
      setPageName(name)
   }, [step])

   return <UserUpdateProvider>
      <div className="form-area">
         {pageName === 'companydetails' && <div>
            {/* adding company information form step 3 */}
            <CompanyInfo type={type} userData={userData}/>
         </div>}
         {pageName === 'authority' && <div>
            {/* adding authority sign form step 3 */}
            <AuthoritySign type={type} userData={userData} />
         </div>}
         {pageName === 'bankdetails' && <div>
            {/* adding bank details form step 3 */}
            <BankAccount type={type} userData={userData} />
         </div>}
         {pageName === 'finalpage' && <div>
            {/* adding final page form step 3 */}
            <FinalMessage type={type} />
         </div>}
      </div>
   </UserUpdateProvider>
}

export default Form