import { useState, useEffect } from 'react';
import Form from '../components/agency-home/form';
import StepUpdateProvider from '../context/registerStep';
import Steps from '../components/agency-home/steps';
import { useRouter } from 'next/router'
import { transitions, positions, Provider as AlertProvider } from 'react-alert'
import AlertTemplate from 'react-alert-template-basic'
import Head from 'next/head';
import BasicForm from '../components/agency-home/basicForm';
import CompanyInfo from '../components/agency-home/companyInfo';


// optional configuration
const options = {
   // you can also just use 'bottom center'
   position: positions.TOP_CENTER,
   timeout: 5000,
   offset: '10px',
   // you can also just use 'scale'
   transition: transitions.SCALE
}

function CompanyDetails() {
   const router = useRouter()
   const [stepName, setStepName] = useState(0)
   const [userData, setUserData] = useState({})

   useEffect(() => {
      if (router.asPath.includes('authoritySign')) {
         if (process.browser) {
            if (localStorage.getItem('agencyinfo')) {
               setStepName('authority')
               setUserData(JSON.parse(localStorage.getItem('agencyinfo')))
            } else {
               router.push('companydetails')
            }
         }
      } else if (router.asPath.includes('bankAccount')) {
         if (process.browser) {
            if (localStorage.getItem('agencyinfo')) {
               setStepName('bankdetails')
               setUserData(JSON.parse(localStorage.getItem('agencyinfo')))
            } else {
               router.push('companydetails')
            }
         }
      } else if (router.asPath.includes('finalMessage')) {
         if (process.browser) {
            if (localStorage.getItem('agencyinfo')) {
               setStepName('finalpage')
               setUserData(JSON.parse(localStorage.getItem('agencyinfo')))
            } else {
               router.push('companydetails')
            }
         }
      } else if (router.asPath === '/companydetails') {
         setStepName('companydetails')
         if (localStorage.getItem('agencyinfo')) {
            setUserData(JSON.parse(localStorage.getItem('agencyinfo')))
         } 
      }
   }, [router])

   return <>

      <AlertProvider template={AlertTemplate} {...options}>
         <Head>
            <title>Unify Care: Partner</title>
            <link rel="icon" href="/favicon.png" />
            <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" />
            <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons" />
         </Head>
         <StepUpdateProvider>
            <div className="register-agency">
               <div className="register-menu">
                  <Steps name={stepName} type={'agency'} />
               </div>
               <div className="register-body">
                  <Form userData={userData} type={'agency'}/>
               </div>
            </div>
         </StepUpdateProvider>
      </AlertProvider>
   </>
}

export default CompanyDetails