import '../styles/globals.css';
import '../styles/globalStyles.css';
import '../components/agency-home/agency-home.css';
import '../styles/Calendar.css';
import buildClient from '../api/build-client';
import config from '../app.constant';
import AlertTemplate from 'react-alert-template-basic';
import { transitions, positions, Provider as AlertProvider } from 'react-alert';
const options = {
  // you can also just use 'bottom center'
  position: positions.TOP_CENTER,
  timeout: 5000,
  offset: '10px',
  // you can also just use 'scale'
  transition: transitions.SCALE
};

const AppComponent = ({ Component, pageProps, currentUser }) => {
  return (
    <AlertProvider template={AlertTemplate} {...options}>
      <div>
        <div className="container">
          <Component currentUser={currentUser} {...pageProps} />
        </div>
      </div>
    </AlertProvider>
    
  );
};

AppComponent.getInitialProps = async (appContext) => {
  const client = buildClient(appContext.ctx);
  // const { data } = await client.get('/api/users/currentuser');
  const data = {currentUser : {}};

  let pageProps = {};
  if (appContext.Component.getInitialProps) {
    pageProps = await appContext.Component.getInitialProps(
      appContext.ctx,
      client,
      data.currentUser
    );
  }

  return {
    pageProps,
    ...data,
  };
};

export default AppComponent;
