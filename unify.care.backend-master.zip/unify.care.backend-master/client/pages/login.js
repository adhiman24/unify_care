import React, { useState, useEffect } from 'react';
import TextField from "@material-ui/core/TextField";
import Button from "@material-ui/core/Button";
import CircularProgress from "@material-ui/core/CircularProgress";
import useRequest from '../hooks/use-request';
import { useRouter } from "next/router";
import { makeStyles } from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';
import CssBaseline from '@material-ui/core/CssBaseline';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import Link from '@material-ui/core/Link';
import Box from '@material-ui/core/Box';
import Grid from '@material-ui/core/Grid';
import LockOutlinedIcon from '@material-ui/icons/LockOutlined';
import Typography from '@material-ui/core/Typography';
import UserType from '../types/user-type';
import PartnerStates from '../types/partner-states';
import config from '../app.constant';
import {useCookies } from "react-cookie";
import Head from 'next/head';

const passwordType = {
  password: 'password',
  text: 'text'
}

const useStyles = makeStyles(() => ({
  root: {
    display: 'flex',
    '& > *': {
      margin: '100px 20px 20px 500px',
      width: '500px',
      height: '00px',
    },
  },
  textbox: {
    '& .MuiTextField-root': {
      margin: '20px 20px 1px 75px',
      width: '300px',
      height: '50px',
    },
  },
  button: {
    '& > *': {
      margin: '20px 20px 1px 150px',
      width: '150px',
    },
  },
}));

const MIN_PASSWORD_LENGTH = 6;
const Signin = ({ currentUser, userState }) => {

  const classes = useStyles();

  const [cookies, setCookie] = useCookies(['name']);

  const Router = useRouter();

  const [emailId, setEmailId] = useState('')
  const [password, setPassword] = useState('')
  const [emailError, setEmailError] = useState(false)
  const [passwordError, setPasswordError] = useState(false)
  const [validationErr, setValidationErr] = useState(false)

  const [loader, setLoader] = React.useState(false);

  const { doRequest, errors } = useRequest({
    url: config.API_URL + '/api/users/employeesignin',
    method: 'post',
    body: {
      emailId,
      password
    },
    onSuccess: (response) => {
      
      console.log(response)

      if(response.token){
        if(process.browser){
          setCookie('express:sess', response.token, { path: '/' });
        }
      }

      // Router.push('/rosterManagerHomePage');

      if (response.userType === UserType.Doctor) {
        Router.push('/doctorHomePage');
      }
      if (response.userType === UserType.PartnerRosterManager) {
        Router.push('/rosterManagerHomePage');
      }
      if (response.userType === UserType.CustomerSupport) {
        Router.push('/customerSupportHomePage');
      }
      if (response.userType === UserType.PartnerSuperuser) {
        if (response.userStatus === 'unverified') {
          return Router.push('/register?verifyAgency');
        } else {
          Router.push('/listing');
          // Router.push('/');
        }
      }
      // setLoader(false)
    }
  });

  const expression = /(?!.*\.{2})^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([\t]*\r\n)?[\t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([\t]*\r\n)?[\t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i;

  const validateEmailId = (email) => {
    setEmailId(email);

    if (expression.test(String(email).toLowerCase())) {
      setEmailError(false);
    } else {
      setEmailError(true);
    }
  }
  const validatePassword = (pwd) => {
    setPassword(pwd);

    if (pwd.length < MIN_PASSWORD_LENGTH) {
      setPasswordError(true);
    } else {
      setPasswordError(false);
    }
  }

  const userSigninHandler = async (event) => {
    event.preventDefault()
    setValidationErr(false)
    if (emailId && password) {
      setLoader(true);
      await doRequest();
    } else {
      setValidationErr(true)
    }
  }

  return <>
    {loader && !errors && (
      <div className="loader">
        <CircularProgress color="secondary" />
      </div>
    )}
    <Head>
         <title>Unify Care: Login</title>
         <link rel="icon" href="/favicon.png" />
         <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" />
         <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons" />
      </Head>
    <div className="mainDiv">
      <div className="leftSide">
        <div className="leftLogo">
            <img src="logoBranding.svg" className="logo" />
            {/* <img src="logo_unifycare.svg" className="logo" />
            <img src="unify_name.svg" className="name" />
            <img src="your-health-partner.svg" className="partner" /> */}
        </div>
      </div>
      <div className="vl"></div>
      <div className="rightSide">
        <Paper className='form'>
          
          <form noValidate autoComplete="off" onSubmit={userSigninHandler}>
            <div className='mainForm'>
              <Typography component="h1" variant="h5" style={{marginBottom:'15px'}}>
                Login to your Account
              </Typography>
              <TextField
                  required
                  label="Email"
                  // InputLabelProps={{
                  //   shrink: true,
                  // }}
                  fullWidth
                  style={{ margin: 8 }} 
                  margin="normal" 
                  variant="filled"
                  autoComplete="off"
                  helperText={emailError ? <span style={{ color: "red" }}>Please Enter valid email address</span> : validationErr && emailId === '' ? <span style={{ color: "red" }}>required</span> : ''}
                  value={emailId}
                  onChange={(e) => validateEmailId(e.target.value)}
                />

              <TextField
                required
                label="Password"
                // InputLabelProps={{
                //   shrink: true,
                // }}
                type="password"
                style={{ margin: 8 }} 
                margin="normal" 
                variant="filled"
                fullWidth
                // variant="outlined"
                autoComplete="off"
                helperText={passwordError ? <span style={{ color: "red" }}>Password must be 6 character or more</span> : validationErr && password === '' ? <span style={{ color: "red" }}>required</span> : ''}
                value={password}
                onChange={(e) => validatePassword(e.target.value)}
              />
              {/* <div className={classes.button}> */}
              <Button
                className="loginBtn primary-button"
                variant="contained"
                color="secondary"
                type="submit"
              >
                LOGIN
              </Button>
            {/* </div> */}
            </div>
            {/* <div className={classes.textbox}> */}
             
            {/* </div> */}
            {/* <div className={classes.textbox}> */}
              
            {/* </div> */}
            
          </form>
          {errors}
        </Paper>
      </div>
      
    </div>
  </>
}

export default Signin