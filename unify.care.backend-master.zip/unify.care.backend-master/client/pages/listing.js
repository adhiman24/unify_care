import { useState, useEffect } from 'react';
import CircularProgress from '@material-ui/core/CircularProgress';
import Head from 'next/head';
import Header from '../components/header/header'
import FilterArea from '../components/listing/filter-area'
import EmployeeTable from '../components/listing/employee-table'
function Listing(){
  
   const [loader, setLoader] = useState(false);
   const [updateList, setUpdateList] = useState('');
   // const departmentType = [
   //    {name: 'Outpatient', value: 'outpatient-department'}, {name: 'Medical', value: 'medical-department'},{name: 'Pathology', value: 'pathology-department'}, {name: 'Pharmacy', value: 'pharmacy-department'}, {name: 'Radiology', value: 'radiology-department'}, {name: 'Dietary', value:  'dietary-department'}, {name: 'Customer Support Executive', value: 'customer-support'}, {name: 'Non Professional Services', value: 'non-professional-services'}, {name: 'Medical Record', value: 'medical-record-department'},
   // ]
   // const designationType =[
   //    {name: 'Superuser', value: 'facility:superuser'}, {name: 'Manager', value: 'facility:manager'}, {name: 'Employee Admin', value: 'employee:admin'}, {name: 'Doctor', value: 'doctor'}, {name: 'Nutritionist', value: 'nutritionist'}, {name: 'Educator', value: 'educator'}, {name: 'Customer Support Executive', value: 'customer:support'}, {name: 'Roster Manager', value: 'roster:manager'}, {name: 'Patient', value: 'patient'},
   // ]
   // ,{name: 'Senior Nurse', value: 'senior-nurse'},{name: 'Nurse', value: 'nurse'}
   
   return <>
      {loader && <div className="loader"><CircularProgress color="secondary" /><div className="text"></div></div>}
      <Head>
         <title>Unify Care: Employees Manager</title>
         <link rel="icon" href="/favicon.png" />
         <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" />
         <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons" />
      </Head>
      <div className="left-area">
         <div className="unifyLogo">
            <img src="logo.svg" className="logo" />
            <img src="unify_care.svg" className="name" />
         </div>
         <div className="menu-items">
            <div className="items active">
               <img src="employees.svg" className="logo" />
               <span>EMPLOYEE MANAGER</span>
            </div>
            {/* <div className="items" onClick={toRosterMgr}>
               <img src="roaster.svg" className="logo" style={{padding:'5px'}} />
               <span>ROASTER MANAGER</span>
            </div>
            <div className="items"  onClick={toSupportCenter}>
               <img src="support.svg" className="logo" style={{padding:'5px'}}/>
               <span>APPOINTMENT MANAGER</span>
            </div> */}
         </div>
      </div>
      <div className="right-area listing">
         <Header name ='Employees Manager'/>
         
         <FilterArea updateList={setUpdateList}/>
       
         <EmployeeTable updateList={updateList}/>

      </div>
   </>
}

export default Listing