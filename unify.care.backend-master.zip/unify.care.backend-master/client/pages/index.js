import { useEffect, useState } from 'react';
import Head from 'next/head';
import Link from 'next/link';
import Card from '@material-ui/core/Card';
import CardActionArea from '@material-ui/core/CardActionArea';
import CardMedia from '@material-ui/core/CardMedia';
import Button from '@material-ui/core/Button';
import PartnerStates from '../types/partner-states';
import UserType from '../types/user-type';
import Router from 'next/router'
import React from 'react';
import CssBaseline from '@material-ui/core/CssBaseline';
import Typography from '@material-ui/core/Typography';
import Container from '@material-ui/core/Container';
import CircularProgress from '@material-ui/core/CircularProgress';

const PartnerLandingPage = ({ currentUser, userState }) => {
  const [loader, setLoader] = useState(false);
  const fetchData = async () => {
    try {
      if (currentUser) {
        if (currentUser.uty === UserType.PartnerSuperuser) {
          if (currentUser.ust === 'unverified') {
            return Router.push('/register?verifyAgency');
          }
          if (userState === PartnerStates.AddPartnerInformation) {
            return Router.push('register?companyInfo');
          }
          if (userState === PartnerStates.AddPartnerBankingDetails) {
            return Router.push('register?bankAccount');
          }
          if (userState === PartnerStates.AddPartnerSigningAuth) {
            return Router.push('register?authoritySign');
          }
          if (userState === PartnerStates.PartnerVerifiedAndActive) {
            return Router.push('register?finalMessage');
          }
          if (userState === PartnerStates.PartnerVerificationPending) {
            return Router.push('register?finalMessage');
          }
          if (userState === PartnerStates.PartnerVerifiedAndActive) {
            return Router.push('agencyPage');
          }
        }
      }
    } catch (error) {
      throw error;
    }
  };

  useEffect(() => {
    fetchData()
      .then()
      .catch(error => {
        console.warn(JSON.stringify(error, null, 2));
      });
  }, []);

  return (
    <div>
      {loader && <div className="loader"><CircularProgress color="secondary" /><div className="text"></div></div>}
      <Head>
        <title>Unify Care</title>
        <link rel="icon" href="/favicon.png" />
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" />
        <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons" />
      </Head>
      <div className="container" style={{backgroundColor:'#fff'}}>
        {/* <div
          style={{
            display: "flex",
            flexDirection: "row",
            background: "#2b2b2b",
          }}
        >
          <Link href="/register">
            <Button
              size="small"
              variant="contained"
              color="secondary"
              className="primary-button"
              style={{ margin: "20px 20px 20px 1000px" }}
            >
              Register Now as Partner
            </Button>
          </Link>
          <Link href="/login">
            <Button
              size="small"
              variant="contained"
              color="secondary"
              className="primary-button"
              style={{ margin: "20px 20px 20px 20px" }}
            >
              Login
            </Button>
          </Link>
        </div> */}
         <CssBaseline />
        <Container maxWidth="xl" style={{width:'80%'}}>
          <Typography component="div" style={{ backgroundColor: '#fff', height: '60vh' }} >
            <div style={{paddingTop:'4%'}}>
              <Card style={{width:'20%', height:'100%',float:'left',boxShadow:'none'}}>
                <CardActionArea className="area">
                  <CardMedia
                    component="img"
                    // className="sec-img"
                    alt="Logo"
                    image="logo-new.png"
                    title="Logo"
                    style={{width:'80%',height:'80%'}}
                  />
                </CardActionArea>
              </Card>
              <Link href="/login">
                <Button
                  size="small"
                  variant="contained"
                  color="secondary"
                  className="primary-button"
                  style={{width:'100px', float:'right', color:'black' }}
                  onClick={()=>setLoader(true)}
                >
                  Login
                </Button>
              </Link>
            </div>
            <div style={{width:'100%',position:'relative',marginTop:'7%'}}>
              <div style={{width:'48%', float:'left',position:'absolute'}}>
                  <Typography paragraph style={{fontSize:'28px',fontWeight:'bold'}}>
                      Hello Doctors, <br />
                      Your hospital is now running online.
                  </Typography>
                  <Typography paragraph style={{fontSize:'13px'}}>
                      Now a days everything is available online then why not your hospital. Unify care is a digital healthcare platform which enables hospitals to go online.
                  </Typography>
                  <Link href="/register">
                    <Button
                      size="small"
                      variant="contained"
                      color="secondary"
                      className="primary-button"
                      style={{ margin: "20px 20px 20px 0px", color:'black', width:'135px'}}
                      onClick={()=>setLoader(true)}
                    >
                      Get started
                    </Button>
                  </Link>
              </div>
              <div style={{width:'48%', float:'right',position:'relative'}}>
                  <Card className="section" style={{width:'100%', height:'100%',boxShadow:'none'}}>
                    <CardActionArea className="area">
                      <CardMedia
                        component="img"
                        // className="sec-img"
                        alt="Partner"
                        image="home-image.jpg"
                        title="Partner"
                        style={{width:'80%',height:'80%'}}
                      />
                    </CardActionArea>
                  </Card>
              </div>
            </div>
          </Typography>
        </Container>
        <div style={{height:'20%', backgroundImage:'linear-gradient(#425ca2, #00b6f7)',display:'inline-block',width:'100%'}}>
        <Container maxWidth="xl" style={{width:'80%', marginTop:'2%'}}>
          <Typography paragraph style={{color:'#fff'}}>
            Hello Patients, <br />
            now consult superspecialist doctors from<br />
            the comfort of your home.
          </Typography>
          <Link href="/">
            <Button
              disabled
              size="small"
              variant="contained"
              color="secondary"
              className="primary-button"
              style={{ margin: "10px 20px 15px 0px", color:'black', width:'135px'}}
            >
              Consult Now
            </Button>
          </Link>
        </Container>
        </div>
        {/* <div className="container" style={{width:'50%', float:'left'}}>
          <h1>Hello Doctors,</h1>
        </div>
        <div className="container" style={{width:'50%', float:'right'}}>
          <Card className="section" style={{width:'100%', height:'100%'}}>
            <CardActionArea className="area">
              <CardMedia
                component="img"
                // className="sec-img"
                alt="Partner"
                image="home-image.jpg"
                title="Partner"
                style={{width:'80%',height:'80%'}}
              />
            </CardActionArea>
          </Card>
        </div> */}
        {/* <Card className="section" style={{ maxWidth: 1200, margin: 'auto' }}>
          <CardActionArea className="area">
            <CardMedia
              component="img"
              className="sec-img"
              alt="Partner"
              image="home-image.jpg"
              title="Partner"
            />
          </CardActionArea>
        </Card> */}
      </div>
    </div >
  )
};

PartnerLandingPage.getInitialProps = async (context, client, currentUser) => {
  if (currentUser && (currentUser.uty === UserType.PartnerSuperuser)) {
    const { data } = await client.get('/api/partner');

    return { userState: data.currentState };
  }
};

export default PartnerLandingPage;