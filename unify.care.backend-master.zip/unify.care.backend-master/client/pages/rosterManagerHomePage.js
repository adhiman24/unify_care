import Router from 'next/router';
import React, { useEffect, useState } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import axios from 'axios';
import config from '../app.constant';
import {useCookies } from "react-cookie";
import SearchIcon from '@material-ui/icons/Search';
import InputBase from '@material-ui/core/InputBase';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import MenuItem from '@material-ui/core/MenuItem';
import Card from '@material-ui/core/Card';
import CardActionArea from '@material-ui/core/CardActionArea';
import CardContent from '@material-ui/core/CardContent';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import TextField from '@material-ui/core/TextField';
import time from '../data/time.json';
import days from '../data/day.json';
import Calendar from 'react-calendar';
import CircularProgress from '@material-ui/core/CircularProgress';
// import 'react-calendar/dist/Calendar.css';
import { useAlert, types } from 'react-alert';
import Head from 'next/head';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogTitle from '@material-ui/core/DialogTitle';
import Header from '../components/header/header';
import FilterArea from '../components/roster-manager/filter-area';
import DoctorsDetails from '../components/roster-manager/doctors-details'
const useStyles = makeStyles({
   table: {
      width: 1200,
   },
   root: {
      width: 1300,
      height: 800,
      margin: 50
   },
}); 

const RosterManagerHomePage = ({ currentUser }) => {
   const alert = useAlert();
   const classes = useStyles();
   const [cookies, getCookie] = useCookies(['name']);
   const [doctors, setDoctors] = useState([]);
   // const [showSignout, setShowSignout] = useState('hide');
   // const [feeFilter, setFeeFilter] = useState('any');
   // const [specialityFilter, setSpecialityFilter] = useState('any');
   // const [sort, setSort] = useState('recent');
   const [consultFeeUpdate,setConsultFeeUpdate] = useState('');
   const [doctorSelected, setDoctorSelected] = useState([{}]);
   // const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
   // const [selectedDay, setSelectedDay] = useState(new Date().getDay());
   // const [responseData, setResponseData] = useState([]);
   // const [slotSelectedDay, setSlotSelectedDay] = useState([]);
   const [loader, setLoader] = useState(false);
   // const [userDetails, setUserDetails] = useState({})
  
   const fetchData = () => {
      let cookie = ''
      for (const [key, value] of Object.entries(cookies)) {
         if(key === 'express:sess'){
            cookie = value;
         }
      }
      let headers = {
         'authtoken': cookie
      }
      setLoader(true);
      axios.get(config.API_URL + '/api/employee/doctors', {headers})
      .then(response => {
         console.log(response.data)
         if(response.data && response.data.length){
            setDoctors(response.data);
            // setConsltFee(response.data[0].consultationChargesInINR)
            setDoctorSelected(response.data[0]);
            // fetchTimeslot(response.data[0].id);
            setLoader(false);
         }
      })
      .catch(error => {
         alert.show(error.response.data.errors[0].message, { type: 'error' });
         console.log(error);
         setLoader(false);
         
      });
   }
   
   useEffect(() => {
      fetchData()
   }, [consultFeeUpdate]);

   const onDocterSelect = (e,doct,i) => {
      setDoctorSelected(doct);
      // fetchTimeslot(doct.id)
      // setConsltFee(doct.consultationChargesInINR)
      // e.preventDefault();
      // onDateChange(new Date());
   }

   return <>
     
      {loader && <div className="loader"><CircularProgress color="secondary" /><div className="text"></div></div>}
      <Head>
         <title>Unify Care: Roaster Manager</title>
         <link rel="icon" href="/favicon.png" />
         <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" />
         <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons" />
      </Head>
      <div className="left-area">
         <div className="unifyLogo">
            <img src="logo.svg" className="logo" />
            <img src="unify_care.svg" className="name" />
         </div>
         <div className="menu-items">
            {/* <div className="items" onClick={toListing}>
               <img src="employees.svg" className="logo" />
               <span>EMPLOYEE MANAGER</span>
            </div> */}
            <div className="items active">
               <img src="roaster.svg" className="logo" style={{padding:'5px'}}/>
               <span>ROASTER MANAGER</span>
            </div>
            {/* <div className="items" onClick={toSupportCenter}>
               <img src="support.svg" className="logo" style={{padding:'5px'}}/>
               <span>APPOINTMENT MANAGER</span>
            </div> */}
         </div>
      </div>
      <div className="right-area rosterManager">
      <Header name ='Roaster Manager'/>
      <FilterArea />
         {doctors.length>0 ? 
         <div className="mainView">
            <div className='doctorList'>
            {doctors.map((doct,i) => (
               <Card className={'doctorcard'+ (doct.id=== doctorSelected.id? ' active':'') } key={doct.id}>
                  <CardActionArea onClick={(e)=>onDocterSelect(e,doct,i)} style={{height:'100%'}}>
                     <CardContent>
                     <div className='docImage'>
                     <img src={"https://www.unify.care/api/file-manager/download/" +doct.displayProfileImageName}/>
                     </div>
                     <div className='docDetails'>
                        <span style={{fontWeight:'bold'}}>{doct.userFirstName+ ' ' + doct.userLastName}</span>
                        <span>{doct.displayQualification && doct.displayQualification != 'NA' ?doct.displayQualification : ''} </span>
                        <span>Experience: {doct.experinceInYears > 1 ? doct.experinceInYears + ' Years' : doct.experinceInYears + ' Year'}
                           
                        </span>
                        <span style={{display:'inline-flex'}}>
                           Fee: &nbsp;
                           <span className='cnstFee'>
                              {'₹' + doct.consultationChargesInINR }
                           </span>
                        </span>
                     </div>
                     </CardContent>
                  </CardActionArea>
               </Card>
               ))}
            </div>

            <DoctorsDetails doctorSelected={doctorSelected} consultFeeUpdate={setConsultFeeUpdate}/>
         </div>
         : 
         <div style={{textAlign:'center', marginTop:'10%'}}>
            <h3>No Doctor added yet.</h3>
         </div>
         }

      </div>
   </>
};

// RosterManagerHomePage.getInitialProps = async (ctx, context, client, currentUser) => {

//    console.log('=========================================')
//    console.log(ctx.req.headers.cookie)
   
//    // let cookie = ''
//    // for (const [key, value] of Object.entries(cookies)) {
//    //    if(key === 'express:sess'){
//    //       cookie = value
//    //    }
//    // }
//    // let headers = {
//    //    'authtoken': cookie
//    // }

//    const { data } = await axios.get(config.API_URL + '/api/employee/doctors');
   
//    return { doctors: data };
// };

export default RosterManagerHomePage;
