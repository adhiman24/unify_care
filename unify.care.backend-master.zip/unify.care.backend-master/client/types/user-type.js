const UserType = {
  Superadmin: 'superadmin',
  PartnerSuperuser: 'facility:superuser',
  PartnerManager: 'facility:manager',
  PartnerEmployeeAdmin: 'employee:admin',
  Doctor: 'doctor',
  Nutritionist: 'nutritionist',
  Educator: 'educator',
  CustomerSupport: 'customer:support',
  PartnerRosterManager: 'roster:manager',
  Patient: 'patient',
}

export default UserType;