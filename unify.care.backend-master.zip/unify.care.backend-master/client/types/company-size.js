const CompanySize = {
    Size0To10: 'size-0-10',
    Size10To100: 'size-10-100',
    Size100To200: 'size-100-200',
    Size200To500: 'size-200-500',
    Size500Plus: 'size-500-plus',
}

export default CompanySize;