import { Subjects } from './subjects';
import { ChatGroupActionType } from '../types/chat-group-action-type'

export interface UpdateAppointmentChatGroupEvent {
  subject: Subjects.UpdateAppointmentChatGroup;
  data: {
    appointmentId: string;
    patientId: string;
    consultantId: string;
    appointmentDate: string;
    appointmentSlotId: number;
    remarks: string;
    chatGroupAction: ChatGroupActionType;
    updateChatGroupAtTime: Date;
  };
}