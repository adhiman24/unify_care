import { Subjects } from './subjects';
import { GenderType } from '../types/gender-type'

export interface PatientCreatedEvent {
  subject: Subjects.PatientCreated;
  data: {
    id: string;
    userFirstName: string;
    userLastName: string;
    emailId: string;
    phoneNumber: string;
    partnerId: string;
    dateOfBirth: string,
    gender: GenderType,
  };
}
