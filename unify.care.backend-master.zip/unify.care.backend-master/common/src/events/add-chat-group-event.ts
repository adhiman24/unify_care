import { Subjects } from './subjects';

export interface AddChatGroupEvent {
  subject: Subjects.AddChatGroup;
  data: {
    patientId: string,
    consultantId: string;
    appointmentId: string;
    appointmentDate: string;
    appointmentSlotId: number;
    remarks: string;
  };
}
