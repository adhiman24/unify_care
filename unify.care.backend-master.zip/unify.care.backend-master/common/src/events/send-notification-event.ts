import { Subjects } from './subjects';
import { NotificationType } from '../types/notification-type'

export interface SendNotificationEvent {
  subject: Subjects.SendNotification;
  data: {
    userId: string;
    title: string;
    body: string;
    type: NotificationType;
  };
}
