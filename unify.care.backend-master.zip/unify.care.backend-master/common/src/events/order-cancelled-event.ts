import { Subjects } from './subjects';
import { OrderStatus } from '../types/order-status';

export interface OrderCancelledEvent {
  subject: Subjects.OrderCancelled;
  data: {
    orderId: string;
    patientId: string;
    status: OrderStatus;
    version: number;
  };
}