import { OrderStatus } from '../types/order-status';
import { Subjects } from './subjects';

export interface OrderCreatedEvent {
  subject: Subjects.OrderCreated;
  data: {
    orderId: string;
    price: number;
    patientId: string;
    status: OrderStatus;
    numberOfRetry: number;
    version: number;
  };
}
