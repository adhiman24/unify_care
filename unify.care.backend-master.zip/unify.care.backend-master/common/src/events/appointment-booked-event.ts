import { Subjects } from './subjects';
import { ConsultationType } from '../types/consultation-type'
import { AppointmentStatus } from '../types/appointment-status'

export interface AppointmentBookedEvent {
  subject: Subjects.AppointmentBooked;
  data: {
    appointmentId: string;
    consultantId: string;
    customerId: string;
    creatorId: string;
    partnerId: string;
    parentId: string;
    createdBy: string;
    basePriceInINR: number;
    consultationType: ConsultationType;
    appointmentDate: string;
    appointmentSlotId: number;
    appointmentStatus: AppointmentStatus;
    appointmentCreationTime: Date;
  };
}