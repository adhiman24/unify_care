import { CustomError } from './custom-error';

export class SecurityError extends CustomError {
  statusCode = 412;

  constructor(public message: string) {
    super(message);

    Object.setPrototypeOf(this, SecurityError.prototype);
  }

  serializeErrors() {
    return [{ message: this.message }];
  }
}
