import { CustomError } from './custom-error';

export class NotVerifiedError extends CustomError {
  statusCode = 401;

  constructor() {
    super('Not Verified');

    Object.setPrototypeOf(this, NotVerifiedError.prototype);
  }

  serializeErrors() {
    return [{ message: 'User Not Verified' }];
  }
}
