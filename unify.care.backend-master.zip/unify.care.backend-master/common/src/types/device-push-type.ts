export enum DevicePushType {
  GCM = 'gcm',
  APM = 'apn',
  WEB = 'web',
  ADM = 'adm',
  WNS = 'wns'
}
