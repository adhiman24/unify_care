export enum PaymentType {
    Online = 'online',
    DiscountCoupon = 'discount:coupon',
    Unknown = 'unknown'
}