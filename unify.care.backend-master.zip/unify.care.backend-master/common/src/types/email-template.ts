export enum EmailTemplate {
  WelcomeEmail = 'welcome',
  VerifyEmail = 'verify-email',
  ForgotPassword = 'forgot-password',
  PasswordReset = 'password-reset',
  CustomerEmailInvite = 'customer-email-invite',
  NoTemplate = 'no-template',
}
