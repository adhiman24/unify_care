export enum ChatGroupActionType {
  ADDCHATGROUP = 'add:chat:group',
  REMOVECHATGROUP = 'remove:chat:group',
}
