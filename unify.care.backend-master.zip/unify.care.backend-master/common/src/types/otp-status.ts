export enum OTPStatus {
  Valid = 'valid',
  Expired = 'expired',
  Used = 'used'
}
