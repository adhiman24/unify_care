export enum SMSTemplate {
  NoTemplate = 'no:template',
}
