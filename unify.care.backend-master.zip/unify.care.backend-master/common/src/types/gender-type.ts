export enum GenderType {
  Male = 'male',
  Female = 'female',
  Other = 'other'
}
