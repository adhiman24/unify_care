export enum SlotAvailability {
    Available = 'available',
    Unavailable = 'unavailable',
    Blocked = 'blocked',
    Booked = 'booked'
}
