export enum EmailDeliveryType {
  Immediate = 'immediate',
  BestEffort = 'best:effort',
  DuringOverNightBatchJob = 'during:overnight:batch:job',
  AtExactTime = 'at:exact:time'
}
