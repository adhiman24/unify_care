export enum SMSType {
  OTP = 'otp',
  Transactional = 'transactional',
}