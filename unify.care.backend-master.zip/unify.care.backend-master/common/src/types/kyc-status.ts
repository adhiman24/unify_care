export enum KYCStatus {
  Unverified = 'unverified',
  Verified = 'verified',
}
