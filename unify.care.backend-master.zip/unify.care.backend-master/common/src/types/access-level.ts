export enum AccessLevel {
  SuperAdmin = 99,
  PartnerSuperuser = 49,
  PartnerManager = 39,
  EmployeeAdmin = 29,
  Employee = 19,
  Patient = 9,
}
