export enum UserStatus {
  Unverified = 'unverified',
  Verified = 'verified',
  Active = 'active',
  Inactive = 'inactive',
  Suspended = 'suspended',
}
