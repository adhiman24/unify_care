export enum EmailType {
  PlanText = 'text/plain',
  HtmlText = 'text/html',
}
