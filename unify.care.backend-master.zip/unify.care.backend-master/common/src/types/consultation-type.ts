export enum ConsultationType {
    PaidPatientDoctor = 'paid:patient:doctor',
    PaidPatientNutritionist = 'paid:patient:nutritionist',
    FollowupPatientNutritionist = 'followup:patient:nutritionist',
    FollowupPatientEducator = 'followup:patient:educator',
}