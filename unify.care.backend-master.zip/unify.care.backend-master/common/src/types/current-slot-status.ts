export enum CurrentSlotStatus {
    Unallocated = 0,
    Allocated = 1,
}
