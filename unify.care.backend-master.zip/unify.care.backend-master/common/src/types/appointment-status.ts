export enum AppointmentStatus {
  Booked = 'booked',
  Created = 'created',
  Blocked = 'blocked',
  Expired = 'expired',
  Cancelled = 'cancelled',
  Rescheduled = 'rescheduled',
  PaymentFailed = 'paymentfailed',
  SuccessfullyCompleted = 'successfully:completed',
  CompletedWithError = 'completed:with:error',
}
