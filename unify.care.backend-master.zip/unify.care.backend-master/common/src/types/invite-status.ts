export enum InviteStatus {
  Created = 'created',
  Rejected = 'rejected',
  Accepted = 'accepted',
  Expired = 'expired',
  AwaitingResponse = 'awaiting-response'
}
