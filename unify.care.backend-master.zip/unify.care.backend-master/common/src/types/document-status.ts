export enum DocumentStatus {
  Unverified = 'unverified',
  Verified = 'verified',
}
