export enum PrescriptionType {
  FirstPrescription = 'first:prescription',
  FollowupPrescription = 'followup:prescription',
}
