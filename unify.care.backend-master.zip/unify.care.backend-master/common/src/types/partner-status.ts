export enum PartnerStatus {
  Unverified = 'unverified',
  Verified = 'verified',
  Active = 'active',
  Suspended = 'suspended',
  Inactive = 'inactive'
}
