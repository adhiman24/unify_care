export enum FileType {
  Image = 'images',
  PDF = 'pdf',
  ANY = 'any'
}
