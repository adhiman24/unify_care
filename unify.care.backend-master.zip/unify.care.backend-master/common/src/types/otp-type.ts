export enum OTPType {
  Email = 'email',
  Phone = 'phone',
}
