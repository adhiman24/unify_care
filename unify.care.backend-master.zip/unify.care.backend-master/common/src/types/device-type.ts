export enum DeviceType {
  Android = 'android',
  IOS = 'ios',
  Chrome = 'chrome',
  Other = 'other'
}
