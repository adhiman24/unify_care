export enum NotificationType {
    Unicast = 'unicast',
    Multicast = 'multicast',
    Broadcast = 'broadcast',
}