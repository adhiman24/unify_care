import mongoose from 'mongoose';
import { PrescriptionType } from '@unifycare/aem';
import { updateIfCurrentPlugin } from 'mongoose-update-if-current';


interface PrescriptionAttrs {
  id: string;
  appointmentId: string;
  prescriptionType: PrescriptionType;
  patientId: string;
  consultantId: string;
  previousPrescriptionId: string;
  nextPrescriptionId: string;
  prescriptionDate: string;
  followupConsultationDate: string;
  diagnosticTestList: [string];
  medicinePrescriptionList: [string];
  consultantRemarksList: [string];
}

interface PrescriptionDoc extends mongoose.Document {
  appointmentId: string;
  prescriptionType: PrescriptionType;
  patientId: string;
  consultantId: string;
  previousPrescriptionId: string;
  nextPrescriptionId: string;
  prescriptionDate: string;
  followupConsultationDate: string;
  diagnosticTestList: [string];
  medicinePrescriptionList: [string];
  consultantRemarksList: [string];
  version: number;
}


interface PrescriptionModel extends mongoose.Model<PrescriptionDoc> {
  build(attrs: PrescriptionAttrs): PrescriptionDoc;
  findByEvent(event: {
    id: string;
    version: number;
  }): Promise<PrescriptionDoc | null>;
}

const prescriptionSchema = new mongoose.Schema(
  {
    appointmentId: {
      type: String,
      required: true,
    },
    patientId: {
      type: String,
      required: true,
    },
    consultantId: {
      type: String,
      required: true,
    },
    prescriptionType: {
      type: PrescriptionType,
      required: true,
    },
    previousPrescriptionId: {
      type: String,
      required: true,
    },
    nextPrescriptionId: {
      type: String,
      required: true,
    },
    prescriptionDate: {
      type: String,
      required: true,
    },
    followupConsultationDate: {
      type: String,
      required: true,
    },
    diagnosticTestList: {
      type: [String],
      required: true,
    },
    medicinePrescriptionList: {
      type: [String],
      required: true,
    },
    consultantRemarksList: {
      type: [String],
      required: true,
    },
  },
  {
    toJSON: {
      transform(doc, ret) {
        ret.id = ret._id;
        delete ret._id;
      },
    },
  }
);
prescriptionSchema.set('versionKey', 'version');
prescriptionSchema.plugin(updateIfCurrentPlugin);

prescriptionSchema.static('findByEvent', (event: { id: string, version: number }) => {
  return Prescription.findOne({
    _id: event.id,
    version: event.version - 1,
  });
});
prescriptionSchema.static('build', (attrs: PrescriptionAttrs) => {
  return new Prescription({
    _id: attrs.id,
    appointmentId: attrs.appointmentId,
    patientId: attrs.patientId,
    consultantId: attrs.consultantId,
    prescriptionType: attrs.prescriptionType,
    previousPrescriptionId: attrs.previousPrescriptionId,
    nextPrescriptionId: attrs.nextPrescriptionId,
    prescriptionDate: attrs.prescriptionDate,
    followupConsultationDate: attrs.followupConsultationDate,
    diagnosticTestList: attrs.diagnosticTestList,
    medicinePrescriptionList: attrs.medicinePrescriptionList,
    consultantRemarksList: attrs.consultantRemarksList,
  });
});

const Prescription = mongoose.model<PrescriptionDoc, PrescriptionModel>('Prescription', prescriptionSchema);

export { Prescription };
