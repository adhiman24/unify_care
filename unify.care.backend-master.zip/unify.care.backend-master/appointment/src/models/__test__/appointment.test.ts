import { Appointment } from '../appointment';
import mongoose from 'mongoose';
import { ConsultationType, AppointmentStatus } from '@unifycare/aem';
const TOTAL_NUMBER_OF_MIN_IN_A_DAY = 1440;
const SLICE_DURATION_IN_MIN = 30;

const totalNumberOfSlots = TOTAL_NUMBER_OF_MIN_IN_A_DAY / SLICE_DURATION_IN_MIN;

it('implements optimistic concurrency control', async (done) => {
  // Create an instance of a profile
  const id = new mongoose.Types.ObjectId().toHexString();

  const appointmentConfig = Appointment.build({
    id,
    consultantId: 'string',
    customerId: 'string',
    creatorId: 'string',
    appointmentSlotId: 3,
    parentId: id,
    createdBy: 'UserType.CustomerSupport',
    consultationType: ConsultationType.FollowupPatientEducator,
    appointmentDate: 'string',
    appointmentStatus: AppointmentStatus.Blocked,
    appointmentCreationTime: new Date(),
    partnerId: new mongoose.Types.ObjectId().toHexString(),
    appointmentStatusUpdateTime: new Date(),
    lastAppointmentStatus: AppointmentStatus.Blocked,
    expirationDate: new Date(),
    basePriceInINR: 500
  });

  // Save the profile to the database
  await appointmentConfig.save();

  // fetch the profile twice
  const firstInstance = await Appointment.findById(appointmentConfig.id);
  const secondInstance = await Appointment.findById(appointmentConfig.id);

  // make two separate changes to the profiles we fetched
  firstInstance!.set({ appointmentSlotId: '30' });
  secondInstance!.set({ appointmentSlotId: '15' });

  // save the first fetched profile
  await firstInstance!.save();

  // save the second fetched profile and expect an error
  try {
    await secondInstance!.save();
  } catch (err) {
    return done();
  }

  throw new Error('Should not reach this point');
});

it('increments the version number on multiple saves', async () => {
  const id = new mongoose.Types.ObjectId().toHexString();
  const appointmentConfig = Appointment.build({
    id,
    consultantId: 'string',
    customerId: 'string',
    creatorId: 'string',
    appointmentSlotId: 3,
    parentId: id,
    createdBy: 'UserType.CustomerSupport',
    consultationType: ConsultationType.FollowupPatientEducator,
    appointmentDate: 'string',
    appointmentStatus: AppointmentStatus.Blocked,
    appointmentCreationTime: new Date(),
    partnerId: new mongoose.Types.ObjectId().toHexString(),
    appointmentStatusUpdateTime: new Date(),
    lastAppointmentStatus: AppointmentStatus.Blocked,
    expirationDate: new Date(),
    basePriceInINR: 500
  });
  await appointmentConfig.save();
  expect(appointmentConfig.version).toEqual(0);
  await appointmentConfig.save();
  expect(appointmentConfig.version).toEqual(1);
  await appointmentConfig.save();
  expect(appointmentConfig.version).toEqual(2);
});

