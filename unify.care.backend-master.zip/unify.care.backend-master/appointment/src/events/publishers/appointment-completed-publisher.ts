import { Publisher, Subjects, AppointmentCompletedEvent } from '@unifycare/aem';

export class AppointmentCompletedPublisher extends Publisher<AppointmentCompletedEvent> {
  subject: Subjects.AppointmentCompleted = Subjects.AppointmentCompleted;
}
