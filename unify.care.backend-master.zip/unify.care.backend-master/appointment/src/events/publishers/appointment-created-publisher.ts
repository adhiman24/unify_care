import { Publisher, Subjects, AppointmentCreatedEvent } from '@unifycare/aem';

export class AppointmentCreatedPublisher extends Publisher<AppointmentCreatedEvent> {
  subject: Subjects.AppointmentCreated = Subjects.AppointmentCreated;
}
