import { Publisher, Subjects, AppointmentCancelEvent } from '@unifycare/aem';

export class AppointmentCancelPublisher extends Publisher<AppointmentCancelEvent> {
  subject: Subjects.AppointmentCancelled = Subjects.AppointmentCancelled;
}
