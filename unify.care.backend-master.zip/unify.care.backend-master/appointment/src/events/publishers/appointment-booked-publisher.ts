import { Publisher, Subjects, AppointmentBookedEvent } from '@unifycare/aem';

export class AppointmentBookedPublisher extends Publisher<AppointmentBookedEvent> {
  subject: Subjects.AppointmentBooked = Subjects.AppointmentBooked;
}
