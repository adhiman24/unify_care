import { Publisher, Subjects, PrescriptionCreatedEvent } from '@unifycare/aem';

export class PrescriptionCreatedPublisher extends Publisher<PrescriptionCreatedEvent> {
  subject: Subjects.PrescriptionCreated = Subjects.PrescriptionCreated;
}
