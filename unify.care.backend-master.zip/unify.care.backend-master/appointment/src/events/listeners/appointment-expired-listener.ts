import { Listener, AppointmentExpiredEvent, Subjects, AppointmentStatus, SlotAvailability, OrderStatus } from '@unifycare/aem';
import { Message } from 'node-nats-streaming';
import { Appointment } from '../../models/appointment';
import { AppointmentConfig } from '../../models/appointment-config';
import { AppointmentExpiredGroupName } from './queue-group-name';

export class AppointmentExpiredListener extends Listener<AppointmentExpiredEvent> {
  subject: Subjects.AppointmentExpired = Subjects.AppointmentExpired;
  queueGroupName = AppointmentExpiredGroupName;

  async onMessage(data: AppointmentExpiredEvent['data'], msg: Message) {
    console.log('AppointmentExpiredEvent for id: ', data.productId);

    const appointment = await Appointment.findById(data.productId);
    if (!appointment) {
      console.log('Apppointment Not Found for Id: ', data.productId);
      msg.ack();
      return;
    }
    if (appointment.appointmentStatus === AppointmentStatus.Blocked) {
      appointment.set({
        lastAppointmentStatus: appointment.appointmentStatus,
        appointmentStatus: AppointmentStatus.Expired,
        appointmentStatusUpdateTime: new Date(),
      });
      await appointment.save();

      const existingAppointmentConfig = await AppointmentConfig.findOne({
        consultantId: appointment.consultantId,
        appointmentDate: appointment.appointmentDate
      });

      if (!existingAppointmentConfig) {
        //This is not possible
        console.log('Apppointment Config Not Consultant for Id: ', appointment.consultantId);
        msg.ack();
        return;
      }
      if (existingAppointmentConfig.availableSlots[appointment.appointmentSlotId] === SlotAvailability.Blocked) {
        const newList = [...existingAppointmentConfig.availableSlots];
        newList[appointment.appointmentSlotId] = SlotAvailability.Available;
        existingAppointmentConfig.set({
          availableSlots: newList,
        });
        await existingAppointmentConfig.save();
      }
    }
    msg.ack();
  }
};
