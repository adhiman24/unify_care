export const AppointmentExpiredGroupName = 'appointment-expire-service';
export const PaymentCompletedGroupName = 'payment-completed-service';
export const databasBackupGroupName = 'appointment-database-backup-service';
export const databasUploadGroupName = 'appointment-database-upload-service';
export const updateTimeTableGroupName = 'appointment-update-time-table-service';
