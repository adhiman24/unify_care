import { Listener, PaymentCompletedEvent, Subjects, AppointmentStatus, SlotAvailability } from '@unifycare/aem';
import { Message } from 'node-nats-streaming';
import { PaymentCompletedGroupName } from './queue-group-name';
import { Appointment } from '../../models/appointment';
import { AppointmentConfig } from '../../models/appointment-config';
import { AppointmentBookedPublisher } from '../publishers/appointment-booked-publisher';
import { natsWrapper } from '../../nats-wrapper';

export class PaymentCompletedListener extends Listener<PaymentCompletedEvent> {
  subject: Subjects.PaymentCompleted = Subjects.PaymentCompleted;
  queueGroupName = PaymentCompletedGroupName;

  async onMessage(data: PaymentCompletedEvent['data'], msg: Message) {
    console.log('PaymentStatusEvent for id: ', data.productId);

    const appointment = await Appointment.findById(data.productId);
    if (!appointment) {
      console.log('Apppointment Not Found for Id: ', data.productId);
      msg.ack();
      return;
    }

    if (appointment.appointmentStatus === AppointmentStatus.Blocked) {
      appointment.set({
        lastAppointmentStatus: appointment.appointmentStatus,
        appointmentStatus: AppointmentStatus.Booked,
        appointmentStatusUpdateTime: new Date(),
      });
      await appointment.save();

      const existingAppointmentConfig = await AppointmentConfig.findOne({
        consultantId: appointment.consultantId,
        appointmentDate: appointment.appointmentDate
      });
      if (!existingAppointmentConfig) {
        console.log('Apppointment Config Not Consultant for Id: ', appointment.consultantId);
        msg.ack();
        return;
      }
      if (existingAppointmentConfig.availableSlots[appointment.appointmentSlotId] === SlotAvailability.Blocked) {
        const newList = [...existingAppointmentConfig.availableSlots];
        newList[appointment.appointmentSlotId] = SlotAvailability.Booked;
        existingAppointmentConfig.set({
          availableSlots: newList,
        });
        await existingAppointmentConfig.save();
      }
    }
    msg.ack();

    ///// Publish New Appointment Message //////////////
    new AppointmentBookedPublisher(natsWrapper.client).publish({
      appointmentId: appointment.id,
      consultantId: appointment.consultantId,
      customerId: appointment.customerId,
      creatorId: appointment.creatorId,
      partnerId: appointment.partnerId,
      parentId: appointment.parentId,
      createdBy: appointment.createdBy,
      basePriceInINR: appointment.basePriceInINR,
      consultationType: appointment.consultationType,
      appointmentDate: appointment.appointmentDate,
      appointmentSlotId: appointment.appointmentSlotId,
      appointmentStatus: appointment.appointmentStatus,
      appointmentCreationTime: appointment.appointmentCreationTime,
    });
  }
};
