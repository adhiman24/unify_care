import express from 'express';
import 'express-async-errors';
import swaggerUi from 'swagger-ui-express';
import { swaggerDocument } from './swagger'
import { json } from 'body-parser';
import cookieSession from 'cookie-session';
import { errorHandler, NotFoundError, currentUser } from '@unifycare/aem';
import { loggerMiddleware, winstonMiddleware } from '@unifycare/logger';
import { addAppointmentSlotRouter } from './routes/add-appointment-slot';
import { addAppointmentRouter } from './routes/add-appointment';
import { addFollowupPrescriptionRouter } from './routes/add-followup-prescription';
import { addNewPrescriptionRouter } from './routes/add-new-prescription';
import { cancelAppointmentRouter } from './routes/cancel-appointment';
import { completedAppointmentRouter } from './routes/complete-appointment';
import { removeAppointmentSlotRouter } from './routes/remove-appointment-slot';
import { rescheduleAppointmentRouter } from './routes/reschedule-appointment';
import { updateAppointmentSlotRouter } from './routes/update-appointment-slot';
import { viewAppointmentSlotRouter } from './routes/view-appointment-slot';
import { viewConsultantAppointmentsRouter } from './routes/view-consultant-appointments';
import { viewAllAppointmentsRouter } from './routes/view-customer-appointments';
import { addAppointmentTimeTableRouter } from './routes/add-appointment-time-table';
import { viewAppointmentTimeTableRouter } from './routes/view-appointment-time-table'
import { markDoctorLeaveRouter } from './routes/mark-doctors-leave'
import { cancelDoctorLeaveRouter } from './routes/cancel-doctors-leave'


var cors = require('cors')

const app = express();

app.use(cors({ credentials: true, origin: 'http://localhost:3000' }));

app.set('trust proxy', true);
app.use(json());
app.use(
  cookieSession({
    signed: false,
    secure: process.env.NODE_ENV !== 'test',
    //secure: false,

  })
);

app.use(currentUser);

app.use(loggerMiddleware);
app.use(winstonMiddleware);
app.use('/api/appointment/swagger', swaggerUi.serve, swaggerUi.setup(swaggerDocument));
app.use(addAppointmentSlotRouter);
app.use(removeAppointmentSlotRouter);
app.use(viewAppointmentSlotRouter);
app.use(addAppointmentRouter);
app.use(cancelAppointmentRouter);
app.use(completedAppointmentRouter);
app.use(rescheduleAppointmentRouter);
app.use(viewAllAppointmentsRouter);
app.use(updateAppointmentSlotRouter);
app.use(addFollowupPrescriptionRouter);
app.use(addNewPrescriptionRouter);
app.use(addAppointmentTimeTableRouter);
app.use(viewAppointmentTimeTableRouter);
app.use(viewConsultantAppointmentsRouter);
app.use(markDoctorLeaveRouter);
app.use(cancelDoctorLeaveRouter);

app.all('*', async (req, res) => {
  throw new NotFoundError();
});

app.use(errorHandler);
export { app };
