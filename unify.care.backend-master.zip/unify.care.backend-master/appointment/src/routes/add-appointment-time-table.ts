import express, { Request, Response } from 'express';
import { body } from 'express-validator';
import { validateRequest, BadRequestError, requireRosterManagerAuth, SlotAvailability } from '@unifycare/aem';
import { AppointmentTimeTable } from '../models/appointment-time-table';
import moment from 'moment';
import mongoose from 'mongoose';
import { AppointmentConfig } from '../models/appointment-config';

const router = express.Router();

const TOTAL_NUMBER_OF_MIN_IN_A_DAY = 1440;
const SLICE_DURATION_IN_MIN = 30;
const BASE_PRICE_IN_INR = 500;
const FUTURE_APPOINTMENT_ALLOWED_IN_DAYS = 31;
const MONDAY = 1;
const TUESDAY = 2;
const WEDNESDAY = 3;
const THURSDAY = 4;
const FRIDAY = 5;
const SATURDAY = 6;
const SUNDAY = 7;

const totalNumberOfSlots = (TOTAL_NUMBER_OF_MIN_IN_A_DAY / SLICE_DURATION_IN_MIN);

router.post(
  '/api/appointment/slotstimetable',
  requireRosterManagerAuth,
  [
    body('consultantId')
      .not()
      .isEmpty()
      .custom((input: string) => mongoose.Types.ObjectId.isValid(input))
      .withMessage('Consultant Id must be provided'),
  ],
  validateRequest,
  async (req: Request, res: Response) => {
    const {
      consultantId,
      mondayAvailableSlotList,
      tuesdayAvailableSlotList,
      wednesdayAvailableSlotList,
      thursdayAvailableSlotList,
      fridayAvailableSlotList,
      saturdayAvailableSlotList,
      sundayAvailableSlotList,
    } = req.body;

    let existingAppointmentTimeTable = await AppointmentTimeTable.findOne({ consultantId: consultantId });
    if (existingAppointmentTimeTable) {
      existingAppointmentTimeTable.set({
        mondayAvailableSlotList: mondayAvailableSlotList,
        tuesdayAvailableSlotList: tuesdayAvailableSlotList,
        wednesdayAvailableSlotList: wednesdayAvailableSlotList,
        thursdayAvailableSlotList: thursdayAvailableSlotList,
        fridayAvailableSlotList: fridayAvailableSlotList,
        saturdayAvailableSlotList: saturdayAvailableSlotList,
        sundayAvailableSlotList: sundayAvailableSlotList,
      });
    } else {
      existingAppointmentTimeTable = AppointmentTimeTable.build({
        id: new mongoose.Types.ObjectId().toHexString(),
        consultantId: consultantId,
        partnerId: req.currentUser!.fid,
        lastUpdatedBy: req.currentUser!.id,
        mondayAvailableSlotList: mondayAvailableSlotList,
        tuesdayAvailableSlotList: tuesdayAvailableSlotList,
        wednesdayAvailableSlotList: wednesdayAvailableSlotList,
        thursdayAvailableSlotList: thursdayAvailableSlotList,
        fridayAvailableSlotList: fridayAvailableSlotList,
        saturdayAvailableSlotList: saturdayAvailableSlotList,
        sundayAvailableSlotList: sundayAvailableSlotList,
        sliceDurationInMin: SLICE_DURATION_IN_MIN
      });
    }
    await existingAppointmentTimeTable.save();

    const dayOfWeek = moment().utcOffset(330).day();
    //Effective today time table will be applied for next FUTURE_APPOINTMENT_ALLOWED_IN_DAYS 
    const numberOfDays = FUTURE_APPOINTMENT_ALLOWED_IN_DAYS + (SUNDAY - dayOfWeek);
    //loop will start from dayOfWeek
    for (let i = dayOfWeek; i <= numberOfDays; i++) {
      let availableSlots: [SlotAvailability] = [SlotAvailability.Unavailable];
      for (let j = 1; j < totalNumberOfSlots; j++) {
        availableSlots.push(SlotAvailability.Unavailable);
      }
      const appointmentDate = moment().utcOffset(330).add((i - dayOfWeek), 'days').format('YYYY-MM-DD');
      let day = i <= SUNDAY ? i : Math.trunc(i / SUNDAY);
      switch (day) {
        case MONDAY: {
          for (let k = 0; k < existingAppointmentTimeTable.mondayAvailableSlotList.length; k++) {
            availableSlots[(Number(existingAppointmentTimeTable.mondayAvailableSlotList[k]))] = SlotAvailability.Available;
          }
          break;
        }
        case TUESDAY: {
          for (let k = 0; k < existingAppointmentTimeTable.tuesdayAvailableSlotList.length; k++) {
            availableSlots[(Number(existingAppointmentTimeTable.tuesdayAvailableSlotList[k]))] = SlotAvailability.Available;
          }
          break;
        }
        case WEDNESDAY: {
          for (let k = 0; k < existingAppointmentTimeTable.wednesdayAvailableSlotList.length; k++) {
            availableSlots[(Number(existingAppointmentTimeTable.wednesdayAvailableSlotList[k]))] = SlotAvailability.Available;
          }
          break;
        }
        case THURSDAY: {
          for (let k = 0; k < existingAppointmentTimeTable.thursdayAvailableSlotList.length; k++) {
            availableSlots[(Number(existingAppointmentTimeTable.thursdayAvailableSlotList[k]))] = SlotAvailability.Available;
          }
          break;
        }
        case FRIDAY: {
          for (let k = 0; k < existingAppointmentTimeTable.fridayAvailableSlotList.length; k++) {
            availableSlots[(Number(existingAppointmentTimeTable.fridayAvailableSlotList[k]))] = SlotAvailability.Available;
          }
          break;
        }
        case SATURDAY: {
          for (let k = 0; k < existingAppointmentTimeTable.saturdayAvailableSlotList.length; k++) {
            availableSlots[(Number(existingAppointmentTimeTable.saturdayAvailableSlotList[k]))] = SlotAvailability.Available;
          }
          break;
        }
        case SUNDAY: {
          for (let k = 0; k < existingAppointmentTimeTable.sundayAvailableSlotList.length; k++) {
            availableSlots[(Number(existingAppointmentTimeTable.sundayAvailableSlotList[k]))] = SlotAvailability.Available;
          }
          break;
        }
      }
      //Check if appointment Config Exist for this day
      let existingAppointmentConfig = await AppointmentConfig.findOne({
        consultantId: consultantId,
        appointmentDate: appointmentDate
      });
      if (existingAppointmentConfig) {
        if (!existingAppointmentConfig.notPartOfTimeTable) {
          existingAppointmentConfig.set({
            availableSlots: availableSlots,
          });
          await existingAppointmentConfig.save();
        }
      } else {
        existingAppointmentConfig = AppointmentConfig.build({
          id: new mongoose.Types.ObjectId().toHexString(),
          consultantId: consultantId,
          lastUpdatedBy: req.currentUser!.id,
          appointmentDate: appointmentDate,
          availableSlots: availableSlots,
          sliceDurationInMin: SLICE_DURATION_IN_MIN,
          partnerId: req.currentUser!.fid,
          basePriceInINR: BASE_PRICE_IN_INR,
          notPartOfTimeTable: false,
          isDoctorOnLeave: false
        });
        await existingAppointmentConfig.save();
      }
    }
    res.status(200).send("Time Table Updated Successfully");
  }
);

export { router as addAppointmentTimeTableRouter };
