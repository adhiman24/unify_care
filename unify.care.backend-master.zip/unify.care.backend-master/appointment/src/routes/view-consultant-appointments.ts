import express, { Request, Response } from 'express';
import { requireDoctorAuth } from '@unifycare/aem';
import { Appointment } from '../models/appointment'

const router = express.Router();

router.get(
  '/api/appointment/view',
  requireDoctorAuth,
  async (req: Request, res: Response) => {
    const appointments = await Appointment.find({ consultantId: req.currentUser!.id });

    res.send(appointments);
  });

export { router as viewConsultantAppointmentsRouter };
