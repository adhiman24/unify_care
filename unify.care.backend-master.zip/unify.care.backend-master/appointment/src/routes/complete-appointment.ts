import express, { Request, Response } from 'express';
import { body } from 'express-validator';
import { validateRequest, AppointmentStatus, requireDoctorAuth, NotFoundError } from '@unifycare/aem';
import { Appointment } from '../models/appointment';
import mongoose from 'mongoose';
import { natsWrapper } from '../nats-wrapper'
import { AppointmentCompletedPublisher } from '../events/publishers/appointment-completed-publisher'
const router = express.Router();

router.post(
  '/api/appointment/completed',
  requireDoctorAuth,
  [
    body('appointmentId')
      .not()
      .isEmpty()
      .custom((input: string) => mongoose.Types.ObjectId.isValid(input))
      .withMessage('Appointment Id must be provided'),
  ],
  validateRequest,
  async (req: Request, res: Response) => {
    const { appointmentId, followupConsultationDate, remarks, successfullyCompleted } = req.body;

    const appointment = await Appointment.findById(appointmentId);
    if (!appointment) {
      console.log('Apppointment Not Found for Id: ', appointmentId);
      throw new NotFoundError();
    }

    let appointmentStatus = AppointmentStatus.SuccessfullyCompleted;

    if (!successfullyCompleted) {
      appointmentStatus = AppointmentStatus.CompletedWithError;
    }

    appointment.set({
      lastAppointmentStatus: appointment.appointmentStatus,
      appointmentStatus: appointmentStatus,
      appointmentStatusUpdateTime: new Date(),
    });
    await appointment.save();

    ///// Publish New Appointment Message //////////////
    new AppointmentCompletedPublisher(natsWrapper.client).publish({
      appointmentId: appointment.id,
      successfullyCompleted: successfullyCompleted,
      remarks: remarks,
      followupConsultationDate: followupConsultationDate,
    });

    res.status(200).send(appointment);
  }
);

export { router as completedAppointmentRouter };
