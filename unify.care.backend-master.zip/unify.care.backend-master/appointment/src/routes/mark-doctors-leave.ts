
import express, { Request, Response } from 'express';
import { body } from 'express-validator';
import { validateRequest, BadRequestError, requireAuth, SlotAvailability, AppointmentStatus } from '@unifycare/aem';
import { AppointmentConfig } from '../models/appointment-config';
import moment from 'moment';
import mongoose from 'mongoose';
import { Appointment } from '../models/appointment';


const router = express.Router();

const TOTAL_NUMBER_OF_MIN_IN_A_DAY = 1440;
const SLICE_DURATION_IN_MIN = 30;
const BASE_PRICE_IN_INR = 500

const totalNumberOfSlots = (TOTAL_NUMBER_OF_MIN_IN_A_DAY / SLICE_DURATION_IN_MIN);

router.post(
  '/api/appointment/markleave',
  requireAuth,
  [
    body('consultantId')
      .not()
      .isEmpty()
      .custom((input: string) => mongoose.Types.ObjectId.isValid(input))
      .withMessage('Consultant Id must be provided'),
  ],
  validateRequest,
  async (req: Request, res: Response) => {
    const { consultantId, leaveDate} = req.body;
    console.log('consultantId ' + consultantId);
    console.log('leaveDate' + leaveDate);
    if (!moment(leaveDate, 'YYYY-MM-DD', true).isValid()) {
      console.log('Date Format should be YYYY-MM-DD ' + leaveDate);
      throw new BadRequestError("Date Format should be YYYY-MM-DD");
    }

    //Make sure only future slots marked as leave. 
    if (!moment(leaveDate).isAfter(moment().utcOffset(330).format('YYYY-MM-DD'))) {
      console.log('Date Format should be YYYY-MM-DD ' + leaveDate);
      throw new BadRequestError("Cannot mark leave for present or past date");
    }

    const appointmentList = await Appointment.find({appointmentDate : leaveDate});
    if (appointmentList.length > 0){
      for (let i = 0; i < appointmentList.length; i++) {
        if (appointmentList[i].appointmentStatus === AppointmentStatus.Booked)  {
          console.log('Apppointment found for leave date: ' + leaveDate);
          throw new BadRequestError("First reschedule all existing appointments then you can mark leave.");
        }
      }
    }

    let existingAppointmentConfig = await AppointmentConfig.findOne({
      consultantId: consultantId,
      appointmentDate: leaveDate
    });

    if (!existingAppointmentConfig) {
      //create New one and never mark first slots available (Cron jobs in action) 
    let availableSlots: [SlotAvailability] = [SlotAvailability.Unavailable];
    for (let i = 1; i < totalNumberOfSlots; i++) {
      availableSlots.push(SlotAvailability.Unavailable);
    }

      const id = new mongoose.Types.ObjectId().toHexString();
      existingAppointmentConfig = AppointmentConfig.build({
        id,
        consultantId: consultantId,
        lastUpdatedBy: req.currentUser!.id,
        appointmentDate: leaveDate,
        availableSlots: availableSlots,
        sliceDurationInMin: SLICE_DURATION_IN_MIN,
        partnerId: req.currentUser!.fid,
        basePriceInINR: BASE_PRICE_IN_INR,
        notPartOfTimeTable: false,
        isDoctorOnLeave: true
      });
      await existingAppointmentConfig.save();
    } else {
     
      existingAppointmentConfig.set({
        isDoctorOnLeave: true
      });
      await existingAppointmentConfig.save();
    }
    res.status(200).send("Leave marked successfully");
  }
);

export { router as markDoctorLeaveRouter };
