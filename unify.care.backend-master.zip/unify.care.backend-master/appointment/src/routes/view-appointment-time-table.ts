import express, { Request, Response } from 'express';
import { requireRosterManagerAuth, NotFoundError } from '@unifycare/aem';
import { AppointmentTimeTable } from '../models/appointment-time-table';

const router = express.Router();

router.get(
  '/api/appointment/slotstimetable/:consultantId',
  requireRosterManagerAuth,
  async (req: Request, res: Response) => {

    let existingAppointmentTimeTable = await AppointmentTimeTable.findOne({
      consultantId: req.params.consultantId,
      partnerId: req.currentUser!.fid
    });
    if (!existingAppointmentTimeTable) {
      throw new NotFoundError();
    }

    res.status(200).send(existingAppointmentTimeTable);
  }
);

export { router as viewAppointmentTimeTableRouter };
