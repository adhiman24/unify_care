import express, { Request, Response } from 'express';
import { requirePatientAuth } from '@unifycare/aem';
import { Appointment } from '../models/appointment'

const router = express.Router();

router.get(
  '/api/appointment/view/:customerId',
  requirePatientAuth,
  async (req: Request, res: Response) => {
    const appointments = await Appointment.find({ customerId: req.params.customerId });

    res.send(appointments);
  });

export { router as viewAllAppointmentsRouter };
