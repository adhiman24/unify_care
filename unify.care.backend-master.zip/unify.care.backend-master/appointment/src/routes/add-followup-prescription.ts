import express, { Request, Response } from 'express';
import { body } from 'express-validator';
import { requireDoctorAuth, validateRequest, PrescriptionType, NotFoundError } from '@unifycare/aem';
import { Prescription } from '../models/prescription';
import mongoose from 'mongoose';

const router = express.Router();

router.post(
  '/api/appointment/followupprescription',
  requireDoctorAuth,
  [
    body('appointmentId')
      .not()
      .isEmpty()
      .custom((input: string) => mongoose.Types.ObjectId.isValid(input))
      .withMessage('Appointment Id must be provided'),
    body('patientId')
      .not()
      .isEmpty()
      .custom((input: string) => mongoose.Types.ObjectId.isValid(input))
      .withMessage('patient Id must be provided'),
    body('previousPrescriptionId')
      .not()
      .isEmpty()
      .custom((input: string) => mongoose.Types.ObjectId.isValid(input))
      .withMessage('Previous Prescription Id must be provided'),
  ],
  validateRequest,
  async (req: Request, res: Response) => {

    const {
      appointmentId,
      patientId,
      previousPrescriptionId,
      prescriptionDate,
      followupConsultationDate,
      diagnosticTestList,
      medicinePrescriptionList,
      consultantRemarksList,
    } = req.body;

    const previousPrescription = await Prescription.findById(previousPrescriptionId);

    if (!previousPrescription) {
      throw new NotFoundError();
    }

    const prescription = Prescription.build({
      id: new mongoose.Types.ObjectId().toHexString(),
      appointmentId: appointmentId,
      prescriptionType: PrescriptionType.FirstPrescription,
      patientId: patientId,
      consultantId: req.currentUser!.id,
      previousPrescriptionId: previousPrescriptionId,
      nextPrescriptionId: 'NA',
      prescriptionDate: prescriptionDate,
      followupConsultationDate: followupConsultationDate,
      diagnosticTestList: diagnosticTestList,
      medicinePrescriptionList: medicinePrescriptionList,
      consultantRemarksList: consultantRemarksList,
    });

    await prescription.save();

    previousPrescription.set({
      nextPrescriptionId: prescription.id,
    });

    await previousPrescription.save();

    res.status(201).send(prescription);
  }
);

export { router as addFollowupPrescriptionRouter };
