import express, { Request, Response } from 'express';
import { body } from 'express-validator';
import { validateRequest, BadRequestError, requireRosterManagerAuth, SlotAvailability } from '@unifycare/aem';
import { AppointmentConfig } from '../models/appointment-config';
import moment from 'moment';
import mongoose from 'mongoose';

const router = express.Router();

const TOTAL_NUMBER_OF_MIN_IN_A_DAY = 1440;
const SLICE_DURATION_IN_MIN = 30;
const BASE_PRICE_IN_INR = 500

const totalNumberOfSlots = (TOTAL_NUMBER_OF_MIN_IN_A_DAY / SLICE_DURATION_IN_MIN);

router.post(
  '/api/appointment/updateslots',
  requireRosterManagerAuth,
  [
    body('consultantId')
      .not()
      .isEmpty()
      .custom((input: string) => mongoose.Types.ObjectId.isValid(input))
      .withMessage('Consultant Id must be provided'),
  ],
  validateRequest,
  async (req: Request, res: Response) => {
    const { consultantId, appointmentDate, availableSlotList } = req.body;

    if (!moment(appointmentDate, 'YYYY-MM-DD', true).isValid()) {
      throw new BadRequestError("Date Format should be YYYY-MM-DD");
    }

    //Make sure only future slots marked as available. 
    if (!moment(appointmentDate).isSameOrAfter(moment().utcOffset(330).format('YYYY-MM-DD'))) {
      throw new BadRequestError("Cannot add slot for past date");
    }

    if (availableSlotList.length < totalNumberOfSlots) {
      throw new BadRequestError("Slot List is not Valid");
    }

    let validNextAvailableSlot = 0;

    //Make sure only future slots marked as available. 
    if (moment(appointmentDate).isSame(moment().utcOffset(330).format('YYYY-MM-DD'))) {
      validNextAvailableSlot = ((moment().utcOffset(330).toObject()).hours * 2 + ((moment().utcOffset(330).toObject()).minutes > 30 ? 2 : 1)) + 1;
    }

    //TODO Check if this date is part of Skip List [days like national holiday/other non working days]

    //TODO Check if consultant exists 


    //Make sure only Add operation is performed (No Update or Delete)
    let existingAppointmentConfig = await AppointmentConfig.findOne({
      consultantId: consultantId,
      appointmentDate: appointmentDate,
    });


    if (!existingAppointmentConfig) {
      //create New one and never mark first slots available (Cron jobs in action) 
      let availableSlots: [SlotAvailability] = [SlotAvailability.Unavailable];
      for (let i = 1; i < totalNumberOfSlots; i++) {
        availableSlots.push(SlotAvailability.Unavailable);
      }
      for (let i = 0; i < availableSlotList.length; i++) {
        if (i >= validNextAvailableSlot) {
          if (availableSlotList[i]) {
            availableSlots[i] = SlotAvailability.Available;
          } else {
            availableSlots[i] = SlotAvailability.Unavailable;
          }
        }
      }
      const id = new mongoose.Types.ObjectId().toHexString();
      existingAppointmentConfig = AppointmentConfig.build({
        id,
        consultantId: consultantId,
        lastUpdatedBy: req.currentUser!.id,
        appointmentDate: appointmentDate,
        availableSlots: availableSlots,
        sliceDurationInMin: SLICE_DURATION_IN_MIN,
        partnerId: req.currentUser!.fid,
        basePriceInINR: BASE_PRICE_IN_INR,
        notPartOfTimeTable: true,
        isDoctorOnLeave: false
      });
      await existingAppointmentConfig.save();
    } else {
      //Add Slots to existing One
      const newList = [...existingAppointmentConfig.availableSlots];
      for (let i = 0; i < availableSlotList.length; i++) {
        if (i >= validNextAvailableSlot) {
          if (availableSlotList[i]) {
            newList[i] = SlotAvailability.Available;
          } else {
            newList[i] = SlotAvailability.Unavailable;
          }
        }
      }
      existingAppointmentConfig.set({
        availableSlots: newList,
        notPartOfTimeTable: true
      });
      await existingAppointmentConfig.save();
    }

    console.log(existingAppointmentConfig.availableSlots);

    res.status(200).send("Slots Updated Successfully");
  }
);

export { router as updateAppointmentSlotRouter };
