import express, { Request, Response } from 'express';
import { body } from 'express-validator';
import { requireDoctorAuth, validateRequest, PrescriptionType } from '@unifycare/aem';
import { Prescription } from '../models/prescription';
import mongoose from 'mongoose';

const router = express.Router();

router.post(
  '/api/appointment/prescription',
  requireDoctorAuth,
  [
    body('appointmentId')
      .not()
      .isEmpty()
      .custom((input: string) => mongoose.Types.ObjectId.isValid(input))
      .withMessage('Appointment Id must be provided'),
    body('patientId')
      .not()
      .isEmpty()
      .custom((input: string) => mongoose.Types.ObjectId.isValid(input))
      .withMessage('patient Id must be provided'),
  ],
  validateRequest,
  async (req: Request, res: Response) => {

    const {
      appointmentId,
      patientId,
      prescriptionDate,
      followupConsultationDate,
      diagnosticTestList,
      medicinePrescriptionList,
      consultantRemarksList,
    } = req.body;

    const prescription = Prescription.build({
      id: new mongoose.Types.ObjectId().toHexString(),
      appointmentId: appointmentId,
      prescriptionType: PrescriptionType.FirstPrescription,
      patientId: patientId,
      consultantId: req.currentUser!.id,
      previousPrescriptionId: 'NA',
      nextPrescriptionId: 'NA',
      prescriptionDate: prescriptionDate,
      followupConsultationDate: followupConsultationDate,
      diagnosticTestList: diagnosticTestList,
      medicinePrescriptionList: medicinePrescriptionList,
      consultantRemarksList: consultantRemarksList,
    });

    await prescription.save();

    res.status(201).send(prescription);
  }
);

export { router as addNewPrescriptionRouter };
