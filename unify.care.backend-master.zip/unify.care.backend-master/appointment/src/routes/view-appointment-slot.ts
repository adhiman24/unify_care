import express, { Request, Response } from 'express';
import { body } from 'express-validator';
import { validateRequest, BadRequestError, requireAuth, SlotAvailability } from '@unifycare/aem';
import { AppointmentConfig } from '../models/appointment-config';
import moment from 'moment';
import mongoose from 'mongoose';

const router = express.Router();

const MAX_DAYS_TO_FETCH_APPOINTMENT_SLOTS = 31;
const TOTAL_NUMBER_OF_MIN_IN_A_DAY = 1440;
const SLICE_DURATION_IN_MIN = 30;

const totalNumberOfSlots = (TOTAL_NUMBER_OF_MIN_IN_A_DAY / SLICE_DURATION_IN_MIN);

router.post(
  '/api/appointment/viewslots',
  requireAuth,
  [
    body('consultantId')
      .not()
      .isEmpty()
      .custom((input: string) => mongoose.Types.ObjectId.isValid(input))
      .withMessage('Consultant Id must be provided'),
  ],
  validateRequest,
  async (req: Request, res: Response) => {
    const { consultantId, startDate, stopDate } = req.body;

    if (!moment(startDate, 'YYYY-MM-DD', true).isValid()) {
      throw new BadRequestError("startDate Format should be YYYY-MM-DD");
    }

    if (!moment(stopDate, 'YYYY-MM-DD', true).isValid()) {
      throw new BadRequestError("stopDate Format should be YYYY-MM-DD");
    }

    //Make sure view only future slots. 
    if (!moment(startDate).isSameOrAfter(moment().utcOffset(330).format('YYYY-MM-DD'))) {
      throw new BadRequestError("Cannot view slot of past date");
    }

    //Make sure view Stop date is after startDate only. 
    if (!moment(stopDate).isSameOrAfter(moment(startDate))) {
      throw new BadRequestError("stopDate must be same or after startDate");
    }

    const days = moment(stopDate).diff(moment(startDate), 'days') + 1;

    if (days > MAX_DAYS_TO_FETCH_APPOINTMENT_SLOTS) {
      throw new BadRequestError("Cannot fetch slots for more then 31 days");
    }

    const appointmentSlots = [];
    let date = null;
    //Make sure only future slots marked as available. 
    let validNextAvailableSlot = 0;
    for (let j = 0; j < days; j++) {
      date = moment(startDate).add(j, 'days');
      if (moment(date).isSame(moment().utcOffset(330).format('YYYY-MM-DD'))) {
        validNextAvailableSlot = ((moment().utcOffset(330).toObject()).hours * 2 + ((moment().utcOffset(330).toObject()).minutes > 30 ? 2 : 1)) + 1;
      } else {
        validNextAvailableSlot = 0;
      }
      const existingAppointmentConfig = await AppointmentConfig.findOne({
        consultantId: consultantId,
        appointmentDate: date.format('YYYY-MM-DD')
      });
      let slotList: [SlotAvailability] = [SlotAvailability.Unavailable];
      for (let i = 1; i < totalNumberOfSlots; i++) {
        slotList.push(SlotAvailability.Unavailable);
      }
      let isDoctorOnLeave = false;
      if (existingAppointmentConfig) {
        if (existingAppointmentConfig.isDoctorOnLeave) {
          isDoctorOnLeave = existingAppointmentConfig.isDoctorOnLeave;
        }
        for (let i = 0; i < existingAppointmentConfig.availableSlots.length; i++) {
          if (i >= validNextAvailableSlot) {
            slotList[i] = existingAppointmentConfig.availableSlots[i];
          }
        }
      }
      console.log(slotList);
      appointmentSlots.push({ appointmentDate: date.format('YYYY-MM-DD'), isDoctorOnLeave: isDoctorOnLeave, availableSlotsList: slotList });
    }

    res.status(200).send(appointmentSlots);
  }
);

export { router as viewAppointmentSlotRouter };
