import express, { Request, Response } from 'express';
import { body } from 'express-validator';
import { validateRequest, BadRequestError, requireCustomerSupportAuth, AppointmentStatus, SlotAvailability, NotFoundError } from '@unifycare/aem';
import { Appointment } from '../models/appointment';
import { AppointmentConfig } from '../models/appointment-config';
import moment from 'moment';
import mongoose from 'mongoose';

const router = express.Router();

const DEFAULT_EXPIRATION_WINDOW_SECONDS = 15 * 60;

router.post(
  '/api/appointment/reschedule',
  requireCustomerSupportAuth,
  [
    body('consultantId')
      .not()
      .isEmpty()
      .custom((input: string) => mongoose.Types.ObjectId.isValid(input))
      .withMessage('Consultant Id must be provided'),
    body('customerId')
      .not()
      .isEmpty()
      .custom((input: string) => mongoose.Types.ObjectId.isValid(input))
      .withMessage('Patient Id must be provided'),
    body('parentId')
      .not()
      .isEmpty()
      .custom((input: string) => mongoose.Types.ObjectId.isValid(input))
      .withMessage('Partner Id must be provided'),
    body('appointmentId')
      .not()
      .isEmpty()
      .custom((input: string) => mongoose.Types.ObjectId.isValid(input))
      .withMessage('Appointment Id must be provided'),
  ],
  validateRequest,
  async (req: Request, res: Response) => {
    const { appointmentId, consultantId, parentId, customerId, appointmentDate, consultationType, appointmentSlotId } = req.body;

    if (!moment(appointmentDate, 'YYYY-MM-DD', true).isValid()) {
      throw new BadRequestError("Date Format should be YYYY-MM-DD");
    }

    //Make sure only future appointments consider as valid. 
    if (!moment(appointmentDate).isSameOrAfter(moment().utcOffset(330).format('YYYY-MM-DD'))) {
      throw new BadRequestError("Cannot make appointment for past date");
    }

    if (moment(appointmentDate).isSame(moment().utcOffset(330).format('YYYY-MM-DD'))) {
      if (appointmentSlotId < ((moment().utcOffset(330).toObject()).hours * 2 + ((moment().utcOffset(330).toObject()).minutes > 30 ? 2 : 1)) + 1) {
        throw new BadRequestError("Cannot make appointment for past time");
      }
    }

    let existingAppointmentConfig = await AppointmentConfig.findOne({
      consultantId: consultantId,
      appointmentDate: appointmentDate
    });

    if (!existingAppointmentConfig) {
      throw new NotFoundError();
    }

    //check if requested new slot is available
    if (existingAppointmentConfig.availableSlots[appointmentSlotId] !== SlotAvailability.Available) {
      throw new BadRequestError("Sorry, Requested Appointment Slot Not Available");
    }
    const newList = [...existingAppointmentConfig.availableSlots];
    newList[appointmentSlotId] = SlotAvailability.Booked;
    existingAppointmentConfig.set({
      availableSlots: newList,
    });
    await existingAppointmentConfig.save();

    const expiration = new Date();

    expiration.setSeconds(expiration.getSeconds() + DEFAULT_EXPIRATION_WINDOW_SECONDS);

    const appointment = Appointment.build({
      id: new mongoose.Types.ObjectId().toHexString(),
      consultantId: consultantId,
      customerId: customerId,
      creatorId: req.currentUser!.id,
      appointmentSlotId: appointmentSlotId,
      createdBy: req.currentUser!.uty,
      consultationType: consultationType,
      appointmentDate: appointmentDate,
      basePriceInINR: existingAppointmentConfig.basePriceInINR,
      appointmentStatus: AppointmentStatus.Booked,
      appointmentCreationTime: new Date(),
      appointmentStatusUpdateTime: new Date(),
      partnerId: req.currentUser!.fid,
      parentId: parentId,
      lastAppointmentStatus: AppointmentStatus.Booked,
      expirationDate: expiration,
    });

    const oldAppointment = await Appointment.findById(appointmentId);
    if (!oldAppointment) {
      console.log('Apppointment Not Found for Id: ', appointmentId);
      throw new NotFoundError();
    }
    oldAppointment.set({
      lastAppointmentStatus: oldAppointment.appointmentStatus,
      appointmentStatus: AppointmentStatus.Rescheduled,
      appointmentStatusUpdateTime: new Date(),
    });
    await oldAppointment.save();

    existingAppointmentConfig = await AppointmentConfig.findOne({
      consultantId: oldAppointment.consultantId,
      appointmentDate: oldAppointment.appointmentDate
    });

    if (!existingAppointmentConfig) {
      //this should not happen
      throw new NotFoundError();
    }

    const oldList = [...existingAppointmentConfig.availableSlots];
    newList[oldAppointment.appointmentSlotId] = SlotAvailability.Available;

    existingAppointmentConfig.set({
      availableSlots: oldList,
    });
    await existingAppointmentConfig.save();

    // Save the profile to the database
    await appointment.save();
    res.status(201).send(appointment);
  }
);

export { router as rescheduleAppointmentRouter };
