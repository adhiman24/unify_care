import express, { Request, Response } from 'express';
import { body } from 'express-validator';
import { validateRequest, BadRequestError, requirePatientAuth, AppointmentStatus, SlotAvailability, NotFoundError } from '@unifycare/aem';
import { Appointment } from '../models/appointment';
import { AppointmentConfig } from '../models/appointment-config';
import moment from 'moment';
import mongoose from 'mongoose';
import { natsWrapper } from '../nats-wrapper';
import { AppointmentCreatedPublisher } from '../events/publishers/appointment-created-publisher';

const router = express.Router();

const DEFAULT_EXPIRATION_WINDOW_SECONDS = 15 * 60;

router.post(
  '/api/appointment/add',
  requirePatientAuth,
  [
    body('consultantId')
      .not()
      .isEmpty()
      .custom((input: string) => mongoose.Types.ObjectId.isValid(input))
      .withMessage('Consultant Id must be provided'),
    body('customerId')
      .not()
      .isEmpty()
      .custom((input: string) => mongoose.Types.ObjectId.isValid(input))
      .withMessage('Patient Id must be provided'),
    body('parentId')
      .not()
      .isEmpty()
      .custom((input: string) => mongoose.Types.ObjectId.isValid(input))
      .withMessage('Parent Id must be provided'),
  ],
  validateRequest,
  async (req: Request, res: Response) => {
    const { consultantId, customerId, parentId, appointmentDate, consultationType, appointmentSlotId } = req.body;

    if (!moment(appointmentDate, 'YYYY-MM-DD', true).isValid()) {
      throw new BadRequestError("Date Format should be YYYY-MM-DD");
    }

    //Make sure only future appointments consider as valid. 
    if (!moment(appointmentDate).isSameOrAfter(moment().utcOffset(330).format('YYYY-MM-DD'))) {
      throw new BadRequestError("Cannot make appointment for past date");
    }

    if (moment(appointmentDate).isSame(moment().utcOffset(330).format('YYYY-MM-DD'))) {
      if (appointmentSlotId < ((moment().utcOffset(330).toObject()).hours * 2 + ((moment().utcOffset(330).toObject()).minutes > 30 ? 2 : 1)) + 1) {
        throw new BadRequestError("Cannot make appointment for past time");
      }
    }

    let existingAppointmentConfig = await AppointmentConfig.findOne({
      consultantId: consultantId,
      appointmentDate: appointmentDate
    });

    if (!existingAppointmentConfig) {
      throw new NotFoundError();
    }

    //check if requested slot is available
    if (existingAppointmentConfig.availableSlots[appointmentSlotId] !== SlotAvailability.Available) {
      throw new BadRequestError("Sorry, Requested Appointment Slot Not Available");
    }
    const newList = [...existingAppointmentConfig.availableSlots];
    //Requested Slot is available make it as blocked for next 10 min
    newList[appointmentSlotId] = SlotAvailability.Blocked;
    existingAppointmentConfig.set({
      availableSlots: newList,
    });
    await existingAppointmentConfig.save();

    const expiration = new Date();

    expiration.setSeconds(expiration.getSeconds() + DEFAULT_EXPIRATION_WINDOW_SECONDS);

    const appointment = Appointment.build({
      id: new mongoose.Types.ObjectId().toHexString(),
      consultantId: consultantId,
      customerId: customerId,
      creatorId: req.currentUser!.id,
      basePriceInINR: existingAppointmentConfig.basePriceInINR,
      appointmentSlotId: appointmentSlotId,
      parentId: parentId,
      createdBy: req.currentUser!.uty,
      consultationType: consultationType,
      appointmentDate: appointmentDate,
      appointmentStatus: AppointmentStatus.Blocked,
      appointmentCreationTime: new Date(),
      appointmentStatusUpdateTime: new Date(),
      partnerId: req.currentUser!.fid,
      lastAppointmentStatus: AppointmentStatus.Blocked,
      expirationDate: expiration,
    });

    // Save the profile to the database
    await appointment.save();
    res.status(201).send(appointment);

    ///// Publish New Appointment Message //////////////
    new AppointmentCreatedPublisher(natsWrapper.client).publish({
      productId: appointment.id,
      expirationDate: appointment.expirationDate,
      basePriceInINR: appointment.basePriceInINR,
      customerId: appointment.customerId,
      parentId: appointment.parentId,
    });
  }
);

export { router as addAppointmentRouter };
