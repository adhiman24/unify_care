import express, { Request, Response } from 'express';
import { body } from 'express-validator';
import { validateRequest, AppointmentStatus, requirePatientAuth, SlotAvailability, NotFoundError } from '@unifycare/aem';
import { Appointment } from '../models/appointment';
import { AppointmentConfig } from '../models/appointment-config';
import mongoose from 'mongoose';
import { natsWrapper } from '../nats-wrapper'
import { AppointmentCancelPublisher } from '../events/publishers/appointment-cancel-publisher'
const router = express.Router();

router.post(
  '/api/appointment/cancel',
  requirePatientAuth,
  [
    body('appointmentId')
      .not()
      .isEmpty()
      .custom((input: string) => mongoose.Types.ObjectId.isValid(input))
      .withMessage('Appointment Id must be provided'),
  ],
  validateRequest,
  async (req: Request, res: Response) => {
    const { appointmentId } = req.body;

    const appointment = await Appointment.findById(appointmentId);
    if (!appointment) {
      console.log('Apppointment Not Found for Id: ', appointmentId);
      throw new NotFoundError();
    }
    appointment.set({
      lastAppointmentStatus: appointment.appointmentStatus,
      appointmentStatus: AppointmentStatus.Cancelled,
      appointmentStatusUpdateTime: new Date(),
    });
    await appointment.save();

    let existingAppointmentConfig = await AppointmentConfig.findOne({
      consultantId: appointment.consultantId,
      appointmentDate: appointment.appointmentDate
    });

    if (!existingAppointmentConfig) {
      throw new NotFoundError();
    }

    const newList = [...existingAppointmentConfig.availableSlots];
    newList[appointment.appointmentSlotId] = SlotAvailability.Available;
    existingAppointmentConfig.set({
      availableSlots: newList,
    });
    await existingAppointmentConfig.save();

    ///// Publish New Appointment Message //////////////
    new AppointmentCancelPublisher(natsWrapper.client).publish({
      appointmentId: appointment.id,
    });

    res.status(200).send(appointment);
  }
);

export { router as cancelAppointmentRouter };
