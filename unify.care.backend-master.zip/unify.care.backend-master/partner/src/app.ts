import express from 'express';
import 'express-async-errors';
import swaggerUi from 'swagger-ui-express';
import { swaggerPostDocument } from './swagger-post';
import { swaggerGetDocument } from './swagger-get';
import { swaggerPutDocument } from './swagger-put';
import { json } from 'body-parser';
import cookieSession from 'cookie-session';
import { errorHandler, NotFoundError, currentUser } from '@unifycare/aem';
import { loggerMiddleware, winstonMiddleware } from '@unifycare/logger';
import { createPartnerBankDetailsRouter } from './routes/create-partner-bank-details';
import { createPartnerInfoRouter } from './routes/create-partner-information';
import { createPartnerSigningAuthRouter } from './routes/create-partner-signing-auth';
import { createPartnerEmployeeRouter } from './routes/create-partner-employee';
import { indexPartnerStateRouter } from './routes/index';
import { resendInviteEmployeeRouter } from './routes/resend-invite-mail-employee';
import { showAllPartnerSuperuserRouter } from './routes/show-all-superuser';
import { showPartnerBankDetailsRouter } from './routes/show-partner-bank-details';
import { showPartnerEmployeeRouter } from './routes/show-partner-employee';
import { showAllPartnerEmployeeRouter } from './routes/show-all-partner-employee';
import { showPartnerInfoRouter } from './routes/show-partner-information';
import { showPartnerSigningAuthRouter } from './routes/show-partner-signing-auth';
import { showPartnerSuperuserRouter } from './routes/show-superuser';
import { updateBankDetailsRouter } from './routes/update-bank-details';
import { updateInfoRouter } from './routes/update-information';
import { updatePartnerBankDetailsRouter } from './routes/update-partner-bank-details';
import { updatePartnerSubuserStatusRouter } from './routes/update-partner-employee-status';
import { updatePartnerInfoRouter } from './routes/update-partner-information';
import { updatePartnerSigningAuthRouter } from './routes/update-partner-signing-auth';
import { updateSigningAuthRouter } from './routes/update-signing-auth';
import { updatePartnerSuperuserStatusRouter } from './routes/update-superuser-status';

var cors = require('cors')

const app = express();

app.use(cors({ credentials: true, origin: 'http://localhost:3000' }));
app.set('trust proxy', true);
app.use(json());
app.use(
  cookieSession({
    signed: false,
    secure: process.env.NODE_ENV !== 'test',
    //secure: false,

  })
);

app.use(currentUser);

app.use(loggerMiddleware);
app.use(winstonMiddleware);
app.use('/api/partner/swagger/post', swaggerUi.serve, swaggerUi.setup(swaggerPostDocument));
app.use('/api/partner/swagger/get', swaggerUi.serve, swaggerUi.setup(swaggerGetDocument));
app.use('/api/partner/swagger/put', swaggerUi.serve, swaggerUi.setup(swaggerPutDocument));
app.use(indexPartnerStateRouter);
app.use(createPartnerBankDetailsRouter);
app.use(createPartnerInfoRouter);
app.use(createPartnerSigningAuthRouter);
app.use(createPartnerEmployeeRouter);
app.use(showAllPartnerSuperuserRouter);
app.use(showPartnerBankDetailsRouter);
app.use(showPartnerInfoRouter);
app.use(showPartnerSigningAuthRouter);
app.use(showPartnerEmployeeRouter);
app.use(showPartnerSuperuserRouter);
app.use(updatePartnerBankDetailsRouter);
app.use(updatePartnerInfoRouter);
app.use(updatePartnerSubuserStatusRouter);
app.use(updatePartnerSuperuserStatusRouter);
app.use(updatePartnerSigningAuthRouter);
app.use(updateBankDetailsRouter);
app.use(updateInfoRouter);
app.use(updateSigningAuthRouter);
app.use(showAllPartnerEmployeeRouter);
app.use(resendInviteEmployeeRouter);


app.all('*', async (req, res) => {
  throw new NotFoundError();
});

app.use(errorHandler);

export { app };
