import express, { Request, Response } from 'express';
import { body } from 'express-validator';
import {
  requirePartnerSuperuserAuth,
  EmailType,
  EmailTemplate,
  EmailDeliveryType,
  NotFoundError,
  validateRequest
} from '@unifycare/aem';
import { PartnerEmployee } from '../models/partner-employee';
import { natsWrapper } from '../nats-wrapper';
import { SendNewEmailPublisher } from '../events/publishers/send-new-email-publisher';
import jwt from 'jsonwebtoken';
import mongoose from 'mongoose';

const router = express.Router();

router.post(
  '/api/partner/resendinvite',
  requirePartnerSuperuserAuth,
  [
    body('employeeId')
      .not()
      .isEmpty()
      .custom((input: string) => mongoose.Types.ObjectId.isValid(input))
      .withMessage('Employee Id must be provided'),
  ],
  validateRequest,
  async (req: Request, res: Response) => {

    const employee = await PartnerEmployee.findById(req.body.employeeId);

    if (!employee) {
      throw new NotFoundError();
    }

    //create token for email verification
    const inviteKey = jwt.sign(
      {
        id: employee.id,
      },
      process.env.JWT_KEY!, { expiresIn: 2 * 24 * 60 * 60 }
    );

    const userObj = {
      userFirstName: employee.userFirstName,
      userLastName: employee.userLastName,
      userEmailId: employee.emailId,
      inviteLink: `https://unify.care/invite-employee/${inviteKey}`
    }

    var objJson = JSON.stringify(userObj);

    //////// Send Email to  New User 
    new SendNewEmailPublisher(natsWrapper.client).publish({
      to: employee.emailId,
      from: 'ashutosh@rufous.com',
      subject: 'Invited To Join Unify Care',
      body: objJson,
      emailType: EmailType.HtmlText,
      emailTemplate: EmailTemplate.ForgotPassword,
      emaiDeliveryType: EmailDeliveryType.Immediate,
      atExactTime: new Date()
    });

    res.status(200).send("Invite Email Sent Successfully");
  }
);

export { router as resendInviteEmployeeRouter };
