import express, { Request, Response } from 'express';
import { NotFoundError, requirePartnerSuperuserAuth } from '@unifycare/aem';
import { PartnerEmployee } from '../models/partner-employee';

const router = express.Router();

router.get('/api/partner/employee', requirePartnerSuperuserAuth, async (req: Request, res: Response) => {
  const partnerEmployee = await PartnerEmployee.find({ partnerId: req.currentUser!.fid });

  res.send(partnerEmployee);
});

export { router as showAllPartnerEmployeeRouter };
