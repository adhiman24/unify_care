import request from 'supertest';
import { app } from '../../app';
import mongoose from 'mongoose';
import { UserType, AccessLevel, UserStatus, DepartmentType, SpecializationType } from '@unifycare/aem';
import { PartnerEmployee } from '../../models/partner-employee'

it('returns the employee if the employee is found', async () => {


  const partnerId = new mongoose.Types.ObjectId().toHexString();

  await request(app)
    .post('/api/partner/employee')
    .set('Cookie', global.signin(UserType.PartnerSuperuser,
      AccessLevel.PartnerSuperuser,
      UserStatus.Active,
      new mongoose.Types.ObjectId().toHexString(),
      partnerId))
    .send({
      userFirstName: 'Ashutosh',
      userLastName: 'New User',
      emailId: 'email@email.com',
      phoneNumber: '1234567890',
      userType: UserType.Doctor,
      dateOfBirth: '24-09-1980',
      experinceInYears: 10,
      highestQualification: 'btech',
      department: DepartmentType.CustomerSupport,
      specialization: SpecializationType.Cardiology,
      profileImageName: 'string',
      designation: 'string'
    })
    .expect(201);

  await request(app)
    .post('/api/partner/employee')
    .set('Cookie', global.signin(UserType.PartnerSuperuser,
      AccessLevel.PartnerSuperuser,
      UserStatus.Active,
      new mongoose.Types.ObjectId().toHexString(),
      partnerId))
    .send({
      userFirstName: 'Ashutosh2',
      userLastName: 'New User2',
      emailId: 'email2@email.com',
      phoneNumber: '2234567890',
      userType: UserType.Doctor,
      dateOfBirth: '25-09-1980',
      experinceInYears: 10,
      highestQualification: 'btech',
      department: DepartmentType.CustomerSupport,
      specialization: SpecializationType.Cardiology,
      profileImageName: 'string',
      designation: 'string'
    })
    .expect(201);

  const employeeResponse = await request(app)
    .get(`/api/partner/employee`)
    .set('Cookie', global.signin(UserType.PartnerSuperuser,
      AccessLevel.PartnerSuperuser,
      UserStatus.Active,
      new mongoose.Types.ObjectId().toHexString(),
      partnerId))
    .send()
    .expect(200);

  expect(employeeResponse.body[0].userFirstName).toEqual('Ashutosh');
  expect(employeeResponse.body[1].userFirstName).toEqual('Ashutosh2');

});
