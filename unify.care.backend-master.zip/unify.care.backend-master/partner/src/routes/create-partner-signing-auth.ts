import express, { Request, Response } from 'express';
import { body } from 'express-validator';
import {
  requirePartnerSuperuserAuth,
  validateRequest,
  KYCStatus,
  DocumentStatus,
  PartnerType,
  PartnerStates
} from '@unifycare/aem';
import { PartnerState } from '../models/partner-state';
import { PartnerSigningAuth } from '../models/partner-signing-auth'

const router = express.Router();

router.post(
  '/api/partner/signingauth',
  requirePartnerSuperuserAuth,
  [
    body('signingAuthName').not().isEmpty().withMessage('Signing Authority Name is required'),
    body('signingAuthWorkEmail').isEmail().withMessage('Email must be valid'),
    body('signingAuthTaxId').not().isEmpty().withMessage('Tax Id is required'),
  ],
  validateRequest,
  async (req: Request, res: Response) => {

    const {
      signingAuthName, signingAuthWorkEmail, signingAuthTaxId,
      signingAuthTaxIdUrl, signingAuthTitle,
      signingAuthLetterUrl,
    } = req.body;

    let partnerType = PartnerType.MainBranch;

    const partnerID = req.currentUser!.fid;

    let partnerInfo = await PartnerSigningAuth.findById(partnerID);

    if (partnerInfo) {

      partnerInfo.set({
        partnerType: partnerType,
        partnerSigningAuthStatus: KYCStatus.Unverified,
        signingAuthName: signingAuthName,
        signingAuthWorkEmail: signingAuthWorkEmail,
        signingAuthTaxId: signingAuthTaxId,
        signingAuthTaxIdUrl: signingAuthTaxIdUrl,
        signingAuthTaxIdStatus: DocumentStatus.Unverified,
        signingAuthTitle: signingAuthTitle,
        signingAuthLetterUrl: signingAuthLetterUrl,
        signingAuthLetterStatus: DocumentStatus.Unverified,

      });
      await partnerInfo.save();
    } else {

      partnerInfo = PartnerSigningAuth.build({
        id: partnerID,
        superuserId: req.currentUser!.id,
        partnerType: partnerType,
        partnerSigningAuthStatus: KYCStatus.Unverified,
        signingAuthName: signingAuthName,
        signingAuthWorkEmail: signingAuthWorkEmail,
        signingAuthTaxId: signingAuthTaxId,
        signingAuthTaxIdUrl: signingAuthTaxIdUrl,
        signingAuthTaxIdStatus: DocumentStatus.Unverified,
        signingAuthTitle: signingAuthTitle,
        signingAuthLetterUrl: signingAuthLetterUrl,
        signingAuthLetterStatus: DocumentStatus.Unverified,
        partnerId: req.currentUser!.fid,

      });
      await partnerInfo.save();

      //Update State 
      const existingState = await PartnerState.findById(partnerID);

      if (!existingState) {
        console.log('PartnerState not found for id : ' + partnerID);
      } else {
        existingState.set({
          currentState: PartnerStates.AddPartnerBankingDetails,
        });
        await existingState.save();
      }
    }

    res.status(201).send(partnerInfo);
  }
);

export { router as createPartnerSigningAuthRouter };
