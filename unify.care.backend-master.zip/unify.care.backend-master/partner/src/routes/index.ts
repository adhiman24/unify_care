import express, { Request, Response } from 'express';
import { PartnerState } from '../models/partner-state';
import { requirePartnerSuperuserAuth, NotFoundError } from '@unifycare/aem';

const router = express.Router();

router.get('/api/partner', requirePartnerSuperuserAuth, async (req: Request, res: Response) => {
  const partnerId = req.currentUser!.fid;
  const partnerState = await PartnerState.findById(partnerId);

  res.send(partnerState);
});

export { router as indexPartnerStateRouter };
