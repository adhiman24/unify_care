import express, { Request, Response } from 'express';
import { body } from 'express-validator';
import {
  requirePartnerSuperuserAuth,
  validateRequest,
  KYCStatus,
  DocumentStatus,
  PartnerType,
  PartnerStates
} from '@unifycare/aem';
import { PartnerState } from '../models/partner-state';
import { PartnerBankDetails } from '../models/partner-bank-details'

const router = express.Router();

router.post(
  '/api/partner/bankdetails',
  requirePartnerSuperuserAuth,
  [
    body('bankAccountName').not().isEmpty().withMessage('Bank Account Name is required'),
    body('bankAccountNumber').not().isEmpty().withMessage('Bank Account Number is required'),
    body('bankName').not().isEmpty().withMessage('Bank Name is required'),
  ],
  validateRequest,
  async (req: Request, res: Response) => {

    const {
      bankAccountName, bankAccountNumber, bankIFSCCode,
      bankName, bankChequeURL,
    } = req.body;

    const partnerType = PartnerType.Branch;

    const partnerID = req.currentUser!.fid;

    let bankDetail = await PartnerBankDetails.findById(partnerID);

    if (bankDetail) {

      bankDetail.set({
        partnerType: partnerType,
        partnerBankDetailsStatus: KYCStatus.Unverified,
        bankAccountName: bankAccountName,
        bankAccountNumber: bankAccountNumber,
        bankIFSCCode: bankIFSCCode,
        bankName: bankName,
        bankChequeURL: bankChequeURL,
        bankChequeStatus: DocumentStatus.Unverified,

      });
      await bankDetail.save();
    } else {

      const bankDetail = PartnerBankDetails.build({
        id: partnerID,
        superuserId: req.currentUser!.id,
        partnerType: partnerType,
        partnerBankDetailsStatus: KYCStatus.Unverified,
        bankAccountName: bankAccountName,
        bankAccountNumber: bankAccountNumber,
        bankIFSCCode: bankIFSCCode,
        bankName: bankName,
        bankChequeURL: bankChequeURL,
        bankChequeStatus: DocumentStatus.Unverified,
        partnerId: req.currentUser!.fid,

      });
      await bankDetail.save();

      //Update State 
      const existingState = await PartnerState.findById(partnerID);

      if (!existingState) {
        console.log('PartnerState not found for id : ' + partnerID);
      } else {
        existingState.set({
          currentState: PartnerStates.PartnerVerificationPending,
        });
        await existingState.save();
      }

      res.status(201).send(bankDetail);
    }
  }
);

export { router as createPartnerBankDetailsRouter };
