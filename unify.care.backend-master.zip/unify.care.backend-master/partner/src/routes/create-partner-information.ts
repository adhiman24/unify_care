import express, { Request, Response } from 'express';
import { body } from 'express-validator';
import {
  requirePartnerSuperuserAuth,
  validateRequest,
  BadRequestError,
  KYCStatus,
  DocumentStatus,
  PartnerType,
  PartnerStates
} from '@unifycare/aem';
import { PartnerState } from '../models/partner-state';
import { PartnerInfo } from '../models/partner-information'

const router = express.Router();

router.post(
  '/api/partner/information',
  requirePartnerSuperuserAuth,
  [
    body('city').not().isEmpty().withMessage('City is required'),
    body('state').not().isEmpty().withMessage('State is required'),
    body('country').not().isEmpty().withMessage('Country is required'),
  ],
  validateRequest,
  async (req: Request, res: Response) => {

    const {
      legalName, website,
      addressLine1, addressLine2, city, state, country,
      pincode, corporateId, corporateIdUrl, corporateTaxId, corporateTaxIdUrl, goodsAndServicesTaxId,
      goodsAndServicesTaxIdUrl
    } = req.body;

    const partnerID = req.currentUser!.fid;

    let partnerInfo = await PartnerInfo.findById(partnerID);

    if (partnerInfo) {
      console.log('found partner info ....should not happen');

      partnerInfo.set({
        legalName: legalName,
        website: website,
        services: 'NA',
        addressLine1: addressLine1,
        addressLine2: addressLine2,
        city: city,
        state: state,
        country: country,
        pincode: pincode,
        corporateId: corporateId,
        corporateIdUrl: corporateIdUrl,
        corporateIdStatus: DocumentStatus.Unverified,
        corporateTaxId: corporateTaxId,
        corporateTaxIdUrl: corporateTaxIdUrl,
        corporateTaxIdStatus: DocumentStatus.Unverified,
        goodsAndServicesTaxId: goodsAndServicesTaxId,
        goodsAndServicesTaxIdUrl: goodsAndServicesTaxIdUrl,
        goodsAndServicesTaxIdStatus: DocumentStatus.Unverified,
        partnerInfoStatus: KYCStatus.Unverified,

      });
      await partnerInfo.save();
    } else {

      const existingCorporateId = await PartnerInfo.findOne({ corporateId });
      if (existingCorporateId) {
        throw new BadRequestError('Partner already Exist with Same Corporate ID');
      }

      const existingCorporateTaxId = await PartnerInfo.findOne({ corporateTaxId });
      if (existingCorporateTaxId) {
        throw new BadRequestError('Partner already Exist with Same Corporate Tax ID');
      }

      const existingGSTId = await PartnerInfo.findOne({ goodsAndServicesTaxId });
      if (existingGSTId) {
        throw new BadRequestError('Partner already Exist with Same GST ID');
      }

      let partnerType = PartnerType.MainBranch;

      const partnerInfo = PartnerInfo.build({
        id: partnerID,
        superuserId: req.currentUser!.id,
        partnerType: partnerType,
        legalName: legalName,
        website: website,
        services: 'NA',
        addressLine1: addressLine1,
        addressLine2: addressLine2,
        city: city,
        state: state,
        country: country,
        pincode: pincode,
        corporateId: corporateId,
        corporateIdUrl: corporateIdUrl,
        corporateIdStatus: DocumentStatus.Unverified,
        corporateTaxId: corporateTaxId,
        corporateTaxIdUrl: corporateTaxIdUrl,
        corporateTaxIdStatus: DocumentStatus.Unverified,
        goodsAndServicesTaxId: goodsAndServicesTaxId,
        goodsAndServicesTaxIdUrl: goodsAndServicesTaxIdUrl,
        goodsAndServicesTaxIdStatus: DocumentStatus.Unverified,
        partnerInfoStatus: KYCStatus.Unverified,
        partnerId: req.currentUser!.fid,

      });
      await partnerInfo.save();

      //Update State 
      const existingState = await PartnerState.findById(partnerID);

      if (!existingState) {
        console.log('PartnerState not found for id : ' + partnerID);
      } else {
        existingState.set({
          currentState: PartnerStates.AddPartnerBankingDetails,
        });
        await existingState.save();
      }
    }

    res.status(201).send(partnerInfo);
  }
);

export { router as createPartnerInfoRouter };
