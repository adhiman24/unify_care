import express, { Request, Response } from 'express';
import { requirePartnerSuperuserAuth } from '@unifycare/aem';
import { PartnerInfo } from '../models/partner-information';

const router = express.Router();

router.get('/api/partner/information', requirePartnerSuperuserAuth, async (req: Request, res: Response) => {
  const partner = await PartnerInfo.findById(req.currentUser!.fid);

  res.send(partner);
});

export { router as showPartnerInfoRouter };
