import express, { Request, Response } from 'express';
import { requireSuperAdminAuth } from '@unifycare/aem';
import { PartnerSuperuser } from '../models/partner-superuser';

const router = express.Router();

router.get('/api/partner/sudo/superuser', requireSuperAdminAuth, async (req: Request, res: Response) => {

  const partnerSuperuser = await PartnerSuperuser.find({});

  res.send(partnerSuperuser);
});

export { router as showAllPartnerSuperuserRouter };
