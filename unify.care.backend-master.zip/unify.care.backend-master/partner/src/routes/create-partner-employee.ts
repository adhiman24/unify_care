import express, { Request, Response } from 'express';
import { body } from 'express-validator';
import {
  requirePartnerSuperuserAuth,
  validateRequest,
  UserStatus,
  AccessLevel,
  EmailType,
  EmailTemplate,
  EmailDeliveryType
} from '@unifycare/aem';
import { PartnerEmployee } from '../models/partner-employee';
import { PartnerEmployeeCreatedPublisher } from '../events/publishers/partner-employee-created-publisher';
import { natsWrapper } from '../nats-wrapper';
import mongoose from 'mongoose';

import { SendNewEmailPublisher } from '../events/publishers/send-new-email-publisher';
import jwt from 'jsonwebtoken';

const router = express.Router();

router.post(
  '/api/partner/employee',
  requirePartnerSuperuserAuth,
  [
    body('userFirstName').not().isEmpty().withMessage('User First Name is required'),
    body('userType').not().isEmpty().withMessage('UserType is required'),
    body('emailId').isEmail().withMessage('Email must be valid'),
    body('phoneNumber')
      .trim()
      .isLength({ min: 10, max: 10 })
      .withMessage('Phone Number must be 10 Digit'),
  ],
  validateRequest,
  async (req: Request, res: Response) => {

    const {
      userFirstName,
      userLastName,
      emailId,
      phoneNumber,
      userType,
      dateOfBirth,
      experinceInYears,
      highestQualification,
      department,
      specialization,
      profileImageName,
      designation
    } = req.body;

    const id = new mongoose.Types.ObjectId().toHexString();

    const employee = PartnerEmployee.build({
      id,
      userFirstName,
      userLastName,
      emailId,
      phoneNumber,
      partnerId: req.currentUser!.fid,
      userStatus: UserStatus.Unverified,
      accessLevel: AccessLevel.Employee,
      userType: userType,
      dateOfBirth: dateOfBirth,
      experinceInYears: experinceInYears,
      highestQualification: highestQualification,
      department: department,
      specialization: specialization,
      profileImageName: profileImageName,
      designation: designation,
      onboardingDate: new Date(),
    });
    await employee.save();

    new PartnerEmployeeCreatedPublisher(natsWrapper.client).publish({
      id: employee.id,
      userFirstName: employee.userFirstName,
      userLastName: employee.userLastName,
      emailId: employee.emailId,
      phoneNumber: employee.phoneNumber,
      partnerId: employee.partnerId,
      userStatus: employee.userStatus,
      accessLevel: employee.accessLevel,
      userType: employee.userType,
      dateOfBirth: employee.dateOfBirth,
      experinceInYears: employee.experinceInYears,
      highestQualification: employee.highestQualification,
      department: employee.department,
      specialization: employee.specialization,
      profileImageName: employee.profileImageName,
      designation: employee.designation
    });

    //create token for email verification
    const inviteKey = jwt.sign(
      {
        id: employee.id,
      },
      process.env.JWT_KEY!, { expiresIn: 2 * 24 * 60 * 60 }
    );

    const userObj = {
      userFirstName: employee.userFirstName,
      userLastName: employee.userLastName,
      userEmailId: employee.emailId,
      inviteLink: `https://unify.care/invite-employee/${inviteKey}`
    }

    var objJson = JSON.stringify(userObj);

    //////// Send Email to  New User 
    new SendNewEmailPublisher(natsWrapper.client).publish({
      to: employee.emailId,
      from: 'ashutosh@rufous.com',
      subject: 'Invited To Join Unify Care',
      body: objJson,
      emailType: EmailType.HtmlText,
      emailTemplate: EmailTemplate.ForgotPassword,
      emaiDeliveryType: EmailDeliveryType.Immediate,
      atExactTime: new Date()
    });

    res.status(201).send(employee);
  }
);

export { router as createPartnerEmployeeRouter };
