import express, { Request, Response } from 'express';
import { requirePartnerSuperuserAuth } from '@unifycare/aem';
import { PartnerBankDetails } from '../models/partner-bank-details';

const router = express.Router();

router.get('/api/partner/bankdetails', requirePartnerSuperuserAuth, async (req: Request, res: Response) => {
  const partner = await PartnerBankDetails.findById(req.currentUser!.fid);

  res.send(partner);
});

export { router as showPartnerBankDetailsRouter };
