import express, { Request, Response } from 'express';
import { requirePartnerSuperuserAuth } from '@unifycare/aem';
import { PartnerSigningAuth } from '../models/partner-signing-auth';

const router = express.Router();

router.get('/api/partner/signingauth', requirePartnerSuperuserAuth, async (req: Request, res: Response) => {
  const partner = await PartnerSigningAuth.findById(req.currentUser!.fid);

  res.send(partner);
});

export { router as showPartnerSigningAuthRouter };
