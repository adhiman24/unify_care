import { Publisher, Subjects, PartnerEmployeeCreatedEvent } from '@unifycare/aem';

export class PartnerEmployeeCreatedPublisher extends Publisher<PartnerEmployeeCreatedEvent> {
  subject: Subjects.PartnerEmployeeCreated = Subjects.PartnerEmployeeCreated;
}
