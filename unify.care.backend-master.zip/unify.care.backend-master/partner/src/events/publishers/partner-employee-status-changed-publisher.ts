import { Publisher, Subjects, PartnerEmployeeStatusChangedEvent } from '@unifycare/aem';

export class PartnerEmployeeStatusChangedPublisher extends Publisher<PartnerEmployeeStatusChangedEvent> {
  subject: Subjects.PartnerEmployeeStatusUpdated = Subjects.PartnerEmployeeStatusUpdated;
}
