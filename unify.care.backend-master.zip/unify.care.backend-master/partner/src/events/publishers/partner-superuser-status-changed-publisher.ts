import { Publisher, Subjects, PartnerSuperuserStatusChangedEvent } from '@unifycare/aem';

export class PartnerSuperuserStatusChangedPublisher extends Publisher<PartnerSuperuserStatusChangedEvent> {
  subject: Subjects.PartnerSuperuserStatusUpdated = Subjects.PartnerSuperuserStatusUpdated;
}
