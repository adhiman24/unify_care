import { Message } from 'node-nats-streaming';
import { Listener, UserCreatedEvent, Subjects, PartnerStates, PartnerType } from '@unifycare/aem';
import { partnerSuperuserCreatedGroupName } from './queue-group-name';
import { PartnerSuperuser } from '../../models/partner-superuser';
import { PartnerState } from '../../models/partner-state';

export class UserCreatedListener extends Listener<UserCreatedEvent> {
  subject: Subjects.UserCreated = Subjects.UserCreated;
  queueGroupName = partnerSuperuserCreatedGroupName;

  async onMessage(data: UserCreatedEvent['data'], msg: Message) {

    if (data.partnerType === PartnerType.NotApplicable) {
      msg.ack();
      return;
    }

    let partner = await PartnerSuperuser.findById(data.id)

    if (partner) {
      msg.ack();
      return;
    }

    // Create a candidate  
    partner = PartnerSuperuser.build({
      id: data.id,
      userFirstName: data.userFirstName,
      userLastName: data.userLastName,
      emailId: data.emailId,
      phoneNumber: data.phoneNumber,
      partnerId: data.partnerId,
      partnerType: data.partnerType,
      userStatus: data.userStatus,
      accessLevel: data.accessLevel,
      userType: data.userType,
    });
    await partner.save();
    // Set user state
    //Update State 
    const existingState = PartnerState.build({
      id: partner.partnerId,
      superuserId: partner.id,
      partnerType: partner.partnerType,
      currentState: PartnerStates.AddPartnerInformation,
      partnerId: partner.partnerId,
    });
    await existingState.save();

    // ack the message
    msg.ack();
  }
}
