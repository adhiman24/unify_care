export const partnerSuperuserCreatedGroupName = 'partner-superuser-created-service';
export const databasBackupGroupName = 'partner-database-backup-service';
export const databasUploadGroupName = 'partner-database-upload-service';