import mongoose from 'mongoose';
import { UserStatus, UserType, AccessLevel, DepartmentType, SpecializationType } from '@unifycare/aem';
import { updateIfCurrentPlugin } from 'mongoose-update-if-current';


interface PartnerEmployeeAttrs {
  id: string;
  userFirstName: string;
  userLastName: string;
  emailId: string;
  phoneNumber: string;
  partnerId: string;
  userStatus: UserStatus;
  accessLevel: AccessLevel;
  dateOfBirth: string;
  experinceInYears: number;
  highestQualification: string;
  userType: UserType;
  department: DepartmentType;
  specialization: SpecializationType;
  profileImageName: string;
  designation: string;
  onboardingDate: Date;
}

interface PartnerEmployeeDoc extends mongoose.Document {
  userFirstName: string;
  userLastName: string;
  emailId: string;
  phoneNumber: string;
  partnerId: string;
  userStatus: UserStatus;
  accessLevel: AccessLevel;
  dateOfBirth: string;
  experinceInYears: number;
  userType: UserType;
  department: DepartmentType;
  specialization: SpecializationType;
  highestQualification: string;
  profileImageName: string;
  designation: string;
  onboardingDate: Date;
  version: number;
}


interface PartnerEmployeeModel extends mongoose.Model<PartnerEmployeeDoc> {
  build(attrs: PartnerEmployeeAttrs): PartnerEmployeeDoc;
  findByEvent(event: {
    id: string;
    version: number;
  }): Promise<PartnerEmployeeDoc | null>;
}

const partnerEmployeeSchema = new mongoose.Schema(
  {
    userFirstName: {
      type: String,
      required: true,
    },
    userLastName: {
      type: String,
      required: true,
    },
    emailId: {
      type: String,
      required: true,
    },
    phoneNumber: {
      type: String,
      required: true,
    },
    partnerId: {
      type: String,
      required: true,
    },
    userStatus: {
      type: UserStatus,
      required: true,
    },
    accessLevel: {
      type: AccessLevel,
      required: true,
    },
    userType: {
      type: UserType,
      required: true,
    },
    dateOfBirth: {
      type: String,
      required: true,
    },
    experinceInYears: {
      type: Number,
      required: true,
    },
    department: {
      type: DepartmentType,
      required: true,
    },
    specialization: {
      type: SpecializationType,
      required: true,
    },
    profileImageName: {
      type: String,
      required: true,
    },
    designation: {
      type: String,
      required: true,
    },
    highestQualification: {
      type: String,
      required: true,
    },
    onboardingDate: {
      type: Date,
      required: true,
    }
  },
  {
    toJSON: {
      transform(doc, ret) {
        ret.id = ret._id;
        delete ret._id;
      },
    },
  }
);
partnerEmployeeSchema.set('versionKey', 'version');
partnerEmployeeSchema.plugin(updateIfCurrentPlugin);

partnerEmployeeSchema.static('findByEvent', (event: { id: string, version: number }) => {
  return PartnerEmployee.findOne({
    _id: event.id,
    version: event.version - 1,
  });
});
partnerEmployeeSchema.static('build', (attrs: PartnerEmployeeAttrs) => {
  return new PartnerEmployee({
    _id: attrs.id,
    userFirstName: attrs.userFirstName,
    userLastName: attrs.userLastName,
    emailId: attrs.emailId,
    phoneNumber: attrs.phoneNumber,
    partnerId: attrs.partnerId,
    userStatus: attrs.userStatus,
    accessLevel: attrs.accessLevel,
    userType: attrs.userType,
    dateOfBirth: attrs.dateOfBirth,
    experinceInYears: attrs.experinceInYears,
    department: attrs.department,
    specialization: attrs.specialization,
    profileImageName: attrs.profileImageName,
    designation: attrs.designation,
    highestQualification: attrs.highestQualification,
    onboardingDate: attrs.onboardingDate
  });
});

const PartnerEmployee = mongoose.model<PartnerEmployeeDoc, PartnerEmployeeModel>('PartnerEmployee', partnerEmployeeSchema);

export { PartnerEmployee };
