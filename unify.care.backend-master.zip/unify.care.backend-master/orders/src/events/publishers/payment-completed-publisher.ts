import { Subjects, Publisher, PaymentCompletedEvent } from '@unifycare/aem';

export class PaymentCompletedPublisher extends Publisher<PaymentCompletedEvent> {
  subject: Subjects.PaymentCompleted = Subjects.PaymentCompleted;
}
