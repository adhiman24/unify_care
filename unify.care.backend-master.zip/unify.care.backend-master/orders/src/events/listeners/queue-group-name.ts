export const AppointmentExpiredGroupName = 'order-service';
export const AppointmentCreatedGroupName = 'order-service';
export const databasBackupGroupName = 'order-database-backup-service';
export const databasUploadGroupName = 'order-database-upload-service';
