import { Listener, AppointmentExpiredEvent, Subjects, OrderStatus } from '@unifycare/aem';
import { Message } from 'node-nats-streaming';
import { AppointmentExpiredGroupName } from './queue-group-name';
import { Order } from '../../models/order';

export class AppointmentExpiredListener extends Listener<AppointmentExpiredEvent> {
  subject: Subjects.AppointmentExpired = Subjects.AppointmentExpired;
  queueGroupName = AppointmentExpiredGroupName;

  async onMessage(data: AppointmentExpiredEvent['data'], msg: Message) {

    let order = await Order.findOne({ productId: data.productId });
    if (!order) {
      msg.ack();
      return
    }

    if (order.status === OrderStatus.Completed || order.status === OrderStatus.AwaitingPayment) {
      msg.ack();
      return
    }

    order.set({
      status: OrderStatus.Cancelled,
    });
    await order.save();

    msg.ack();
  }
};
