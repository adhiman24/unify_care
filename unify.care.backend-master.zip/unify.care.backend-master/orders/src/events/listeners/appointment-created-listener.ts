import { AppointmentCreatedGroupName } from './queue-group-name';
import { Message } from 'node-nats-streaming';
import { Listener, AppointmentCreatedEvent, Subjects, BadRequestError, OrderStatus } from '@unifycare/aem';
import { Order } from '../../models/order';
import mongoose from 'mongoose';
import short from 'short-uuid';

export class AppointmentCreatedListener extends Listener<AppointmentCreatedEvent> {
  subject: Subjects.AppointmentCreated = Subjects.AppointmentCreated;
  queueGroupName = AppointmentCreatedGroupName;

  async onMessage(data: AppointmentCreatedEvent['data'], msg: Message) {

    let order = await Order.findOne({ productId: data.productId });
    if (order) {
      msg.ack();
      return;
    }
    order = Order.build({
      id: new mongoose.Types.ObjectId().toHexString(),
      basePriceInINR: data.basePriceInINR,
      currency: "INR",
      customerId: data.customerId,
      productId: data.productId,
      parentId: data.parentId,
      status: OrderStatus.Created,
      order_id: 'NA',
      receipt: short.uuid(),
    });
    await order.save();
    msg.ack();
  }
}
