import { OrderStatus } from '@unifycare/aem';
import mongoose from 'mongoose';
import { updateIfCurrentPlugin } from 'mongoose-update-if-current';

interface OrderAttrs {
    id: string;
    basePriceInINR: number;
    customerId: string;
    currency: string;
    productId: string;
    parentId: string;
    status: OrderStatus;
    receipt: string;
    order_id: string;
}

interface OrderDoc extends mongoose.Document {
    basePriceInINR: number;
    customerId: string;
    currency: string;
    productId: string;
    parentId: string;
    status: OrderStatus;
    receipt: string;
    order_id: string;
    version: number;
}

interface OrderModel extends mongoose.Model<OrderDoc> {
    build(attrs: OrderAttrs): OrderDoc;
    findByEvent(event: {
        id: string;
        version: number;
    }): Promise<OrderDoc | null>;
}

const orderSchema = new mongoose.Schema(
    {
        basePriceInINR: {
            type: Number,
            required: true
        },
        customerId: {
            type: String,
            required: true
        },
        productId: {
            type: String,
            required: true
        },
        parentId: {
            type: String,
            required: true
        },
        order_id: {
            type: String,
            required: true
        },
        receipt: {
            type: String,
            required: true
        },
        currency: {
            type: String,
            required: true
        },
        status: {
            type: OrderStatus,
            required: true
        }
    },
    {
        toJSON: {
            transform(doc, ret) {
                ret.id = ret._id;
                delete ret._id;
            },
        },
    }
);
orderSchema.set('versionKey', 'version');
orderSchema.plugin(updateIfCurrentPlugin);

orderSchema.static('findByEvent', (event: { id: string, version: number }) => {
    return Order.findOne({
        _id: event.id,
        version: event.version - 1,
    });
});

orderSchema.static('build', (attrs: OrderAttrs) => {
    return new Order({
        _id: attrs.id,
        order_id: attrs.order_id,
        basePriceInINR: attrs.basePriceInINR,
        status: attrs.status,
        currency: attrs.currency,
        customerId: attrs.customerId,
        parentId: attrs.parentId,
        productId: attrs.productId,
        receipt: attrs.receipt,
    });
});

const Order = mongoose.model<OrderDoc, OrderModel>('Order', orderSchema);

export { Order };
