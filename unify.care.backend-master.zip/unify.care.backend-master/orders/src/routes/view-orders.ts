import express, { Request, Response } from 'express';
import { requirePatientAuth } from '@unifycare/aem';
import { Order } from '../models/order'

const router = express.Router();

router.get(
  '/api/order/all/:parentId',
  requirePatientAuth,
  async (req: Request, res: Response) => {
    const orders = await Order.find({ parentId: req.params.parentId });

    res.send(orders);
  });

export { router as viewOrdersRouter };
