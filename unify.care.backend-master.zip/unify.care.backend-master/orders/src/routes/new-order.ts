import express, { Request, Response } from 'express';
import { body } from 'express-validator';
import { validateRequest, requirePatientAuth, BadRequestError, OrderStatus, NotAuthorizedError, InternalServerError } from '@unifycare/aem';
import { Order } from '../models/order';
import mongoose from 'mongoose';
import Razorpay from 'razorpay';

const router = express.Router();

const razorpay = new Razorpay({
    key_id: process.env.RAZORPAY_API_KEY,
    key_secret: process.env.RAZORPAY_API_SECRET
});

router.post(
    '/api/order/new',
    requirePatientAuth,
    [
        body('productId')
            .not()
            .isEmpty()
            .custom((input: string) => mongoose.Types.ObjectId.isValid(input))
            .withMessage('Product Id must be provided'),
    ],
    validateRequest,
    async (req: Request, res: Response) => {

        let existingOrder = await Order.findOne({ productId: req.body.productId });
        if (!existingOrder) {
            throw new BadRequestError("Order Does Not Exist.");
        }

        if (existingOrder.status === OrderStatus.Cancelled) {
            throw new BadRequestError("Can not initiat payment for cancelled order.");
        }

        if (existingOrder.parentId !== req.currentUser!.id) {
            throw new NotAuthorizedError();
        }

        const options = {
            amount: existingOrder.basePriceInINR * 100,
            currency: existingOrder.currency,
            receipt: existingOrder.receipt
        };
        let order_id = 'NA';

        try {
            await razorpay.orders.create(options, function (err: any, order: any) {
                if (err) {
                    req.errorlog(err);
                    throw new InternalServerError();
                }
                order_id = order.id;
            });

        } catch (error) {
            console.log(error);
        }

        existingOrder.set({
            status: OrderStatus.AwaitingPayment,
            order_id: order_id,
        });
        await existingOrder.save();

        res.status(200).send(existingOrder);
    }
);

export { router as newOrderRouter };
