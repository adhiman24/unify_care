import express, { Request, Response } from 'express';
import { requirePatientAuth } from '@unifycare/aem';
import { Payment } from '../models/payment'

const router = express.Router();

router.get(
  '/api/order/payment/:id',
  requirePatientAuth,
  async (req: Request, res: Response) => {
    const payment = await Payment.findOne({ payment_id: req.params.id });

    res.send(payment);
  });

export { router as viewPaymentRouter };
